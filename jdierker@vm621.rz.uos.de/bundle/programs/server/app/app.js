var require = meteorInstall({"imports":{"startup":{"server":{"addGameData.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/addGameData.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"addPackageTasks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/addPackageTasks.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  addPackageTasks: () => addPackageTasks
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

function createDragTask(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "drag";
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: false,
    help: false
  };
  return taskSpecs;
}

function createTagTask(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "tag";
  taskSpecs["content"] = taskSpecs["content"];
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: false,
    help: false,
    readFinished: false
  };
  return taskSpecs;
}

function createClozeTask(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "cloze";
  taskSpecs["content"] = taskSpecs["content"];
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: false,
    help: false
  };
  return taskSpecs;
}

function createMemory(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "memory";
  taskSpecs["content"] = taskSpecs["content"];
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: false,
    help: false
  };
  return taskSpecs;
}

function createMultiChoice(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "multiChoice";
  taskSpecs["content"] = taskSpecs["content"];
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: false,
    help: false
  };
  return taskSpecs;
}

function createSurveyTask(taskSpecs) {
  taskSpecs["isTask"] = true;
  taskSpecs["taskId"] = taskSpecs["taskId"];
  taskSpecs["type"] = "survey";
  taskSpecs["package"] = taskSpecs["package"];
  taskSpecs["autoGrading"] = true;
  taskSpecs["filePrefix"] = taskSpecs["filePrefix"];
  taskSpecs["taskState"] = {
    save: true,
    help: false
  };
  return taskSpecs;
}

function addTasks(packageName, path) {
  let tasks = JSON.parse(Assets.getText(path))["tasks"];
  let trainings = [];

  for (let i in tasks) {
    tasks[i]["sequenceId"] = parseInt(i);

    if (tasks[i].isTraining) {
      trainings.push(tasks[i]);
    } else {
      let newtask = {};

      switch (tasks[i].filePrefix) {
        case "Drag":
          newtask = createDragTask(tasks[i]);
          break;

        case "Tag":
          newtask = createTagTask(tasks[i]);
          break;

        case "Multi":
          newtask = createMultiChoice(tasks[i]);
          break;

        case "Memory":
          newtask = createMemory(tasks[i]);
          break;

        case "Cloze":
          newtask = createClozeTask(tasks[i]);
          break;

        case "Survey":
          newtask = createSurveyTask(tasks[i]);
          break;
      }

      Meteor.call("tasks.insert", newtask);
    }
  }

  return trainings;
}

function addPackageTasks() {
  let trainings = {};
  trainings["Motivation"] = addTasks("Motivation", "tasks/motivation.json");
  trainings["Identität"] = addTasks("Identität", "tasks/identity.json");
  Meteor.call("training.insert", trainings);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"addPackages.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/addPackages.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  addPackages: () => addPackages
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Tasks;
module.link("../../api/tasks", {
  Tasks(v) {
    Tasks = v;
  }

}, 1);
let Training;
module.link("../../api/training", {
  Training(v) {
    Training = v;
  }

}, 2);
let Packages;
module.link("../../api/package", {
  Packages(v) {
    Packages = v;
  }

}, 3);

function createDragTask(trainingSpecs) {
  trainingSpecs["name"] = trainingSpecs["name"];
  trainingSpecs["package"] = trainingSpecs["package"];
  trainingSpecs["imageVideo"] = "link";
  trainingSpecs["discount"] = false;
  trainingSpecs["format"] = "pdf"; // taskSpecs["taskurl"] =
  //   "/Tasks/Maze/TaskPictures/" + taskSpecs["taskId"] + ".jpeg";

  return trainingSpecs;
}

function addPackages() {
  var packages = JSON.parse(Assets.getText("packages/package.json"))["packages"];

  for (var i = 0; i < packages.length; i++) {
    Meteor.call("package.insert", createDragTask(packages[i]));
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"databaseHandling.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/startup/server/databaseHandling.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  resetDatabase: () => resetDatabase
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);
let shortid;
module.link("shortid", {
  default(v) {
    shortid = v;
  }

}, 3);
let Teachers;
module.link("../../api/teachers", {
  Teachers(v) {
    Teachers = v;
  }

}, 4);
let Training;
module.link("../../api/training", {
  Training(v) {
    Training = v;
  }

}, 5);
let Courses;
module.link("../../api/courses", {
  Courses(v) {
    Courses = v;
  }

}, 6);
let Students;
module.link("../../api/students", {
  Students(v) {
    Students = v;
  }

}, 7);
let Tasks;
module.link("../../api/tasks", {
  Tasks(v) {
    Tasks = v;
  }

}, 8);
let Package;
module.link("../../api/package", {
  Package(v) {
    Package = v;
  }

}, 9);
let addPackages;
module.link("./addPackages", {
  addPackages(v) {
    addPackages = v;
  }

}, 10);
let addPackageTasks;
module.link("./addPackageTasks", {
  addPackageTasks(v) {
    addPackageTasks = v;
  }

}, 11);
let addGameData;
module.link("./addGameData", {
  addGameData(v) {
    addGameData = v;
  }

}, 12);

function resetDatabase() {
  clearDatabase(); // remove when loading custom database state

  setupAdmin();

  if (Meteor.isDevelopment) {
    setupTestCourse(true);
  }

  addPackageTasks();
  addPackages();
  initPackages();
  setupStudents();
  setupTeacher(); // remove when loading custom database state
}

//TODO SOURCE THIS OUT
function initPackages() {
  var packages = Package.find({}).fetch();

  for (var i in packages) {
    var content = packages[i].content;
    var tmp1 = [];
    var tmp2 = [];
    var pname = packages[i].name; //var tasks = Tasks.find({ package: pname }).fetch();

    var trainings = Training.find({}).fetch();

    for (var j in content) {
      var tasks = Tasks.find({
        parentId: packages[i].name + content[j].sequenceId
      }).fetch();
      content[j].tasks = tasks;
    }

    var packageUpdates = {
      $set: {
        content: content
      }
    };
    Package.update({
      _id: packages[i]._id
    }, packageUpdates);

    for (var k in trainings[0][pname]) {
      tmp2.push(trainings[0][pname][k].trainingId + trainings[0][pname][k].sequenceId);
    } //TODO PUT THIS IN 1 QUERY


    Package.update({
      _id: packages[i]._id
    }, packageUpdates);
    packageUpdates = {
      $set: {
        trainings: tmp2
      }
    };
    Package.update({
      _id: packages[i]._id
    }, packageUpdates); //TODO END
  }
}

function setupTestCourse(skipSetup) {
  const email = "dozent@yuoshi.de";
  const password = "123";
  const teacherId = Accounts.createUser({
    email,
    password
  });
  Roles.addUsersToRoles(teacherId, "teacher");
  Teachers.insert({
    userId: teacherId,
    courses: []
  });
  const courseId = shortid.generate();
  Courses.insert({
    _id: courseId,
    courseName: "Demo-Kurs",
    pupils: [],
    tasks: [],
    teacherId: Teachers.findOne()._id
  });
}

function setupAdmin() {
  const ppEmail = "admin@yuoshi.de";
  const password = "123";
  res = Accounts.createUser({
    username: "ppAdmin",
    email: ppEmail,
    password
  });

  const ppId = Accounts.findUserByEmail(ppEmail)._id;

  Roles.addUsersToRoles(ppId, "yadmin");
}

function setupTeacher() {
  let username = "teacher";
  let email = username;
  let userId = Accounts.createUser({
    username,
    email,
    password: username
  });
  Roles.addUsersToRoles(userId, "teacher");
  Teachers.insert({
    userId: userId,
    studipUserId: "",
    courses: []
  });
}

function setupStudents() {
  const courses = Courses.find({}).fetch();

  for (let i = 0; i < 9; i++) {
    let username = "user" + i;
    let email = username;
    let userId = Accounts.createUser({
      username,
      email,
      password: username
    });
    Roles.addUsersToRoles(userId, "student"); //TESTCASE WORKSPACE Tasks

    if (i == 2) {
      var task = Tasks.findOne({
        package: "Motivation",
        sequenceId: 1
      });
      Students.insert({
        userId: userId,
        credits: 0,
        exp: 0,
        level: 1,
        earning: [1],
        studipUserId: "e7a0a84b161f3e8c09b4a0a2e8a58147",
        lastActiveTaskId: null,
        courses: [],
        tasks: [task],
        solvedTasks: [],
        learnCards: [],
        solvedSurveys: [],
        currentSequenceId: 0,
        currentPackage: [],
        currentTraining: [],
        solvedTraining: []
      });
    } else {
      Students.insert({
        userId: userId,
        credits: 0,
        exp: 0,
        level: 1,
        earning: [1],
        studipUserId: "",
        lastActiveTaskId: null,
        courses: [],
        tasks: [],
        solvedTasks: [],
        learnCards: [],
        currentSequenceId: 0,
        currentPackage: [],
        currentTraining: [],
        solvedTraining: []
      });
    } //TESTCASE END
    // Dummy-Entry for Studip-Validated User:

  } // const dummyId = Accounts.createUser({
  //   username: "test_autor",
  //   password: "testing"
  // });
  // Students.insert({
  //   courseId: courses[0]._id,
  //   dummyId,
  //   username: `test_autor`
  // });

}

function clearDatabase() {
  Teachers.remove({});
  Students.remove({});
  Meteor.users.remove({});
  Courses.remove({});
  Tasks.remove({});
  Training.remove({});
  Package.remove({});
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"api":{"courses.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/courses.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Courses: () => Courses
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let shortid;
module.link("shortid", {
  default(v) {
    shortid = v;
  }

}, 3);
let Students;
module.link("./students", {
  Students(v) {
    Students = v;
  }

}, 4);
let Teachers;
module.link("./teachers", {
  Teachers(v) {
    Teachers = v;
  }

}, 5);
const Courses = new Mongo.Collection("courses");

if (Meteor.isServer) {
  // courseNames of one teacher are unique
  Courses.rawCollection().ensureIndex({
    teacherId: 1,
    courseName: 1
  }, {
    unique: true
  }); //Students

  Meteor.publish("coursesByStudent", () => {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["student"])) {
      var studentId = Students.findOne({
        userId: Meteor.userId()
      })._id;

      Courses.find({
        studentId
      });
      return Courses.find({
        studentId
      });
    }

    throw new Meteor.Error("Access denied!");
  });
  Meteor.publish("coursesById", function () {
    if (Meteor.userId()) {
      return Courses.find({});
    }

    throw new Meteor.Error("Access denied!");
  }); // teacher

  Meteor.publish("coursesByTeacher", courseId => {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["teacher"])) {
      var teacherId = Teachers.findOne({
        userId: Meteor.userId()
      })._id;

      Courses.findOne();
      return Courses.find({
        teacherId
      });
    }

    throw new Meteor.Error("Access denied!");
  }); // teacher

  Meteor.publish("classroomByName", function (className) {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["teacher"])) {
      return Courses.find({
        teacherId: Meteor.userId(),
        className
      });
    }

    throw new Meteor.Error("Access denied!");
  }); // admin

  Meteor.publish("courses", function () {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["yadmin"])) {
      return Courses.find({});
    }

    throw new Meteor.Error("Access denied!");
  }); // pupil

  Meteor.publish("coursesOfStudent", function () {
    const student = Students.findOne({
      userId: Meteor.userId()
    });

    if (student) {
      return Courses.find({
        _id: student.classId
      });
    }

    throw new Meteor.Error("Access denied!");
  });
}

Meteor.methods({
  // teacher
  "courses.insert": function (courseName, studipId, teacherId) {
    if (Meteor.isServer) {
      if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["teacher"])) {
        if (Courses.findOne({
          teacherId: Meteor.userId(),
          courseName
        })) throw new Meteor.Error("Class already exists!");
        const courseId = shortid.generate();
        const students = [];
        Courses.insert({
          teacherId: teacherId,
          courseName,
          studipId,
          students,
          started: false,
          tasks: [],
          paths: []
        });
        Teachers.update({
          $addToSet: {
            courses: courseId
          }
        });
      } else {
        throw new Meteor.Error("Access denied!");
      }
    }
  },
  // after basic-auth get the user-courses where the teacher initialized yuoshi
  "courses.getTeacherCourses": function (token, studipUserId) {
    //HTTP requests goes server-side only
    if (Meteor.isServer) {
      try {
        var courseRawData = HTTP.call("GET", "http://localhost/studip/plugins.php/argonautsplugin/users/" + studipUserId + "/courses", {
          headers: {
            Authorization: "Basic " + token
          }
        });
        var courseData = JSON.parse(courseRawData.content);
        var memberships = [];

        for (var i in courseData.data) {
          var tmpCourse = courseData.data[i];

          try {
            var membershipsRaw = HTTP.call("GET", "http://localhost/studip/plugins.php/argonautsplugin/courses/" + tmpCourse.id + "/memberships", {
              headers: {
                Authorization: "Basic " + token
              }
            });
            var membershipData = JSON.parse(membershipsRaw.content); //Search for courses where current user is "dozent"

            for (var k in membershipData.data) {
              var memberStatus = membershipData.data[k].attributes.status;
              var targetcourseId = membershipData.data[k].id.split("_")[1];
              var validDozent = targetcourseId === studipUserId;

              if (memberStatus == "dozent" && validDozent) {
                memberships.push(tmpCourse);
              }
            }
          } catch (e) {
            console.log(e);
            return false;
          }
        }

        return memberships;
      } catch (e) {
        console.log(e);
        return false;
      }
    }
  },
  "courses.getStudentCourses": function (token, studipUserId) {
    var user = Students.findOne({
      studipUserId: studipUserId
    });

    if (Meteor.isServer) {
      try {
        var courseRawData = HTTP.call("GET", "http://localhost/studip/plugins.php/argonautsplugin/users/" + studipUserId + "/courses", {
          headers: {
            Authorization: "Basic " + token
          }
        });
        var courseData = JSON.parse(courseRawData.content);
      } catch (e) {
        console.log(e);
        return false;
      }

      return courseData;
    }
  },
  "courses.start": function (courseId) {
    Courses.update({
      _id: courseId
    }, {
      $set: {
        started: true
      }
    });
  },
  "courses.delete": function (courseId, teacherId) {//TODO delte routine
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"package.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/package.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Package: () => Package
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
const Package = new Mongo.Collection("package");
const trainingSchema = new SimpleSchema({
  name: {
    type: String
  },
  tasks: {
    type: Array
  },
  "tasks.$": {
    type: String
  },
  trainings: {
    type: Array
  },
  "trainings.$": {
    type: String
  }
}).newContext();

if (Meteor.isServer) {
  Meteor.publish("package", () => {
    return Package.find({});
  });
}

Meteor.methods({
  "package.insert"(training) {
    Package.insert(training);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"students.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/students.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Students: () => Students
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 3);
let Classrooms;
module.link("./courses", {
  Classrooms(v) {
    Classrooms = v;
  }

}, 4);
let Teachers;
module.link("./teachers", {
  Teachers(v) {
    Teachers = v;
  }

}, 5);
let Courses;
module.link("./courses", {
  Courses(v) {
    Courses = v;
  }

}, 6);
let Tasks;
module.link("./tasks", {
  Tasks(v) {
    Tasks = v;
  }

}, 7);
let Package;
module.link("./package", {
  Package(v) {
    Package = v;
  }

}, 8);
const Students = new Mongo.Collection("students");

function checkTaskRequirements(req, solvedTasks) {
  let allRequiredFound = true;

  for (let i in req) {
    let found = solvedTasks.find(elem => {
      return elem.taskId === req[i];
    });

    if (found === undefined) {
      allRequiredFound = false;
    }
  }

  return allRequiredFound;
}

Meteor.methods({
  "students.insert": function (userId, studipUserId) {
    Students.insert({
      userId: userId,
      credits: 0,
      exp: 0,
      level: 1,
      earning: [1],
      studipUserId: studipUserId,
      lastActiveTaskId: null,
      courses: [],
      tasks: [],
      solvedSurveys: [],
      currentSequenceId: 0,
      currentTraining: [],
      solvedTraining: [],
      learnCards: [],
      solvedTasks: [],
      currentPackage: []
    });
  },
  "student.saveLearncard": function (_id, subject, statement, example, image, content) {
    let learnCardObj = {
      subject,
      statement,
      example,
      image,
      content
    };
    Students.update(_id, {
      $addToSet: {
        learnCards: learnCardObj
      }
    });
  },
  "students.addCourse": function (courseId, _id) {
    Students.update(_id, {
      $addToSet: {
        courses: courseId
      }
    });
  },
  "students.getStartedCourses": function (studentCourses) {
    var tmp = [];

    for (var i = 0; i < studentCourses.length; i++) {
      tmp.push(Courses.findOne({
        studipId: studentCourses[i]
      }));
    }

    return tmp;
  },
  "students.getTasks": function (tasks, _id) {
    Students.update(_id, {
      $addToSet: {
        tasks
      }
    });
  },
  "students.getNextTask": function (packageName, sequenceId, _id) {
    let tasks = Tasks.find({
      package: packageName,
      sequenceId: sequenceId
    }).fetch()[0];
    Students.update(_id, {
      $addToSet: {
        tasks
      }
    });
  },
  //Gets a package and it's first training
  "students.getPackage": function (packageName, _id) {
    var packageObj = Package.findOne({
      name: packageName
    });

    try {
      Students.update(_id, {
        $addToSet: {
          currentPackage: packageObj
        }
      });
      return true;
    } catch (e) {
      console.log(e);
    }
  },
  "students.initTraining": function (training, _id) {
    try {
      Students.update(_id, {
        $set: {
          currentTraining: training
        }
      });
      return Students.find({
        _id: _id
      }).fetch()[0];
    } catch (e) {
      console.log(e);
    }
  },
  "students.setLastActiveTaskId": function (taskId, _id) {
    Students.update(_id, {
      $addToSet: {
        lastActiveTaskId: taskId
      }
    });
  },
  "students.solveTraining": function (student, training) {
    var studentUpdates = {
      $addToSet: {
        solvedTraining: training
      },
      $pull: {
        currentTraining: {
          name: training.name,
          sequenceId: training.sequenceId
        }
      }
    };
    Students.update({
      _id: student._id
    }, studentUpdates);
    Students.update({
      _id: student._id
    }, {
      $inc: {
        currentSequenceId: 1
      }
    });
  },
  "students.showNextTask": function (student) {
    let task = Tasks.find({
      package: student.currentPackage[0].name,
      sequenceId: student.currentSequenceId + 1
    }).fetch()[0];

    if (task && task.requires) {
      if (!checkTaskRequirements(task.requires, student.solvedTasks)) {
        Students.update({
          _id: student._id
        }, {
          $inc: {
            currentSequenceId: 2
          }
        });
        return;
      }
    }

    Students.update({
      _id: student._id
    }, {
      $inc: {
        currentSequenceId: 1
      }
    });
  },
  "students.showPreviousTask": function (student) {
    let task = Tasks.find({
      package: student.currentPackage[0].name,
      sequenceId: student.currentSequenceId - 1
    }).fetch()[0];

    if (task.requires) {
      if (!checkTaskRequirements(task.requires, student.solvedTasks)) {
        Students.update({
          _id: student._id
        }, {
          $inc: {
            currentSequenceId: -2
          }
        });
        return;
      }
    }

    Students.update({
      _id: student._id
    }, {
      $inc: {
        currentSequenceId: -1
      }
    });
  }
});

if (Meteor.isServer) {
  // pupil
  Meteor.publish("student", () => {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["student"])) {
      return Students.find({
        userId: Meteor.userId()
      });
    }

    throw new Meteor.Error("Access denied!");
  }); // teacher

  Meteor.publish("pupilsByClassId", classId => {
    const teacher = Teachers.findOne({
      userId: Meteor.userId()
    });

    if (teacher && teacher.classrooms.includes(classId)) {
      return Pupils.find({
        classId
      });
    }

    throw new Meteor.Error("Access denied!");
  }); // pupil

  Meteor.publish("companyMates", () => {
    const pupil = Pupils.findOne({
      userId: Meteor.userId()
    });

    if (pupil) {
      return Pupils.find({
        companyId: pupil.companyId
      });
    }

    throw new Meteor.Error("Access denied!");
  }); // admin

  Meteor.publish("pupilsOfTeacher", () => {
    const teacher = Teachers.findOne({
      userId: Meteor.userId()
    });

    if (teacher) {
      return Pupils.find({
        classId: {
          $in: teacher.classrooms
        }
      });
    }

    throw new Meteor.Error("Access denied!");
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tasks.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/tasks.js                                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Tasks: () => Tasks
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let shortid;
module.link("shortid", {
  default(v) {
    shortid = v;
  }

}, 3);
const Tasks = new Mongo.Collection("tasks");
const taskSchema = new SimpleSchema({
  taskId: {
    type: String,
    optional: true
  },
  shortDescription: {
    type: String
  },
  type: {
    type: String
  },
  trainingId: {
    type: String,
    optional: true
  },
  package: {
    type: String
  },
  filePrefix: {
    type: String,
    optional: true
  },
  solution1: {
    type: Array,
    optional: true
  },
  solution2: {
    type: Array,
    optional: true
  },
  solution3: {
    type: Array,
    optional: true
  },
  solution4: {
    type: Array,
    optional: true
  },
  renderfiles: {
    type: Array,
    optional: true
  },
  "renderfiles.$": {
    type: String,
    optional: true
  },
  "solution1.$": {
    type: String,
    optional: true
  },
  "solution2.$": {
    type: String,
    optional: true
  },
  "solution3.$": {
    type: String,
    optional: true
  },
  "solution4.$": {
    type: String,
    optional: true
  },
  description: {
    type: String
  },
  instruction: {
    type: String
  },
  credits: {
    type: Number
  },
  minLevel: {
    type: Number
  },
  //empfohlenes Level
  level: {
    type: Number
  },
  taskurl: {
    type: String,
    optional: true
  },
  preKnowledge: {
    type: String,
    optional: true
  },
  //true wenn grading automatisch ist, false sonst
  autoGrading: {
    type: Boolean,
    optional: true
  }
}).newContext();
Meteor.methods({
  "tasks.insert"(task) {
    Tasks.insert(task);
  }

});

if (Meteor.isServer) {
  Meteor.publish("tasks", () => {
    return Tasks.find({});
  });
  Meteor.publish("tasksByIds", taskIds => {
    return Tasks.find({
      taskId: {
        $in: taskIds
      }
    });
  });
  Meteor.publish("taskById", function (taskId) {
    return Tasks.find({
      taskId: taskId
    });
  });
  Meteor.publish("tasksByPackage", name => {
    return Tasks.find({
      taskPackage: name
    });
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"teachers.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/teachers.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Teachers: () => Teachers
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 3);
let Students;
module.link("./students", {
  Students(v) {
    Students = v;
  }

}, 4);
let Classrooms;
module.link("./courses", {
  Classrooms(v) {
    Classrooms = v;
  }

}, 5);
const Teachers = new Mongo.Collection("teachers");

if (Meteor.isServer) {
  // teacher
  Meteor.publish("teacher", function (teacherId) {
    return Teachers.find({
      studipUserId: teacherId
    });
  });
  Meteor.publish("teacherByUserId", function (userId) {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["teacher"])) {
      return Teachers.find({
        userId: Meteor.userId()
      });
    }

    throw new Meteor.Error("Acces denied!");
  }); // admin

  Meteor.publish("allTeacher", function () {
    if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["yadmin"])) {
      return Teachers.find({});
    }

    throw new Meteor.Error("Access denied!");
  });
}

Meteor.methods({
  "teachers.insert": function (userId, studipUserId) {
    Teachers.insert({
      userId: userId,
      studipUserId: studipUserId,
      courses: []
    });
  },
  "teachers.delete": function (userId) {
    if (Meteor.isServer) {
      let teacher = null;

      if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["ppadmin"])) {
        teacher = Teachers.findOne({
          userId
        });
        if (!teacher) throw new Meteor.Error("Teacher doesn't exist!");
      } else if (Meteor.userId() && Roles.userIsInRole(Meteor.user(), ["teacher"])) {
        teacher = Teachers.findOne({
          userId: Meteor.userId()
        });
      }

      if (teacher) {
        const classrooms = Classrooms.find({
          _id: {
            $in: teacher.classrooms
          }
        });
        classrooms.forEach(classroom => {
          Companies.remove({
            _id: {
              $in: classroom.companies
            }
          });
          Students.remove({
            userId: {
              $in: classroom.students
            }
          });
          Meteor.users.remove({
            _id: {
              $in: classroom.students
            }
          });
        });
        Classrooms.remove({
          _id: {
            $in: teacher.classrooms
          }
        });
        Teachers.remove({
          userId: teacher.userId
        });
        Meteor.users.remove({
          _id: teacher.userId
        });
      } else {
        throw new Meteor.Error("Access denied!");
      }
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tokens.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/tokens.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Tokens: () => Tokens
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 3);
const Tokens = new Mongo.Collection("tokens");

if (Meteor.isServer) {
  Meteor.publish("tokenByUser", function () {
    return Tokens.find({
      userId: Meteor.userId()
    });
  });
  Meteor.methods({
    "tokens.insert": function (userId, token) {
      Tokens.insert({
        userId: userId,
        token: token
      });
    }
  });
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"training.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/training.js                                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Training: () => Training
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 2);
const Training = new Mongo.Collection("training");
const trainingSchema = new SimpleSchema({
  name: {
    type: String
  },
  package: {
    type: String
  },
  imageVideo: {
    type: String,
    optional: true
  },
  discount: {
    type: Boolean
  },
  format: {
    type: String
  }
}).newContext();

if (Meteor.isServer) {
  Meteor.publish("training", () => {
    return Training.find({});
  });
}

Meteor.methods({
  "training.insert"(training) {
    Training.insert(training);
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"users.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/api/users.js                                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 2);
let Pupils;
module.link("./students", {
  Pupils(v) {
    Pupils = v;
  }

}, 3);
let Teachers;
module.link("./teachers", {
  Teachers(v) {
    Teachers = v;
  }

}, 4);
let Courses;
module.link("./courses", {
  Courses(v) {
    Courses = v;
  }

}, 5);
Accounts.validateNewUser(user => {
  return true;
});

if (Meteor.isServer) {
  // TODO:
  Meteor.publish("usersByClassroom", function (classId) {});
  Meteor.publish("userByName", function (userName) {
    return Meteor.users.findOne({
      username: userName
    });
  });
}

Meteor.methods({
  // perform a basic auth user-request to verify a studip-user
  "users.auth": function (token, email, password) {
    try {
      const result = HTTP.call("GET", "http://localhost/studip/plugins.php/argonautsplugin/users/me", {
        headers: {
          Authorization: token
        }
      });
      var userData = JSON.parse(result.content);
      var studipUserId = userData.data.id;

      if (Meteor.users.findOne({
        username: email
      })) {
        var user = Meteor.users.findOne({
          username: email
        });
      } else {
        const userId = Accounts.createUser({
          username: email,
          password: password
        });
      }

      var results = [result, studipUserId];
      return results;
    } catch (e) {
      console.log(e); // Got a network error, timeout, or HTTP error in the 400 or 500 range.

      return false;
    }
  },
  "users.teachersInsert": function (username, studipUserId) {
    var teacherId = Meteor.users.findOne({
      username: username
    })._id;

    Roles.addUsersToRoles(teacherId, "teacher");
    Meteor.call("teachers.insert", teacherId, studipUserId);
    return teacherId;
  },
  "users.studentInsert": function (username, studipUserId) {
    var studentId = Meteor.users.findOne({
      username: username
    })._id;

    Roles.addUsersToRoles(studentId, "student");
    Meteor.call("students.insert", studentId, studipUserId);
    return studentId;
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"solutionHandling":{"cardSaver.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/solutionHandling/cardSaver.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  saveCard: () => saveCard
});

function saveCard(studentId, taskId) {
  const task = taskId;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"multiSolver.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/solutionHandling/multiSolver.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  checkMulti: () => checkMulti
});

function checkMulti(question, studentSolution, correctSolution) {
  const answers = question.AnswerSet;
  let falseCount = 0; // Get correct question from array

  if (studentSolution.length > 1) {
    studentSolution = studentSolution.filter(elem => {
      return elem.id.toString() === question.QuestionId.toString();
    });
  }

  for (let i = 0; i < answers.length; i++) {
    let answerIsSelected = studentSolution.length > 0 ? studentSolution[0].values.includes(answers[i]) : false;
    let answerIsCorrect = correctSolution.correct.includes(answers[i]);

    if (answerIsSelected != answerIsCorrect) {
      let answerNeutral = correctSolution.neutral !== undefined && correctSolution.neutral.includes(answers[i]);

      if (!answerNeutral) {
        falseCount++;
      }
    }
  }

  let falseQuestions = [];

  if (falseCount > 0) {
    falseQuestions.push(correctSolution);
  }

  let retval = {
    falseCount,
    totalAnswerCount: answers.length,
    neutralAnswers: correctSolution.neutral,
    falseQuestions
  };
  return retval;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"taskSolver.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/solutionHandling/taskSolver.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  solveTask: () => solveTask
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let equals;
module.link("fast-deep-equal", {
  default(v) {
    equals = v;
  }

}, 1);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 2);
let Students;
module.link("../../imports/api/students", {
  Students(v) {
    Students = v;
  }

}, 3);
let Tasks;
module.link("../../imports/api/tasks", {
  Tasks(v) {
    Tasks = v;
  }

}, 4);

function solveTask(studentId, taskId, solvedPercentage) {
  const student = Students.findOne({
    _id: studentId
  });
  let task = getTask(studentId, taskId);
  if (!task) return;
  updateStudentExperience(student, task, solvedPercentage);
  updateStudentCredits(student, task, solvedPercentage);
  setTaskSolved(student, task);
}

/**
 * Get Task from Student by studentId and taskId
 * @param {Number} studentId
 * @param {Number} taskId
 */
function getTask(studentId, taskId) {
  try {
    var currentTask = Students.find({
      _id: studentId,
      "tasks.taskId": taskId
    }, {
      fields: {
        "tasks.$": 1,
        _id: 0
      }
    }).fetch()[0];
    if (!currentTask) return null;
    return currentTask.tasks[0];
  } catch (error) {
    console.log(error);
  }
}
/**
 * Set endTime and solved flag of task
 * @param {*} student
 * @param {*} task
 */


function setTaskSolved(student, task) {
  var endTime = moment().format("dddd, MMMM, Do YYYY, h:mm:ss a");
  task["endTime"] = endTime;
  task["taskState"] = "solved";
  updateStudentData(student._id, {
    $push: {
      solvedTasks: task
    },
    $set: {
      lastActiveTaskId: task.taskId
    },
    $pull: {
      tasks: {
        taskId: task.taskId
      }
    },
    $inc: {
      currentSequenceId: 1
    }
  });
}
/**
 * Update the students experience and check for level-up
 * @param {*} student
 * @param {*} task
 * @param {Number} solvedPercentage
 */


function updateStudentExperience(student, task, solvedPercentage) {
  let taskExp = task.credits;
  let level = student.level; // Experience needed to level up

  const neededExp = level * level * 10; // Check if solvedPercentage is a not null or is 0

  if (solvedPercentage || solvedPercentage == 0) {
    taskExp = Math.round(taskExp * solvedPercentage);
  }

  let newExp = student.exp + taskExp;

  if (newExp > neededExp) {
    level++;
    newExp -= neededExp;
  }

  updateStudentData(student._id, {
    $set: {
      level: level,
      exp: newExp
    }
  });
}
/**
 * Increment the students credits
 * @param {*} student
 * @param {*} task
 * @param {Number} solvedPercentage
 */


function updateStudentCredits(student, task, solvedPercentage) {
  let newCredits = task.credits;

  if (solvedPercentage || solvedPercentage == 0) {
    newCredits = Math.round(newCredits * solvedPercentage);
  }

  updateStudentData(student._id, {
    $inc: {
      credits: newCredits
    }
  });
}
/**
 * Update student in mongo
 * @param {Number} studentId
 * @param {*} data
 */


function updateStudentData(studentId, data) {
  Students.update({
    _id: studentId
  }, data);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"solutionHandling.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/solutionHandling.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let equals;
module.link("fast-deep-equal", {
  default(v) {
    equals = v;
  }

}, 1);
let saveCard;
module.link("./solutionHandling/cardSaver", {
  saveCard(v) {
    saveCard = v;
  }

}, 2);
let solveTask;
module.link("./solutionHandling/taskSolver", {
  solveTask(v) {
    solveTask = v;
  }

}, 3);
let checkMulti;
module.link("./solutionHandling/multiSolver", {
  checkMulti(v) {
    checkMulti = v;
  }

}, 4);
let Students;
module.link("../imports/api/students", {
  Students(v) {
    Students = v;
  }

}, 5);
var Solutions = JSON.parse(Assets.getText("solutions.json"));
Meteor.methods({
  "solutionHandler.submitCard"(studentId, task) {
    saveCard(studentId, task.taskId);
    solveTask(studentId, task.taskId, 100);
  },

  "solutionHandler.submitDrag"(studentSolution, studentId, task, solvedPercentage) {
    console.log("enteredd");
    console.log(studentSolution);

    if (solvedPercentage !== undefined) {
      solveTask(studentId, task.taskId, solvedPercentage);
    } // var correct = equals(studentSolution, Solutions[task.taskId]);


    var correct = true;
    studentSolution.map(solution => {
      solution.children.map((child, index) => {
        if (task.multipleColumns) {
          if (solution.categorie != child.solution) {
            correct = false;
          }
        } else {
          if (child.solution != task.solArray[index]) {
            correct = false;
          }
        }
      });
    });

    if (correct) {
      solveTask(studentId, task.taskId);
    }

    return correct;
  },

  "solutionHandler.submitCloze"(studentSolution, studentId, task, solvedPercentage) {
    if (solvedPercentage !== undefined) {
      solveTask(studentId, task.taskId, solvedPercentage);
    }

    let correctAnswers = [];
    let allCorrect = true;

    for (let i = 0; i < studentSolution.length; i++) {
      if (studentSolution[i].toString().toLowerCase() === Solutions[task.taskId][i].toString().toLowerCase()) {
        correctAnswers.push(true);
      } else {
        correctAnswers.push(false);
        allCorrect = false;
      }
    }

    if (allCorrect) {
      solveTask(studentId, task.taskId);
    }

    return correctAnswers;
  },

  "solutionHandler.submitTag"(studentSolution, studentId, task) {
    var correct = !Solutions[task.taskId] || studentSolution.length == Solutions[task.taskId].length;

    if (correct) {
      solveTask(studentId, task.taskId);
    }

    return correct;
  },

  "solutionHandler.submitMemory"(studentSolution, studentId, task) {
    var correct = studentSolution.length == task.content[0].keywords.length * 2;

    if (correct) {
      solveTask(studentId, task.taskId);
    }

    return correct;
  },

  "solutionHandler.submitMulti"(studentSolution, studentId, task, questionIndex, solvedPercentage) {
    if (solvedPercentage !== undefined) {
      solveTask(studentId, task.taskId, solvedPercentage);
      return null;
    }

    let solution = Solutions[task.taskId];
    if (!solution) return null;
    const currentSolution = solution.find(element => {
      if (task.content) {
        return element.id.toString() === task.content[questionIndex].QuestionId.toString();
      } else {
        return element.id.toString() === task.QuestionId.toString();
      }
    }); // question has no "correct" answer

    if (currentSolution.correct[0] === "free") {
      return currentSolution.correct.concat(studentSolution);
    }

    let retval = checkMulti(task.content ? task.content[questionIndex] : task, studentSolution, currentSolution);

    if (task.hasNext) {
      return Object.assign(retval, {
        next: true
      });
    }

    if (retval.falseCount === 0) {
      solveTask(studentId, task.taskId);
    }

    return retval;
  },

  "solutionHandler.submitSurvey"(surveyData, studentId, task) {
    // Mark surveyTask as Solved and move it into solvedTaskArray
    solveTask(studentId, task.taskId); //Get updated SolvedTasks from Student

    let currentStudentData = Students.findOne({
      _id: studentId
    });
    let currentSurveyTask = currentStudentData.solvedTasks.find(elem => elem.taskId === task.taskId); // Set surveyData in SolvedTask (Survey)

    currentSurveyTask.surveyData = surveyData;
    currentSurveyTask.content = surveyData.content; // Add new surveyData to Meteor

    const surveyObj = {
      surveyId: task.taskId,
      title: task.title,
      package: task.package,
      question: task.question,
      answers: task.keywords,
      solution: surveyData.checkedAnswers,
      comment: surveyData.content
    };
    Students.update({
      _id: studentId
    }, {
      $set: {
        solvedSurveys: surveyObj
      }
    });
    return true;
  },

  "solutionHandler.checkMulti"(studentSolution, task, questionIndex) {
    let solution = Solutions[task.taskId];
    if (!solution) return null;
    const currentSolution = solution.find(element => {
      if (task.content) {
        return element.id.toString() === task.content[questionIndex].QuestionId.toString();
      } else {
        return element.id.toString() === task.QuestionId.toString();
      }
    }); // question has no "correct" answer

    if (currentSolution.correct[0] === "free") {
      return currentSolution.correct.concat(studentSolution);
    }

    let retval = checkMulti(task.content ? task.content[questionIndex] : task, studentSolution, currentSolution);

    if (task.hasNext) {
      return Object.assign(retval, {
        next: true
      });
    }

    return retval;
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let resetDatabase;
module.link("../imports/startup/server/databaseHandling", {
  resetDatabase(v) {
    resetDatabase = v;
  }

}, 2);
module.link("./solutionHandling");
module.link("../imports/api/users");
module.link("../imports/api/teachers");
module.link("../imports/api/courses");
module.link("../imports/api/tokens");
Meteor.startup(() => {
  // code to run on server at startup
  resetDatabase();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9hZGRHYW1lRGF0YS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9hZGRQYWNrYWdlVGFza3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvYWRkUGFja2FnZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvZGF0YWJhc2VIYW5kbGluZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY291cnNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcGFja2FnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvc3R1ZGVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3Rhc2tzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90ZWFjaGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdG9rZW5zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFpbmluZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdXNlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zb2x1dGlvbkhhbmRsaW5nL2NhcmRTYXZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3NvbHV0aW9uSGFuZGxpbmcvbXVsdGlTb2x2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zb2x1dGlvbkhhbmRsaW5nL3Rhc2tTb2x2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zb2x1dGlvbkhhbmRsaW5nLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJNZXRlb3IiLCJtb2R1bGUiLCJsaW5rIiwidiIsImV4cG9ydCIsImFkZFBhY2thZ2VUYXNrcyIsImNyZWF0ZURyYWdUYXNrIiwidGFza1NwZWNzIiwic2F2ZSIsImhlbHAiLCJjcmVhdGVUYWdUYXNrIiwicmVhZEZpbmlzaGVkIiwiY3JlYXRlQ2xvemVUYXNrIiwiY3JlYXRlTWVtb3J5IiwiY3JlYXRlTXVsdGlDaG9pY2UiLCJjcmVhdGVTdXJ2ZXlUYXNrIiwiYWRkVGFza3MiLCJwYWNrYWdlTmFtZSIsInBhdGgiLCJ0YXNrcyIsIkpTT04iLCJwYXJzZSIsIkFzc2V0cyIsImdldFRleHQiLCJ0cmFpbmluZ3MiLCJpIiwicGFyc2VJbnQiLCJpc1RyYWluaW5nIiwicHVzaCIsIm5ld3Rhc2siLCJmaWxlUHJlZml4IiwiY2FsbCIsImFkZFBhY2thZ2VzIiwiVGFza3MiLCJUcmFpbmluZyIsIlBhY2thZ2VzIiwidHJhaW5pbmdTcGVjcyIsInBhY2thZ2VzIiwibGVuZ3RoIiwicmVzZXREYXRhYmFzZSIsIkFjY291bnRzIiwiUm9sZXMiLCJzaG9ydGlkIiwiZGVmYXVsdCIsIlRlYWNoZXJzIiwiQ291cnNlcyIsIlN0dWRlbnRzIiwiUGFja2FnZSIsImFkZEdhbWVEYXRhIiwiY2xlYXJEYXRhYmFzZSIsInNldHVwQWRtaW4iLCJpc0RldmVsb3BtZW50Iiwic2V0dXBUZXN0Q291cnNlIiwiaW5pdFBhY2thZ2VzIiwic2V0dXBTdHVkZW50cyIsInNldHVwVGVhY2hlciIsImZpbmQiLCJmZXRjaCIsImNvbnRlbnQiLCJ0bXAxIiwidG1wMiIsInBuYW1lIiwibmFtZSIsImoiLCJwYXJlbnRJZCIsInNlcXVlbmNlSWQiLCJwYWNrYWdlVXBkYXRlcyIsIiRzZXQiLCJ1cGRhdGUiLCJfaWQiLCJrIiwidHJhaW5pbmdJZCIsInNraXBTZXR1cCIsImVtYWlsIiwicGFzc3dvcmQiLCJ0ZWFjaGVySWQiLCJjcmVhdGVVc2VyIiwiYWRkVXNlcnNUb1JvbGVzIiwiaW5zZXJ0IiwidXNlcklkIiwiY291cnNlcyIsImNvdXJzZUlkIiwiZ2VuZXJhdGUiLCJjb3Vyc2VOYW1lIiwicHVwaWxzIiwiZmluZE9uZSIsInBwRW1haWwiLCJyZXMiLCJ1c2VybmFtZSIsInBwSWQiLCJmaW5kVXNlckJ5RW1haWwiLCJzdHVkaXBVc2VySWQiLCJ0YXNrIiwicGFja2FnZSIsImNyZWRpdHMiLCJleHAiLCJsZXZlbCIsImVhcm5pbmciLCJsYXN0QWN0aXZlVGFza0lkIiwic29sdmVkVGFza3MiLCJsZWFybkNhcmRzIiwic29sdmVkU3VydmV5cyIsImN1cnJlbnRTZXF1ZW5jZUlkIiwiY3VycmVudFBhY2thZ2UiLCJjdXJyZW50VHJhaW5pbmciLCJzb2x2ZWRUcmFpbmluZyIsInJlbW92ZSIsInVzZXJzIiwiTW9uZ28iLCJTaW1wbGVTY2hlbWEiLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJyYXdDb2xsZWN0aW9uIiwiZW5zdXJlSW5kZXgiLCJ1bmlxdWUiLCJwdWJsaXNoIiwidXNlcklzSW5Sb2xlIiwidXNlciIsInN0dWRlbnRJZCIsIkVycm9yIiwiY2xhc3NOYW1lIiwic3R1ZGVudCIsImNsYXNzSWQiLCJtZXRob2RzIiwic3R1ZGlwSWQiLCJzdHVkZW50cyIsInN0YXJ0ZWQiLCJwYXRocyIsIiRhZGRUb1NldCIsInRva2VuIiwiY291cnNlUmF3RGF0YSIsIkhUVFAiLCJoZWFkZXJzIiwiQXV0aG9yaXphdGlvbiIsImNvdXJzZURhdGEiLCJtZW1iZXJzaGlwcyIsImRhdGEiLCJ0bXBDb3Vyc2UiLCJtZW1iZXJzaGlwc1JhdyIsImlkIiwibWVtYmVyc2hpcERhdGEiLCJtZW1iZXJTdGF0dXMiLCJhdHRyaWJ1dGVzIiwic3RhdHVzIiwidGFyZ2V0Y291cnNlSWQiLCJzcGxpdCIsInZhbGlkRG96ZW50IiwiZSIsImNvbnNvbGUiLCJsb2ciLCJ0cmFpbmluZ1NjaGVtYSIsInR5cGUiLCJTdHJpbmciLCJBcnJheSIsIm5ld0NvbnRleHQiLCJ0cmFpbmluZyIsIkNsYXNzcm9vbXMiLCJjaGVja1Rhc2tSZXF1aXJlbWVudHMiLCJyZXEiLCJhbGxSZXF1aXJlZEZvdW5kIiwiZm91bmQiLCJlbGVtIiwidGFza0lkIiwidW5kZWZpbmVkIiwic3ViamVjdCIsInN0YXRlbWVudCIsImV4YW1wbGUiLCJpbWFnZSIsImxlYXJuQ2FyZE9iaiIsInN0dWRlbnRDb3Vyc2VzIiwidG1wIiwicGFja2FnZU9iaiIsInN0dWRlbnRVcGRhdGVzIiwiJHB1bGwiLCIkaW5jIiwicmVxdWlyZXMiLCJ0ZWFjaGVyIiwiY2xhc3Nyb29tcyIsImluY2x1ZGVzIiwiUHVwaWxzIiwicHVwaWwiLCJjb21wYW55SWQiLCIkaW4iLCJ0YXNrU2NoZW1hIiwib3B0aW9uYWwiLCJzaG9ydERlc2NyaXB0aW9uIiwic29sdXRpb24xIiwic29sdXRpb24yIiwic29sdXRpb24zIiwic29sdXRpb240IiwicmVuZGVyZmlsZXMiLCJkZXNjcmlwdGlvbiIsImluc3RydWN0aW9uIiwiTnVtYmVyIiwibWluTGV2ZWwiLCJ0YXNrdXJsIiwicHJlS25vd2xlZGdlIiwiYXV0b0dyYWRpbmciLCJCb29sZWFuIiwidGFza0lkcyIsInRhc2tQYWNrYWdlIiwiZm9yRWFjaCIsImNsYXNzcm9vbSIsIkNvbXBhbmllcyIsImNvbXBhbmllcyIsIlRva2VucyIsImltYWdlVmlkZW8iLCJkaXNjb3VudCIsImZvcm1hdCIsInZhbGlkYXRlTmV3VXNlciIsInVzZXJOYW1lIiwicmVzdWx0IiwidXNlckRhdGEiLCJyZXN1bHRzIiwic2F2ZUNhcmQiLCJjaGVja011bHRpIiwicXVlc3Rpb24iLCJzdHVkZW50U29sdXRpb24iLCJjb3JyZWN0U29sdXRpb24iLCJhbnN3ZXJzIiwiQW5zd2VyU2V0IiwiZmFsc2VDb3VudCIsImZpbHRlciIsInRvU3RyaW5nIiwiUXVlc3Rpb25JZCIsImFuc3dlcklzU2VsZWN0ZWQiLCJ2YWx1ZXMiLCJhbnN3ZXJJc0NvcnJlY3QiLCJjb3JyZWN0IiwiYW5zd2VyTmV1dHJhbCIsIm5ldXRyYWwiLCJmYWxzZVF1ZXN0aW9ucyIsInJldHZhbCIsInRvdGFsQW5zd2VyQ291bnQiLCJuZXV0cmFsQW5zd2VycyIsInNvbHZlVGFzayIsImVxdWFscyIsInNvbHZlZFBlcmNlbnRhZ2UiLCJnZXRUYXNrIiwidXBkYXRlU3R1ZGVudEV4cGVyaWVuY2UiLCJ1cGRhdGVTdHVkZW50Q3JlZGl0cyIsInNldFRhc2tTb2x2ZWQiLCJjdXJyZW50VGFzayIsImZpZWxkcyIsImVycm9yIiwiZW5kVGltZSIsIm1vbWVudCIsInVwZGF0ZVN0dWRlbnREYXRhIiwiJHB1c2giLCJ0YXNrRXhwIiwibmVlZGVkRXhwIiwiTWF0aCIsInJvdW5kIiwibmV3RXhwIiwibmV3Q3JlZGl0cyIsIlNvbHV0aW9ucyIsIm1hcCIsInNvbHV0aW9uIiwiY2hpbGRyZW4iLCJjaGlsZCIsImluZGV4IiwibXVsdGlwbGVDb2x1bW5zIiwiY2F0ZWdvcmllIiwic29sQXJyYXkiLCJjb3JyZWN0QW5zd2VycyIsImFsbENvcnJlY3QiLCJ0b0xvd2VyQ2FzZSIsImtleXdvcmRzIiwicXVlc3Rpb25JbmRleCIsImN1cnJlbnRTb2x1dGlvbiIsImVsZW1lbnQiLCJjb25jYXQiLCJoYXNOZXh0IiwiT2JqZWN0IiwiYXNzaWduIiwibmV4dCIsInN1cnZleURhdGEiLCJjdXJyZW50U3R1ZGVudERhdGEiLCJjdXJyZW50U3VydmV5VGFzayIsInN1cnZleU9iaiIsInN1cnZleUlkIiwidGl0bGUiLCJjaGVja2VkQW5zd2VycyIsImNvbW1lbnQiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQsRTs7Ozs7Ozs7Ozs7QUNBWEYsTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQ0MsaUJBQWUsRUFBQyxNQUFJQTtBQUFyQixDQUFkO0FBQXFELElBQUlMLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7O0FBRWhFLFNBQVNHLGNBQVQsQ0FBd0JDLFNBQXhCLEVBQW1DO0FBQ2pDQSxXQUFTLENBQUMsUUFBRCxDQUFULEdBQXNCLElBQXRCO0FBQ0FBLFdBQVMsQ0FBQyxRQUFELENBQVQsR0FBc0JBLFNBQVMsQ0FBQyxRQUFELENBQS9CO0FBQ0FBLFdBQVMsQ0FBQyxNQUFELENBQVQsR0FBb0IsTUFBcEI7QUFDQUEsV0FBUyxDQUFDLFNBQUQsQ0FBVCxHQUF1QkEsU0FBUyxDQUFDLFNBQUQsQ0FBaEM7QUFDQUEsV0FBUyxDQUFDLGFBQUQsQ0FBVCxHQUEyQixJQUEzQjtBQUNBQSxXQUFTLENBQUMsWUFBRCxDQUFULEdBQTBCQSxTQUFTLENBQUMsWUFBRCxDQUFuQztBQUNBQSxXQUFTLENBQUMsV0FBRCxDQUFULEdBQXlCO0FBQUVDLFFBQUksRUFBRSxLQUFSO0FBQWVDLFFBQUksRUFBRTtBQUFyQixHQUF6QjtBQUVBLFNBQU9GLFNBQVA7QUFDRDs7QUFDRCxTQUFTRyxhQUFULENBQXVCSCxTQUF2QixFQUFrQztBQUNoQ0EsV0FBUyxDQUFDLFFBQUQsQ0FBVCxHQUFzQixJQUF0QjtBQUNBQSxXQUFTLENBQUMsUUFBRCxDQUFULEdBQXNCQSxTQUFTLENBQUMsUUFBRCxDQUEvQjtBQUNBQSxXQUFTLENBQUMsTUFBRCxDQUFULEdBQW9CLEtBQXBCO0FBQ0FBLFdBQVMsQ0FBQyxTQUFELENBQVQsR0FBdUJBLFNBQVMsQ0FBQyxTQUFELENBQWhDO0FBQ0FBLFdBQVMsQ0FBQyxTQUFELENBQVQsR0FBdUJBLFNBQVMsQ0FBQyxTQUFELENBQWhDO0FBQ0FBLFdBQVMsQ0FBQyxhQUFELENBQVQsR0FBMkIsSUFBM0I7QUFDQUEsV0FBUyxDQUFDLFlBQUQsQ0FBVCxHQUEwQkEsU0FBUyxDQUFDLFlBQUQsQ0FBbkM7QUFDQUEsV0FBUyxDQUFDLFdBQUQsQ0FBVCxHQUF5QjtBQUFFQyxRQUFJLEVBQUUsS0FBUjtBQUFlQyxRQUFJLEVBQUUsS0FBckI7QUFBNEJFLGdCQUFZLEVBQUU7QUFBMUMsR0FBekI7QUFFQSxTQUFPSixTQUFQO0FBQ0Q7O0FBRUQsU0FBU0ssZUFBVCxDQUF5QkwsU0FBekIsRUFBb0M7QUFDbENBLFdBQVMsQ0FBQyxRQUFELENBQVQsR0FBc0IsSUFBdEI7QUFDQUEsV0FBUyxDQUFDLFFBQUQsQ0FBVCxHQUFzQkEsU0FBUyxDQUFDLFFBQUQsQ0FBL0I7QUFDQUEsV0FBUyxDQUFDLE1BQUQsQ0FBVCxHQUFvQixPQUFwQjtBQUNBQSxXQUFTLENBQUMsU0FBRCxDQUFULEdBQXVCQSxTQUFTLENBQUMsU0FBRCxDQUFoQztBQUNBQSxXQUFTLENBQUMsU0FBRCxDQUFULEdBQXVCQSxTQUFTLENBQUMsU0FBRCxDQUFoQztBQUNBQSxXQUFTLENBQUMsYUFBRCxDQUFULEdBQTJCLElBQTNCO0FBQ0FBLFdBQVMsQ0FBQyxZQUFELENBQVQsR0FBMEJBLFNBQVMsQ0FBQyxZQUFELENBQW5DO0FBQ0FBLFdBQVMsQ0FBQyxXQUFELENBQVQsR0FBeUI7QUFBRUMsUUFBSSxFQUFFLEtBQVI7QUFBZUMsUUFBSSxFQUFFO0FBQXJCLEdBQXpCO0FBRUEsU0FBT0YsU0FBUDtBQUNEOztBQUVELFNBQVNNLFlBQVQsQ0FBc0JOLFNBQXRCLEVBQWlDO0FBQy9CQSxXQUFTLENBQUMsUUFBRCxDQUFULEdBQXNCLElBQXRCO0FBQ0FBLFdBQVMsQ0FBQyxRQUFELENBQVQsR0FBc0JBLFNBQVMsQ0FBQyxRQUFELENBQS9CO0FBQ0FBLFdBQVMsQ0FBQyxNQUFELENBQVQsR0FBb0IsUUFBcEI7QUFDQUEsV0FBUyxDQUFDLFNBQUQsQ0FBVCxHQUF1QkEsU0FBUyxDQUFDLFNBQUQsQ0FBaEM7QUFDQUEsV0FBUyxDQUFDLFNBQUQsQ0FBVCxHQUF1QkEsU0FBUyxDQUFDLFNBQUQsQ0FBaEM7QUFDQUEsV0FBUyxDQUFDLGFBQUQsQ0FBVCxHQUEyQixJQUEzQjtBQUNBQSxXQUFTLENBQUMsWUFBRCxDQUFULEdBQTBCQSxTQUFTLENBQUMsWUFBRCxDQUFuQztBQUNBQSxXQUFTLENBQUMsV0FBRCxDQUFULEdBQXlCO0FBQUVDLFFBQUksRUFBRSxLQUFSO0FBQWVDLFFBQUksRUFBRTtBQUFyQixHQUF6QjtBQUVBLFNBQU9GLFNBQVA7QUFDRDs7QUFFRCxTQUFTTyxpQkFBVCxDQUEyQlAsU0FBM0IsRUFBc0M7QUFDcENBLFdBQVMsQ0FBQyxRQUFELENBQVQsR0FBc0IsSUFBdEI7QUFDQUEsV0FBUyxDQUFDLFFBQUQsQ0FBVCxHQUFzQkEsU0FBUyxDQUFDLFFBQUQsQ0FBL0I7QUFDQUEsV0FBUyxDQUFDLE1BQUQsQ0FBVCxHQUFvQixhQUFwQjtBQUNBQSxXQUFTLENBQUMsU0FBRCxDQUFULEdBQXVCQSxTQUFTLENBQUMsU0FBRCxDQUFoQztBQUNBQSxXQUFTLENBQUMsU0FBRCxDQUFULEdBQXVCQSxTQUFTLENBQUMsU0FBRCxDQUFoQztBQUNBQSxXQUFTLENBQUMsYUFBRCxDQUFULEdBQTJCLElBQTNCO0FBQ0FBLFdBQVMsQ0FBQyxZQUFELENBQVQsR0FBMEJBLFNBQVMsQ0FBQyxZQUFELENBQW5DO0FBQ0FBLFdBQVMsQ0FBQyxXQUFELENBQVQsR0FBeUI7QUFBRUMsUUFBSSxFQUFFLEtBQVI7QUFBZUMsUUFBSSxFQUFFO0FBQXJCLEdBQXpCO0FBRUEsU0FBT0YsU0FBUDtBQUNEOztBQUVELFNBQVNRLGdCQUFULENBQTBCUixTQUExQixFQUFxQztBQUNuQ0EsV0FBUyxDQUFDLFFBQUQsQ0FBVCxHQUFzQixJQUF0QjtBQUNBQSxXQUFTLENBQUMsUUFBRCxDQUFULEdBQXNCQSxTQUFTLENBQUMsUUFBRCxDQUEvQjtBQUNBQSxXQUFTLENBQUMsTUFBRCxDQUFULEdBQW9CLFFBQXBCO0FBQ0FBLFdBQVMsQ0FBQyxTQUFELENBQVQsR0FBdUJBLFNBQVMsQ0FBQyxTQUFELENBQWhDO0FBQ0FBLFdBQVMsQ0FBQyxhQUFELENBQVQsR0FBMkIsSUFBM0I7QUFDQUEsV0FBUyxDQUFDLFlBQUQsQ0FBVCxHQUEwQkEsU0FBUyxDQUFDLFlBQUQsQ0FBbkM7QUFDQUEsV0FBUyxDQUFDLFdBQUQsQ0FBVCxHQUF5QjtBQUFFQyxRQUFJLEVBQUUsSUFBUjtBQUFjQyxRQUFJLEVBQUU7QUFBcEIsR0FBekI7QUFFQSxTQUFPRixTQUFQO0FBQ0Q7O0FBRUQsU0FBU1MsUUFBVCxDQUFrQkMsV0FBbEIsRUFBK0JDLElBQS9CLEVBQXFDO0FBQ25DLE1BQUlDLEtBQUssR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdDLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlTCxJQUFmLENBQVgsRUFBaUMsT0FBakMsQ0FBWjtBQUNBLE1BQUlNLFNBQVMsR0FBRyxFQUFoQjs7QUFFQSxPQUFLLElBQUlDLENBQVQsSUFBY04sS0FBZCxFQUFxQjtBQUNuQkEsU0FBSyxDQUFDTSxDQUFELENBQUwsQ0FBUyxZQUFULElBQXlCQyxRQUFRLENBQUNELENBQUQsQ0FBakM7O0FBQ0EsUUFBSU4sS0FBSyxDQUFDTSxDQUFELENBQUwsQ0FBU0UsVUFBYixFQUF5QjtBQUN2QkgsZUFBUyxDQUFDSSxJQUFWLENBQWVULEtBQUssQ0FBQ00sQ0FBRCxDQUFwQjtBQUNELEtBRkQsTUFFTztBQUNMLFVBQUlJLE9BQU8sR0FBRyxFQUFkOztBQUNBLGNBQVFWLEtBQUssQ0FBQ00sQ0FBRCxDQUFMLENBQVNLLFVBQWpCO0FBQ0UsYUFBSyxNQUFMO0FBQ0VELGlCQUFPLEdBQUd2QixjQUFjLENBQUNhLEtBQUssQ0FBQ00sQ0FBRCxDQUFOLENBQXhCO0FBQ0E7O0FBQ0YsYUFBSyxLQUFMO0FBQ0VJLGlCQUFPLEdBQUduQixhQUFhLENBQUNTLEtBQUssQ0FBQ00sQ0FBRCxDQUFOLENBQXZCO0FBQ0E7O0FBQ0YsYUFBSyxPQUFMO0FBQ0VJLGlCQUFPLEdBQUdmLGlCQUFpQixDQUFDSyxLQUFLLENBQUNNLENBQUQsQ0FBTixDQUEzQjtBQUNBOztBQUNGLGFBQUssUUFBTDtBQUNFSSxpQkFBTyxHQUFHaEIsWUFBWSxDQUFDTSxLQUFLLENBQUNNLENBQUQsQ0FBTixDQUF0QjtBQUNBOztBQUNGLGFBQUssT0FBTDtBQUNFSSxpQkFBTyxHQUFHakIsZUFBZSxDQUFDTyxLQUFLLENBQUNNLENBQUQsQ0FBTixDQUF6QjtBQUNBOztBQUNGLGFBQUssUUFBTDtBQUNFSSxpQkFBTyxHQUFHZCxnQkFBZ0IsQ0FBQ0ksS0FBSyxDQUFDTSxDQUFELENBQU4sQ0FBMUI7QUFDQTtBQWxCSjs7QUFvQkF6QixZQUFNLENBQUMrQixJQUFQLENBQVksY0FBWixFQUE0QkYsT0FBNUI7QUFDRDtBQUNGOztBQUNELFNBQU9MLFNBQVA7QUFDRDs7QUFFTSxTQUFTbkIsZUFBVCxHQUEyQjtBQUNoQyxNQUFJbUIsU0FBUyxHQUFHLEVBQWhCO0FBQ0FBLFdBQVMsQ0FBQyxZQUFELENBQVQsR0FBMEJSLFFBQVEsQ0FBQyxZQUFELEVBQWUsdUJBQWYsQ0FBbEM7QUFDQVEsV0FBUyxDQUFDLFdBQUQsQ0FBVCxHQUF5QlIsUUFBUSxDQUFDLFdBQUQsRUFBYyxxQkFBZCxDQUFqQztBQUVBaEIsUUFBTSxDQUFDK0IsSUFBUCxDQUFZLGlCQUFaLEVBQStCUCxTQUEvQjtBQUNELEM7Ozs7Ozs7Ozs7O0FDdkhEdkIsTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQzRCLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUloQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUk4QixLQUFKO0FBQVVoQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQkFBWixFQUE4QjtBQUFDK0IsT0FBSyxDQUFDOUIsQ0FBRCxFQUFHO0FBQUM4QixTQUFLLEdBQUM5QixDQUFOO0FBQVE7O0FBQWxCLENBQTlCLEVBQWtELENBQWxEO0FBQXFELElBQUkrQixRQUFKO0FBQWFqQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQkFBWixFQUFpQztBQUFDZ0MsVUFBUSxDQUFDL0IsQ0FBRCxFQUFHO0FBQUMrQixZQUFRLEdBQUMvQixDQUFUO0FBQVc7O0FBQXhCLENBQWpDLEVBQTJELENBQTNEO0FBQThELElBQUlnQyxRQUFKO0FBQWFsQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDaUMsVUFBUSxDQUFDaEMsQ0FBRCxFQUFHO0FBQUNnQyxZQUFRLEdBQUNoQyxDQUFUO0FBQVc7O0FBQXhCLENBQWhDLEVBQTBELENBQTFEOztBQUlwUSxTQUFTRyxjQUFULENBQXdCOEIsYUFBeEIsRUFBdUM7QUFDckNBLGVBQWEsQ0FBQyxNQUFELENBQWIsR0FBd0JBLGFBQWEsQ0FBQyxNQUFELENBQXJDO0FBQ0FBLGVBQWEsQ0FBQyxTQUFELENBQWIsR0FBMkJBLGFBQWEsQ0FBQyxTQUFELENBQXhDO0FBQ0FBLGVBQWEsQ0FBQyxZQUFELENBQWIsR0FBOEIsTUFBOUI7QUFDQUEsZUFBYSxDQUFDLFVBQUQsQ0FBYixHQUE0QixLQUE1QjtBQUNBQSxlQUFhLENBQUMsUUFBRCxDQUFiLEdBQTBCLEtBQTFCLENBTHFDLENBT3JDO0FBQ0E7O0FBQ0EsU0FBT0EsYUFBUDtBQUNEOztBQUVNLFNBQVNKLFdBQVQsR0FBdUI7QUFDNUIsTUFBSUssUUFBUSxHQUFHakIsSUFBSSxDQUFDQyxLQUFMLENBQVdDLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlLHVCQUFmLENBQVgsRUFDYixVQURhLENBQWY7O0FBSUEsT0FBSyxJQUFJRSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHWSxRQUFRLENBQUNDLE1BQTdCLEVBQXFDYixDQUFDLEVBQXRDLEVBQTBDO0FBQ3hDekIsVUFBTSxDQUFDK0IsSUFBUCxDQUFZLGdCQUFaLEVBQThCekIsY0FBYyxDQUFDK0IsUUFBUSxDQUFDWixDQUFELENBQVQsQ0FBNUM7QUFDRDtBQUNGLEM7Ozs7Ozs7Ozs7O0FDeEJEeEIsTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQ21DLGVBQWEsRUFBQyxNQUFJQTtBQUFuQixDQUFkO0FBQWlELElBQUl2QyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxQyxRQUFKO0FBQWF2QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDc0MsVUFBUSxDQUFDckMsQ0FBRCxFQUFHO0FBQUNxQyxZQUFRLEdBQUNyQyxDQUFUO0FBQVc7O0FBQXhCLENBQW5DLEVBQTZELENBQTdEO0FBQWdFLElBQUlzQyxLQUFKO0FBQVV4QyxNQUFNLENBQUNDLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDdUMsT0FBSyxDQUFDdEMsQ0FBRCxFQUFHO0FBQUNzQyxTQUFLLEdBQUN0QyxDQUFOO0FBQVE7O0FBQWxCLENBQXBDLEVBQXdELENBQXhEO0FBQTJELElBQUl1QyxPQUFKO0FBQVl6QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUN5QyxTQUFPLENBQUN4QyxDQUFELEVBQUc7QUFBQ3VDLFdBQU8sR0FBQ3ZDLENBQVI7QUFBVTs7QUFBdEIsQ0FBdEIsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSXlDLFFBQUo7QUFBYTNDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUMwQyxVQUFRLENBQUN6QyxDQUFELEVBQUc7QUFBQ3lDLFlBQVEsR0FBQ3pDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBakMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSStCLFFBQUo7QUFBYWpDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUNnQyxVQUFRLENBQUMvQixDQUFELEVBQUc7QUFBQytCLFlBQVEsR0FBQy9CLENBQVQ7QUFBVzs7QUFBeEIsQ0FBakMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSTBDLE9BQUo7QUFBWTVDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUMyQyxTQUFPLENBQUMxQyxDQUFELEVBQUc7QUFBQzBDLFdBQU8sR0FBQzFDLENBQVI7QUFBVTs7QUFBdEIsQ0FBaEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTJDLFFBQUo7QUFBYTdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUM0QyxVQUFRLENBQUMzQyxDQUFELEVBQUc7QUFBQzJDLFlBQVEsR0FBQzNDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBakMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSThCLEtBQUo7QUFBVWhDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGlCQUFaLEVBQThCO0FBQUMrQixPQUFLLENBQUM5QixDQUFELEVBQUc7QUFBQzhCLFNBQUssR0FBQzlCLENBQU47QUFBUTs7QUFBbEIsQ0FBOUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRDLE9BQUo7QUFBWTlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUM2QyxTQUFPLENBQUM1QyxDQUFELEVBQUc7QUFBQzRDLFdBQU8sR0FBQzVDLENBQVI7QUFBVTs7QUFBdEIsQ0FBaEMsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSTZCLFdBQUo7QUFBZ0IvQixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUM4QixhQUFXLENBQUM3QixDQUFELEVBQUc7QUFBQzZCLGVBQVcsR0FBQzdCLENBQVo7QUFBYzs7QUFBOUIsQ0FBNUIsRUFBNEQsRUFBNUQ7QUFBZ0UsSUFBSUUsZUFBSjtBQUFvQkosTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ0csaUJBQWUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLG1CQUFlLEdBQUNGLENBQWhCO0FBQWtCOztBQUF0QyxDQUFoQyxFQUF3RSxFQUF4RTtBQUE0RSxJQUFJNkMsV0FBSjtBQUFnQi9DLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzhDLGFBQVcsQ0FBQzdDLENBQUQsRUFBRztBQUFDNkMsZUFBVyxHQUFDN0MsQ0FBWjtBQUFjOztBQUE5QixDQUE1QixFQUE0RCxFQUE1RDs7QUFldjZCLFNBQVNvQyxhQUFULEdBQXlCO0FBQzlCVSxlQUFhLEdBRGlCLENBRTlCOztBQUNBQyxZQUFVOztBQUNWLE1BQUlsRCxNQUFNLENBQUNtRCxhQUFYLEVBQTBCO0FBQ3hCQyxtQkFBZSxDQUFDLElBQUQsQ0FBZjtBQUNEOztBQUNEL0MsaUJBQWU7QUFDZjJCLGFBQVc7QUFDWHFCLGNBQVk7QUFDWkMsZUFBYTtBQUNiQyxjQUFZLEdBWGtCLENBWTlCO0FBQ0Q7O0FBQ0Q7QUFDQSxTQUFTRixZQUFULEdBQXdCO0FBQ3RCLE1BQUloQixRQUFRLEdBQUdVLE9BQU8sQ0FBQ1MsSUFBUixDQUFhLEVBQWIsRUFBaUJDLEtBQWpCLEVBQWY7O0FBQ0EsT0FBSyxJQUFJaEMsQ0FBVCxJQUFjWSxRQUFkLEVBQXdCO0FBQ3RCLFFBQUlxQixPQUFPLEdBQUdyQixRQUFRLENBQUNaLENBQUQsQ0FBUixDQUFZaUMsT0FBMUI7QUFDQSxRQUFJQyxJQUFJLEdBQUcsRUFBWDtBQUNBLFFBQUlDLElBQUksR0FBRyxFQUFYO0FBQ0EsUUFBSUMsS0FBSyxHQUFHeEIsUUFBUSxDQUFDWixDQUFELENBQVIsQ0FBWXFDLElBQXhCLENBSnNCLENBS3RCOztBQUNBLFFBQUl0QyxTQUFTLEdBQUdVLFFBQVEsQ0FBQ3NCLElBQVQsQ0FBYyxFQUFkLEVBQWtCQyxLQUFsQixFQUFoQjs7QUFFQSxTQUFLLElBQUlNLENBQVQsSUFBY0wsT0FBZCxFQUF1QjtBQUNyQixVQUFJdkMsS0FBSyxHQUFHYyxLQUFLLENBQUN1QixJQUFOLENBQVc7QUFDckJRLGdCQUFRLEVBQUUzQixRQUFRLENBQUNaLENBQUQsQ0FBUixDQUFZcUMsSUFBWixHQUFtQkosT0FBTyxDQUFDSyxDQUFELENBQVAsQ0FBV0U7QUFEbkIsT0FBWCxFQUVUUixLQUZTLEVBQVo7QUFHQUMsYUFBTyxDQUFDSyxDQUFELENBQVAsQ0FBVzVDLEtBQVgsR0FBbUJBLEtBQW5CO0FBQ0Q7O0FBRUQsUUFBSStDLGNBQWMsR0FBRztBQUNuQkMsVUFBSSxFQUFFO0FBQUVULGVBQU8sRUFBRUE7QUFBWDtBQURhLEtBQXJCO0FBSUFYLFdBQU8sQ0FBQ3FCLE1BQVIsQ0FBZTtBQUFFQyxTQUFHLEVBQUVoQyxRQUFRLENBQUNaLENBQUQsQ0FBUixDQUFZNEM7QUFBbkIsS0FBZixFQUF5Q0gsY0FBekM7O0FBRUEsU0FBSyxJQUFJSSxDQUFULElBQWM5QyxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWFxQyxLQUFiLENBQWQsRUFBbUM7QUFDakNELFVBQUksQ0FBQ2hDLElBQUwsQ0FDRUosU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhcUMsS0FBYixFQUFvQlMsQ0FBcEIsRUFBdUJDLFVBQXZCLEdBQW9DL0MsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhcUMsS0FBYixFQUFvQlMsQ0FBcEIsRUFBdUJMLFVBRDdEO0FBR0QsS0F6QnFCLENBMkJ0Qjs7O0FBQ0FsQixXQUFPLENBQUNxQixNQUFSLENBQWU7QUFBRUMsU0FBRyxFQUFFaEMsUUFBUSxDQUFDWixDQUFELENBQVIsQ0FBWTRDO0FBQW5CLEtBQWYsRUFBeUNILGNBQXpDO0FBRUFBLGtCQUFjLEdBQUc7QUFDZkMsVUFBSSxFQUFFO0FBQUUzQyxpQkFBUyxFQUFFb0M7QUFBYjtBQURTLEtBQWpCO0FBR0FiLFdBQU8sQ0FBQ3FCLE1BQVIsQ0FBZTtBQUFFQyxTQUFHLEVBQUVoQyxRQUFRLENBQUNaLENBQUQsQ0FBUixDQUFZNEM7QUFBbkIsS0FBZixFQUF5Q0gsY0FBekMsRUFqQ3NCLENBa0N0QjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBU2QsZUFBVCxDQUF5Qm9CLFNBQXpCLEVBQW9DO0FBQ2xDLFFBQU1DLEtBQUssR0FBRyxrQkFBZDtBQUNBLFFBQU1DLFFBQVEsR0FBRyxLQUFqQjtBQUNBLFFBQU1DLFNBQVMsR0FBR25DLFFBQVEsQ0FBQ29DLFVBQVQsQ0FBb0I7QUFBRUgsU0FBRjtBQUFTQztBQUFULEdBQXBCLENBQWxCO0FBQ0FqQyxPQUFLLENBQUNvQyxlQUFOLENBQXNCRixTQUF0QixFQUFpQyxTQUFqQztBQUNBL0IsVUFBUSxDQUFDa0MsTUFBVCxDQUFnQjtBQUNkQyxVQUFNLEVBQUVKLFNBRE07QUFFZEssV0FBTyxFQUFFO0FBRkssR0FBaEI7QUFJQSxRQUFNQyxRQUFRLEdBQUd2QyxPQUFPLENBQUN3QyxRQUFSLEVBQWpCO0FBRUFyQyxTQUFPLENBQUNpQyxNQUFSLENBQWU7QUFDYlQsT0FBRyxFQUFFWSxRQURRO0FBRWJFLGNBQVUsRUFBRSxXQUZDO0FBR2JDLFVBQU0sRUFBRSxFQUhLO0FBSWJqRSxTQUFLLEVBQUUsRUFKTTtBQUtid0QsYUFBUyxFQUFFL0IsUUFBUSxDQUFDeUMsT0FBVCxHQUFtQmhCO0FBTGpCLEdBQWY7QUFPRDs7QUFFRCxTQUFTbkIsVUFBVCxHQUFzQjtBQUNwQixRQUFNb0MsT0FBTyxHQUFHLGlCQUFoQjtBQUNBLFFBQU1aLFFBQVEsR0FBRyxLQUFqQjtBQUNBYSxLQUFHLEdBQUcvQyxRQUFRLENBQUNvQyxVQUFULENBQW9CO0FBQUVZLFlBQVEsRUFBRSxTQUFaO0FBQXVCZixTQUFLLEVBQUVhLE9BQTlCO0FBQXVDWjtBQUF2QyxHQUFwQixDQUFOOztBQUNBLFFBQU1lLElBQUksR0FBR2pELFFBQVEsQ0FBQ2tELGVBQVQsQ0FBeUJKLE9BQXpCLEVBQWtDakIsR0FBL0M7O0FBQ0E1QixPQUFLLENBQUNvQyxlQUFOLENBQXNCWSxJQUF0QixFQUE0QixRQUE1QjtBQUNEOztBQUNELFNBQVNsQyxZQUFULEdBQXdCO0FBQ3RCLE1BQUlpQyxRQUFRLEdBQUcsU0FBZjtBQUNBLE1BQUlmLEtBQUssR0FBR2UsUUFBWjtBQUNBLE1BQUlULE1BQU0sR0FBR3ZDLFFBQVEsQ0FBQ29DLFVBQVQsQ0FBb0I7QUFBRVksWUFBRjtBQUFZZixTQUFaO0FBQW1CQyxZQUFRLEVBQUVjO0FBQTdCLEdBQXBCLENBQWI7QUFDQS9DLE9BQUssQ0FBQ29DLGVBQU4sQ0FBc0JFLE1BQXRCLEVBQThCLFNBQTlCO0FBQ0FuQyxVQUFRLENBQUNrQyxNQUFULENBQWdCO0FBQ2RDLFVBQU0sRUFBRUEsTUFETTtBQUVkWSxnQkFBWSxFQUFFLEVBRkE7QUFHZFgsV0FBTyxFQUFFO0FBSEssR0FBaEI7QUFLRDs7QUFDRCxTQUFTMUIsYUFBVCxHQUF5QjtBQUN2QixRQUFNMEIsT0FBTyxHQUFHbkMsT0FBTyxDQUFDVyxJQUFSLENBQWEsRUFBYixFQUFpQkMsS0FBakIsRUFBaEI7O0FBQ0EsT0FBSyxJQUFJaEMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxDQUFwQixFQUF1QkEsQ0FBQyxFQUF4QixFQUE0QjtBQUMxQixRQUFJK0QsUUFBUSxHQUFHLFNBQVMvRCxDQUF4QjtBQUNBLFFBQUlnRCxLQUFLLEdBQUdlLFFBQVo7QUFDQSxRQUFJVCxNQUFNLEdBQUd2QyxRQUFRLENBQUNvQyxVQUFULENBQW9CO0FBQUVZLGNBQUY7QUFBWWYsV0FBWjtBQUFtQkMsY0FBUSxFQUFFYztBQUE3QixLQUFwQixDQUFiO0FBQ0EvQyxTQUFLLENBQUNvQyxlQUFOLENBQXNCRSxNQUF0QixFQUE4QixTQUE5QixFQUowQixDQU0xQjs7QUFFQSxRQUFJdEQsQ0FBQyxJQUFJLENBQVQsRUFBWTtBQUNWLFVBQUltRSxJQUFJLEdBQUczRCxLQUFLLENBQUNvRCxPQUFOLENBQWM7QUFBRVEsZUFBTyxFQUFFLFlBQVg7QUFBeUI1QixrQkFBVSxFQUFFO0FBQXJDLE9BQWQsQ0FBWDtBQUNBbkIsY0FBUSxDQUFDZ0MsTUFBVCxDQUFnQjtBQUNkQyxjQUFNLEVBQUVBLE1BRE07QUFFZGUsZUFBTyxFQUFFLENBRks7QUFHZEMsV0FBRyxFQUFFLENBSFM7QUFJZEMsYUFBSyxFQUFFLENBSk87QUFLZEMsZUFBTyxFQUFFLENBQUMsQ0FBRCxDQUxLO0FBTWROLG9CQUFZLEVBQUUsa0NBTkE7QUFPZE8sd0JBQWdCLEVBQUUsSUFQSjtBQVFkbEIsZUFBTyxFQUFFLEVBUks7QUFTZDdELGFBQUssRUFBRSxDQUFDeUUsSUFBRCxDQVRPO0FBVWRPLG1CQUFXLEVBQUUsRUFWQztBQVdkQyxrQkFBVSxFQUFFLEVBWEU7QUFZZEMscUJBQWEsRUFBRSxFQVpEO0FBYWRDLHlCQUFpQixFQUFFLENBYkw7QUFjZEMsc0JBQWMsRUFBRSxFQWRGO0FBZWRDLHVCQUFlLEVBQUUsRUFmSDtBQWdCZEMsc0JBQWMsRUFBRTtBQWhCRixPQUFoQjtBQWtCRCxLQXBCRCxNQW9CTztBQUNMM0QsY0FBUSxDQUFDZ0MsTUFBVCxDQUFnQjtBQUNkQyxjQUFNLEVBQUVBLE1BRE07QUFFZGUsZUFBTyxFQUFFLENBRks7QUFHZEMsV0FBRyxFQUFFLENBSFM7QUFJZEMsYUFBSyxFQUFFLENBSk87QUFLZEMsZUFBTyxFQUFFLENBQUMsQ0FBRCxDQUxLO0FBTWROLG9CQUFZLEVBQUUsRUFOQTtBQU9kTyx3QkFBZ0IsRUFBRSxJQVBKO0FBUWRsQixlQUFPLEVBQUUsRUFSSztBQVNkN0QsYUFBSyxFQUFFLEVBVE87QUFVZGdGLG1CQUFXLEVBQUUsRUFWQztBQVdkQyxrQkFBVSxFQUFFLEVBWEU7QUFhZEUseUJBQWlCLEVBQUUsQ0FiTDtBQWNkQyxzQkFBYyxFQUFFLEVBZEY7QUFlZEMsdUJBQWUsRUFBRSxFQWZIO0FBZ0JkQyxzQkFBYyxFQUFFO0FBaEJGLE9BQWhCO0FBa0JELEtBL0N5QixDQWlEMUI7QUFFQTs7QUFDRCxHQXREc0IsQ0F1RHZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDRDs7QUFFRCxTQUFTeEQsYUFBVCxHQUF5QjtBQUN2QkwsVUFBUSxDQUFDOEQsTUFBVCxDQUFnQixFQUFoQjtBQUNBNUQsVUFBUSxDQUFDNEQsTUFBVCxDQUFnQixFQUFoQjtBQUNBMUcsUUFBTSxDQUFDMkcsS0FBUCxDQUFhRCxNQUFiLENBQW9CLEVBQXBCO0FBQ0E3RCxTQUFPLENBQUM2RCxNQUFSLENBQWUsRUFBZjtBQUNBekUsT0FBSyxDQUFDeUUsTUFBTixDQUFhLEVBQWI7QUFDQXhFLFVBQVEsQ0FBQ3dFLE1BQVQsQ0FBZ0IsRUFBaEI7QUFDQTNELFNBQU8sQ0FBQzJELE1BQVIsQ0FBZSxFQUFmO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUNyTER6RyxNQUFNLENBQUNHLE1BQVAsQ0FBYztBQUFDeUMsU0FBTyxFQUFDLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJN0MsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUcsS0FBSjtBQUFVM0csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMEcsT0FBSyxDQUFDekcsQ0FBRCxFQUFHO0FBQUN5RyxTQUFLLEdBQUN6RyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkwRyxZQUFKO0FBQWlCNUcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUMsU0FBTyxDQUFDeEMsQ0FBRCxFQUFHO0FBQUMwRyxnQkFBWSxHQUFDMUcsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJdUMsT0FBSjtBQUFZekMsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDeUMsU0FBTyxDQUFDeEMsQ0FBRCxFQUFHO0FBQUN1QyxXQUFPLEdBQUN2QyxDQUFSO0FBQVU7O0FBQXRCLENBQXRCLEVBQThDLENBQTlDO0FBQWlELElBQUkyQyxRQUFKO0FBQWE3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUM0QyxVQUFRLENBQUMzQyxDQUFELEVBQUc7QUFBQzJDLFlBQVEsR0FBQzNDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBekIsRUFBbUQsQ0FBbkQ7QUFBc0QsSUFBSXlDLFFBQUo7QUFBYTNDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQzBDLFVBQVEsQ0FBQ3pDLENBQUQsRUFBRztBQUFDeUMsWUFBUSxHQUFDekMsQ0FBVDtBQUFXOztBQUF4QixDQUF6QixFQUFtRCxDQUFuRDtBQU9uWCxNQUFNMEMsT0FBTyxHQUFHLElBQUkrRCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7O0FBRVAsSUFBSTlHLE1BQU0sQ0FBQytHLFFBQVgsRUFBcUI7QUFDbkI7QUFDQWxFLFNBQU8sQ0FBQ21FLGFBQVIsR0FBd0JDLFdBQXhCLENBQ0U7QUFBRXRDLGFBQVMsRUFBRSxDQUFiO0FBQWdCUSxjQUFVLEVBQUU7QUFBNUIsR0FERixFQUVFO0FBQUUrQixVQUFNLEVBQUU7QUFBVixHQUZGLEVBRm1CLENBTW5COztBQUNBbEgsUUFBTSxDQUFDbUgsT0FBUCxDQUFlLGtCQUFmLEVBQW1DLE1BQU07QUFDdkMsUUFBSW5ILE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FBdkIsRUFBdUU7QUFDckUsVUFBSUMsU0FBUyxHQUFHeEUsUUFBUSxDQUFDdUMsT0FBVCxDQUFpQjtBQUFFTixjQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsT0FBakIsRUFBOENWLEdBQTlEOztBQUNBeEIsYUFBTyxDQUFDVyxJQUFSLENBQWE7QUFBRThEO0FBQUYsT0FBYjtBQUNBLGFBQU96RSxPQUFPLENBQUNXLElBQVIsQ0FBYTtBQUFFOEQ7QUFBRixPQUFiLENBQVA7QUFDRDs7QUFDRCxVQUFNLElBQUl0SCxNQUFNLENBQUN1SCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0QsR0FQRDtBQVFBdkgsUUFBTSxDQUFDbUgsT0FBUCxDQUFlLGFBQWYsRUFBOEIsWUFBVztBQUN2QyxRQUFJbkgsTUFBTSxDQUFDK0UsTUFBUCxFQUFKLEVBQXFCO0FBQ25CLGFBQU9sQyxPQUFPLENBQUNXLElBQVIsQ0FBYSxFQUFiLENBQVA7QUFDRDs7QUFDRCxVQUFNLElBQUl4RCxNQUFNLENBQUN1SCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0QsR0FMRCxFQWZtQixDQXFCbkI7O0FBQ0F2SCxRQUFNLENBQUNtSCxPQUFQLENBQWUsa0JBQWYsRUFBbUNsQyxRQUFRLElBQUk7QUFDN0MsUUFBSWpGLE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FBdkIsRUFBdUU7QUFDckUsVUFBSTFDLFNBQVMsR0FBRy9CLFFBQVEsQ0FBQ3lDLE9BQVQsQ0FBaUI7QUFBRU4sY0FBTSxFQUFFL0UsTUFBTSxDQUFDK0UsTUFBUDtBQUFWLE9BQWpCLEVBQThDVixHQUE5RDs7QUFDQXhCLGFBQU8sQ0FBQ3dDLE9BQVI7QUFDQSxhQUFPeEMsT0FBTyxDQUFDVyxJQUFSLENBQWE7QUFBRW1CO0FBQUYsT0FBYixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJM0UsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEdBUEQsRUF0Qm1CLENBOEJuQjs7QUFDQXZILFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxVQUFTSyxTQUFULEVBQW9CO0FBQ3BELFFBQUl4SCxNQUFNLENBQUMrRSxNQUFQLE1BQW1CdEMsS0FBSyxDQUFDMkUsWUFBTixDQUFtQnBILE1BQU0sQ0FBQ3FILElBQVAsRUFBbkIsRUFBa0MsQ0FBQyxTQUFELENBQWxDLENBQXZCLEVBQXVFO0FBQ3JFLGFBQU94RSxPQUFPLENBQUNXLElBQVIsQ0FBYTtBQUFFbUIsaUJBQVMsRUFBRTNFLE1BQU0sQ0FBQytFLE1BQVAsRUFBYjtBQUE4QnlDO0FBQTlCLE9BQWIsQ0FBUDtBQUNEOztBQUNELFVBQU0sSUFBSXhILE1BQU0sQ0FBQ3VILEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRCxHQUxELEVBL0JtQixDQXFDbkI7O0FBQ0F2SCxRQUFNLENBQUNtSCxPQUFQLENBQWUsU0FBZixFQUEwQixZQUFXO0FBQ25DLFFBQUluSCxNQUFNLENBQUMrRSxNQUFQLE1BQW1CdEMsS0FBSyxDQUFDMkUsWUFBTixDQUFtQnBILE1BQU0sQ0FBQ3FILElBQVAsRUFBbkIsRUFBa0MsQ0FBQyxRQUFELENBQWxDLENBQXZCLEVBQXNFO0FBQ3BFLGFBQU94RSxPQUFPLENBQUNXLElBQVIsQ0FBYSxFQUFiLENBQVA7QUFDRDs7QUFDRCxVQUFNLElBQUl4RCxNQUFNLENBQUN1SCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0QsR0FMRCxFQXRDbUIsQ0E0Q25COztBQUNBdkgsUUFBTSxDQUFDbUgsT0FBUCxDQUFlLGtCQUFmLEVBQW1DLFlBQVc7QUFDNUMsVUFBTU0sT0FBTyxHQUFHM0UsUUFBUSxDQUFDdUMsT0FBVCxDQUFpQjtBQUFFTixZQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsS0FBakIsQ0FBaEI7O0FBQ0EsUUFBSTBDLE9BQUosRUFBYTtBQUNYLGFBQU81RSxPQUFPLENBQUNXLElBQVIsQ0FBYTtBQUFFYSxXQUFHLEVBQUVvRCxPQUFPLENBQUNDO0FBQWYsT0FBYixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJMUgsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEdBTkQ7QUFPRDs7QUFFRHZILE1BQU0sQ0FBQzJILE9BQVAsQ0FBZTtBQUNiO0FBQ0Esb0JBQWtCLFVBQVN4QyxVQUFULEVBQXFCeUMsUUFBckIsRUFBK0JqRCxTQUEvQixFQUEwQztBQUMxRCxRQUFJM0UsTUFBTSxDQUFDK0csUUFBWCxFQUFxQjtBQUNuQixVQUFJL0csTUFBTSxDQUFDK0UsTUFBUCxNQUFtQnRDLEtBQUssQ0FBQzJFLFlBQU4sQ0FBbUJwSCxNQUFNLENBQUNxSCxJQUFQLEVBQW5CLEVBQWtDLENBQUMsU0FBRCxDQUFsQyxDQUF2QixFQUF1RTtBQUNyRSxZQUFJeEUsT0FBTyxDQUFDd0MsT0FBUixDQUFnQjtBQUFFVixtQkFBUyxFQUFFM0UsTUFBTSxDQUFDK0UsTUFBUCxFQUFiO0FBQThCSTtBQUE5QixTQUFoQixDQUFKLEVBQ0UsTUFBTSxJQUFJbkYsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQix1QkFBakIsQ0FBTjtBQUNGLGNBQU10QyxRQUFRLEdBQUd2QyxPQUFPLENBQUN3QyxRQUFSLEVBQWpCO0FBQ0EsY0FBTTJDLFFBQVEsR0FBRyxFQUFqQjtBQUNBaEYsZUFBTyxDQUFDaUMsTUFBUixDQUFlO0FBQ2JILG1CQUFTLEVBQUVBLFNBREU7QUFFYlEsb0JBRmE7QUFHYnlDLGtCQUhhO0FBSWJDLGtCQUphO0FBS2JDLGlCQUFPLEVBQUUsS0FMSTtBQU1iM0csZUFBSyxFQUFFLEVBTk07QUFPYjRHLGVBQUssRUFBRTtBQVBNLFNBQWY7QUFTQW5GLGdCQUFRLENBQUN3QixNQUFULENBQWdCO0FBQUU0RCxtQkFBUyxFQUFFO0FBQUVoRCxtQkFBTyxFQUFFQztBQUFYO0FBQWIsU0FBaEI7QUFDRCxPQWZELE1BZU87QUFDTCxjQUFNLElBQUlqRixNQUFNLENBQUN1SCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0Q7QUFDRjtBQUNGLEdBdkJZO0FBd0JiO0FBQ0EsK0JBQTZCLFVBQVNVLEtBQVQsRUFBZ0J0QyxZQUFoQixFQUE4QjtBQUN6RDtBQUNBLFFBQUkzRixNQUFNLENBQUMrRyxRQUFYLEVBQXFCO0FBQ25CLFVBQUk7QUFDRixZQUFJbUIsYUFBYSxHQUFHQyxJQUFJLENBQUNwRyxJQUFMLENBQ2xCLEtBRGtCLEVBRWxCLCtEQUNFNEQsWUFERixHQUVFLFVBSmdCLEVBS2xCO0FBQ0V5QyxpQkFBTyxFQUFFO0FBQUVDLHlCQUFhLEVBQUUsV0FBV0o7QUFBNUI7QUFEWCxTQUxrQixDQUFwQjtBQVNBLFlBQUlLLFVBQVUsR0FBR2xILElBQUksQ0FBQ0MsS0FBTCxDQUFXNkcsYUFBYSxDQUFDeEUsT0FBekIsQ0FBakI7QUFDQSxZQUFJNkUsV0FBVyxHQUFHLEVBQWxCOztBQUNBLGFBQUssSUFBSTlHLENBQVQsSUFBYzZHLFVBQVUsQ0FBQ0UsSUFBekIsRUFBK0I7QUFDN0IsY0FBSUMsU0FBUyxHQUFHSCxVQUFVLENBQUNFLElBQVgsQ0FBZ0IvRyxDQUFoQixDQUFoQjs7QUFFQSxjQUFJO0FBQ0YsZ0JBQUlpSCxjQUFjLEdBQUdQLElBQUksQ0FBQ3BHLElBQUwsQ0FDbkIsS0FEbUIsRUFFbkIsaUVBQ0UwRyxTQUFTLENBQUNFLEVBRFosR0FFRSxjQUppQixFQUtuQjtBQUNFUCxxQkFBTyxFQUFFO0FBQUVDLDZCQUFhLEVBQUUsV0FBV0o7QUFBNUI7QUFEWCxhQUxtQixDQUFyQjtBQVNBLGdCQUFJVyxjQUFjLEdBQUd4SCxJQUFJLENBQUNDLEtBQUwsQ0FBV3FILGNBQWMsQ0FBQ2hGLE9BQTFCLENBQXJCLENBVkUsQ0FZRjs7QUFDQSxpQkFBSyxJQUFJWSxDQUFULElBQWNzRSxjQUFjLENBQUNKLElBQTdCLEVBQW1DO0FBQ2pDLGtCQUFJSyxZQUFZLEdBQUdELGNBQWMsQ0FBQ0osSUFBZixDQUFvQmxFLENBQXBCLEVBQXVCd0UsVUFBdkIsQ0FBa0NDLE1BQXJEO0FBQ0Esa0JBQUlDLGNBQWMsR0FBR0osY0FBYyxDQUFDSixJQUFmLENBQW9CbEUsQ0FBcEIsRUFBdUJxRSxFQUF2QixDQUEwQk0sS0FBMUIsQ0FBZ0MsR0FBaEMsRUFBcUMsQ0FBckMsQ0FBckI7QUFFQSxrQkFBSUMsV0FBVyxHQUFHRixjQUFjLEtBQUtyRCxZQUFyQzs7QUFDQSxrQkFBSWtELFlBQVksSUFBSSxRQUFoQixJQUE0QkssV0FBaEMsRUFBNkM7QUFDM0NYLDJCQUFXLENBQUMzRyxJQUFaLENBQWlCNkcsU0FBakI7QUFDRDtBQUNGO0FBQ0YsV0F0QkQsQ0FzQkUsT0FBT1UsQ0FBUCxFQUFVO0FBQ1ZDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBLG1CQUFPLEtBQVA7QUFDRDtBQUNGOztBQUNELGVBQU9aLFdBQVA7QUFDRCxPQTNDRCxDQTJDRSxPQUFPWSxDQUFQLEVBQVU7QUFDVkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQSxlQUFPLEtBQVA7QUFDRDtBQUNGO0FBQ0YsR0E1RVk7QUE4RWIsK0JBQTZCLFVBQVNsQixLQUFULEVBQWdCdEMsWUFBaEIsRUFBOEI7QUFDekQsUUFBSTBCLElBQUksR0FBR3ZFLFFBQVEsQ0FBQ3VDLE9BQVQsQ0FBaUI7QUFBRU0sa0JBQVksRUFBRUE7QUFBaEIsS0FBakIsQ0FBWDs7QUFFQSxRQUFJM0YsTUFBTSxDQUFDK0csUUFBWCxFQUFxQjtBQUNuQixVQUFJO0FBQ0YsWUFBSW1CLGFBQWEsR0FBR0MsSUFBSSxDQUFDcEcsSUFBTCxDQUNsQixLQURrQixFQUVsQiwrREFDRTRELFlBREYsR0FFRSxVQUpnQixFQUtsQjtBQUNFeUMsaUJBQU8sRUFBRTtBQUFFQyx5QkFBYSxFQUFFLFdBQVdKO0FBQTVCO0FBRFgsU0FMa0IsQ0FBcEI7QUFTQSxZQUFJSyxVQUFVLEdBQUdsSCxJQUFJLENBQUNDLEtBQUwsQ0FBVzZHLGFBQWEsQ0FBQ3hFLE9BQXpCLENBQWpCO0FBQ0QsT0FYRCxDQVdFLE9BQU95RixDQUFQLEVBQVU7QUFDVkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDQSxlQUFPLEtBQVA7QUFDRDs7QUFDRCxhQUFPYixVQUFQO0FBQ0Q7QUFDRixHQW5HWTtBQXFHYixtQkFBaUIsVUFBU3JELFFBQVQsRUFBbUI7QUFDbENwQyxXQUFPLENBQUN1QixNQUFSLENBQWU7QUFBRUMsU0FBRyxFQUFFWTtBQUFQLEtBQWYsRUFBa0M7QUFBRWQsVUFBSSxFQUFFO0FBQUUyRCxlQUFPLEVBQUU7QUFBWDtBQUFSLEtBQWxDO0FBQ0QsR0F2R1k7QUF3R2Isb0JBQWtCLFVBQVM3QyxRQUFULEVBQW1CTixTQUFuQixFQUE4QixDQUM5QztBQUNEO0FBMUdZLENBQWYsRTs7Ozs7Ozs7Ozs7QUMvREExRSxNQUFNLENBQUNHLE1BQVAsQ0FBYztBQUFDMkMsU0FBTyxFQUFDLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJL0MsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUcsS0FBSjtBQUFVM0csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMEcsT0FBSyxDQUFDekcsQ0FBRCxFQUFHO0FBQUN5RyxTQUFLLEdBQUN6RyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkwRyxZQUFKO0FBQWlCNUcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUMsU0FBTyxDQUFDeEMsQ0FBRCxFQUFHO0FBQUMwRyxnQkFBWSxHQUFDMUcsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUkzSyxNQUFNNEMsT0FBTyxHQUFHLElBQUk2RCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsU0FBckIsQ0FBaEI7QUFFUCxNQUFNd0MsY0FBYyxHQUFHLElBQUl6QyxZQUFKLENBQWlCO0FBQ3RDL0MsTUFBSSxFQUFFO0FBQ0p5RixRQUFJLEVBQUVDO0FBREYsR0FEZ0M7QUFJdENySSxPQUFLLEVBQUU7QUFDTG9JLFFBQUksRUFBRUU7QUFERCxHQUorQjtBQU90QyxhQUFXO0FBQ1RGLFFBQUksRUFBRUM7QUFERyxHQVAyQjtBQVV0Q2hJLFdBQVMsRUFBRTtBQUNUK0gsUUFBSSxFQUFFRTtBQURHLEdBVjJCO0FBYXRDLGlCQUFlO0FBQ2JGLFFBQUksRUFBRUM7QUFETztBQWJ1QixDQUFqQixFQWdCcEJFLFVBaEJvQixFQUF2Qjs7QUFrQkEsSUFBSTFKLE1BQU0sQ0FBQytHLFFBQVgsRUFBcUI7QUFDbkIvRyxRQUFNLENBQUNtSCxPQUFQLENBQWUsU0FBZixFQUEwQixNQUFNO0FBQzlCLFdBQU9wRSxPQUFPLENBQUNTLElBQVIsQ0FBYSxFQUFiLENBQVA7QUFDRCxHQUZEO0FBR0Q7O0FBRUR4RCxNQUFNLENBQUMySCxPQUFQLENBQWU7QUFDYixtQkFBaUJnQyxRQUFqQixFQUEyQjtBQUN6QjVHLFdBQU8sQ0FBQytCLE1BQVIsQ0FBZTZFLFFBQWY7QUFDRDs7QUFIWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDOUJBMUosTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQzBDLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSTlDLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLEtBQUo7QUFBVTNHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBHLE9BQUssQ0FBQ3pHLENBQUQsRUFBRztBQUFDeUcsU0FBSyxHQUFDekcsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJMEcsWUFBSjtBQUFpQjVHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lDLFNBQU8sQ0FBQ3hDLENBQUQsRUFBRztBQUFDMEcsZ0JBQVksR0FBQzFHLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXFDLFFBQUo7QUFBYXZDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNzQyxVQUFRLENBQUNyQyxDQUFELEVBQUc7QUFBQ3FDLFlBQVEsR0FBQ3JDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSXlKLFVBQUo7QUFBZTNKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQzBKLFlBQVUsQ0FBQ3pKLENBQUQsRUFBRztBQUFDeUosY0FBVSxHQUFDekosQ0FBWDtBQUFhOztBQUE1QixDQUF4QixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJeUMsUUFBSjtBQUFhM0MsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDMEMsVUFBUSxDQUFDekMsQ0FBRCxFQUFHO0FBQUN5QyxZQUFRLEdBQUN6QyxDQUFUO0FBQVc7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBQXNELElBQUkwQyxPQUFKO0FBQVk1QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUMyQyxTQUFPLENBQUMxQyxDQUFELEVBQUc7QUFBQzBDLFdBQU8sR0FBQzFDLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSThCLEtBQUo7QUFBVWhDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFNBQVosRUFBc0I7QUFBQytCLE9BQUssQ0FBQzlCLENBQUQsRUFBRztBQUFDOEIsU0FBSyxHQUFDOUIsQ0FBTjtBQUFROztBQUFsQixDQUF0QixFQUEwQyxDQUExQztBQUE2QyxJQUFJNEMsT0FBSjtBQUFZOUMsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDNkMsU0FBTyxDQUFDNUMsQ0FBRCxFQUFHO0FBQUM0QyxXQUFPLEdBQUM1QyxDQUFSO0FBQVU7O0FBQXRCLENBQXhCLEVBQWdELENBQWhEO0FBU2xrQixNQUFNMkMsUUFBUSxHQUFHLElBQUk4RCxLQUFLLENBQUNFLFVBQVYsQ0FBcUIsVUFBckIsQ0FBakI7O0FBRVAsU0FBUytDLHFCQUFULENBQStCQyxHQUEvQixFQUFvQzNELFdBQXBDLEVBQWlEO0FBQy9DLE1BQUk0RCxnQkFBZ0IsR0FBRyxJQUF2Qjs7QUFDQSxPQUFLLElBQUl0SSxDQUFULElBQWNxSSxHQUFkLEVBQW1CO0FBQ2pCLFFBQUlFLEtBQUssR0FBRzdELFdBQVcsQ0FBQzNDLElBQVosQ0FBaUJ5RyxJQUFJLElBQUk7QUFDbkMsYUFBT0EsSUFBSSxDQUFDQyxNQUFMLEtBQWdCSixHQUFHLENBQUNySSxDQUFELENBQTFCO0FBQ0QsS0FGVyxDQUFaOztBQUdBLFFBQUl1SSxLQUFLLEtBQUtHLFNBQWQsRUFBeUI7QUFDdkJKLHNCQUFnQixHQUFHLEtBQW5CO0FBQ0Q7QUFDRjs7QUFDRCxTQUFPQSxnQkFBUDtBQUNEOztBQUVEL0osTUFBTSxDQUFDMkgsT0FBUCxDQUFlO0FBQ2IscUJBQW1CLFVBQVM1QyxNQUFULEVBQWlCWSxZQUFqQixFQUErQjtBQUNoRDdDLFlBQVEsQ0FBQ2dDLE1BQVQsQ0FBZ0I7QUFDZEMsWUFBTSxFQUFFQSxNQURNO0FBRWRlLGFBQU8sRUFBRSxDQUZLO0FBR2RDLFNBQUcsRUFBRSxDQUhTO0FBSWRDLFdBQUssRUFBRSxDQUpPO0FBS2RDLGFBQU8sRUFBRSxDQUFDLENBQUQsQ0FMSztBQU1kTixrQkFBWSxFQUFFQSxZQU5BO0FBT2RPLHNCQUFnQixFQUFFLElBUEo7QUFRZGxCLGFBQU8sRUFBRSxFQVJLO0FBU2Q3RCxXQUFLLEVBQUUsRUFUTztBQVVka0YsbUJBQWEsRUFBRSxFQVZEO0FBV2RDLHVCQUFpQixFQUFFLENBWEw7QUFZZEUscUJBQWUsRUFBRSxFQVpIO0FBYWRDLG9CQUFjLEVBQUUsRUFiRjtBQWNkTCxnQkFBVSxFQUFFLEVBZEU7QUFlZEQsaUJBQVcsRUFBRSxFQWZDO0FBZ0JkSSxvQkFBYyxFQUFFO0FBaEJGLEtBQWhCO0FBa0JELEdBcEJZO0FBcUJiLDJCQUF5QixVQUN2QmxDLEdBRHVCLEVBRXZCK0YsT0FGdUIsRUFHdkJDLFNBSHVCLEVBSXZCQyxPQUp1QixFQUt2QkMsS0FMdUIsRUFNdkI3RyxPQU51QixFQU92QjtBQUNBLFFBQUk4RyxZQUFZLEdBQUc7QUFDakJKLGFBRGlCO0FBRWpCQyxlQUZpQjtBQUdqQkMsYUFIaUI7QUFJakJDLFdBSmlCO0FBS2pCN0c7QUFMaUIsS0FBbkI7QUFRQVosWUFBUSxDQUFDc0IsTUFBVCxDQUFnQkMsR0FBaEIsRUFBcUI7QUFBRTJELGVBQVMsRUFBRTtBQUFFNUIsa0JBQVUsRUFBRW9FO0FBQWQ7QUFBYixLQUFyQjtBQUNELEdBdENZO0FBdUNiLHdCQUFzQixVQUFTdkYsUUFBVCxFQUFtQlosR0FBbkIsRUFBd0I7QUFDNUN2QixZQUFRLENBQUNzQixNQUFULENBQWdCQyxHQUFoQixFQUFxQjtBQUFFMkQsZUFBUyxFQUFFO0FBQUVoRCxlQUFPLEVBQUVDO0FBQVg7QUFBYixLQUFyQjtBQUNELEdBekNZO0FBMENiLGdDQUE4QixVQUFTd0YsY0FBVCxFQUF5QjtBQUNyRCxRQUFJQyxHQUFHLEdBQUcsRUFBVjs7QUFDQSxTQUFLLElBQUlqSixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHZ0osY0FBYyxDQUFDbkksTUFBbkMsRUFBMkNiLENBQUMsRUFBNUMsRUFBZ0Q7QUFDOUNpSixTQUFHLENBQUM5SSxJQUFKLENBQVNpQixPQUFPLENBQUN3QyxPQUFSLENBQWdCO0FBQUV1QyxnQkFBUSxFQUFFNkMsY0FBYyxDQUFDaEosQ0FBRDtBQUExQixPQUFoQixDQUFUO0FBQ0Q7O0FBQ0QsV0FBT2lKLEdBQVA7QUFDRCxHQWhEWTtBQWlEYix1QkFBcUIsVUFBU3ZKLEtBQVQsRUFBZ0JrRCxHQUFoQixFQUFxQjtBQUN4Q3ZCLFlBQVEsQ0FBQ3NCLE1BQVQsQ0FBZ0JDLEdBQWhCLEVBQXFCO0FBQUUyRCxlQUFTLEVBQUU7QUFBRTdHO0FBQUY7QUFBYixLQUFyQjtBQUNELEdBbkRZO0FBb0RiLDBCQUF3QixVQUFTRixXQUFULEVBQXNCZ0QsVUFBdEIsRUFBa0NJLEdBQWxDLEVBQXVDO0FBQzdELFFBQUlsRCxLQUFLLEdBQUdjLEtBQUssQ0FBQ3VCLElBQU4sQ0FBVztBQUNyQnFDLGFBQU8sRUFBRTVFLFdBRFk7QUFFckJnRCxnQkFBVSxFQUFFQTtBQUZTLEtBQVgsRUFHVFIsS0FIUyxHQUdELENBSEMsQ0FBWjtBQUlBWCxZQUFRLENBQUNzQixNQUFULENBQWdCQyxHQUFoQixFQUFxQjtBQUFFMkQsZUFBUyxFQUFFO0FBQUU3RztBQUFGO0FBQWIsS0FBckI7QUFDRCxHQTFEWTtBQTJEYjtBQUNBLHlCQUF1QixVQUFTRixXQUFULEVBQXNCb0QsR0FBdEIsRUFBMkI7QUFDaEQsUUFBSXNHLFVBQVUsR0FBRzVILE9BQU8sQ0FBQ3NDLE9BQVIsQ0FBZ0I7QUFBRXZCLFVBQUksRUFBRTdDO0FBQVIsS0FBaEIsQ0FBakI7O0FBQ0EsUUFBSTtBQUNGNkIsY0FBUSxDQUFDc0IsTUFBVCxDQUFnQkMsR0FBaEIsRUFBcUI7QUFBRTJELGlCQUFTLEVBQUU7QUFBRXpCLHdCQUFjLEVBQUVvRTtBQUFsQjtBQUFiLE9BQXJCO0FBQ0EsYUFBTyxJQUFQO0FBQ0QsS0FIRCxDQUdFLE9BQU94QixDQUFQLEVBQVU7QUFDVkMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDRDtBQUNGLEdBcEVZO0FBcUViLDJCQUF5QixVQUFTUSxRQUFULEVBQW1CdEYsR0FBbkIsRUFBd0I7QUFDL0MsUUFBSTtBQUNGdkIsY0FBUSxDQUFDc0IsTUFBVCxDQUFnQkMsR0FBaEIsRUFBcUI7QUFBRUYsWUFBSSxFQUFFO0FBQUVxQyx5QkFBZSxFQUFFbUQ7QUFBbkI7QUFBUixPQUFyQjtBQUNBLGFBQU83RyxRQUFRLENBQUNVLElBQVQsQ0FBYztBQUFFYSxXQUFHLEVBQUVBO0FBQVAsT0FBZCxFQUE0QlosS0FBNUIsR0FBb0MsQ0FBcEMsQ0FBUDtBQUNELEtBSEQsQ0FHRSxPQUFPMEYsQ0FBUCxFQUFVO0FBQ1ZDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0Q7QUFDRixHQTVFWTtBQTZFYixrQ0FBZ0MsVUFBU2UsTUFBVCxFQUFpQjdGLEdBQWpCLEVBQXNCO0FBQ3BEdkIsWUFBUSxDQUFDc0IsTUFBVCxDQUFnQkMsR0FBaEIsRUFBcUI7QUFBRTJELGVBQVMsRUFBRTtBQUFFOUIsd0JBQWdCLEVBQUVnRTtBQUFwQjtBQUFiLEtBQXJCO0FBQ0QsR0EvRVk7QUFnRmIsNEJBQTBCLFVBQVN6QyxPQUFULEVBQWtCa0MsUUFBbEIsRUFBNEI7QUFDcEQsUUFBSWlCLGNBQWMsR0FBRztBQUNuQjVDLGVBQVMsRUFBRTtBQUFFdkIsc0JBQWMsRUFBRWtEO0FBQWxCLE9BRFE7QUFFbkJrQixXQUFLLEVBQUU7QUFDTHJFLHVCQUFlLEVBQUU7QUFDZjFDLGNBQUksRUFBRTZGLFFBQVEsQ0FBQzdGLElBREE7QUFFZkcsb0JBQVUsRUFBRTBGLFFBQVEsQ0FBQzFGO0FBRk47QUFEWjtBQUZZLEtBQXJCO0FBU0FuQixZQUFRLENBQUNzQixNQUFULENBQWdCO0FBQUVDLFNBQUcsRUFBRW9ELE9BQU8sQ0FBQ3BEO0FBQWYsS0FBaEIsRUFBc0N1RyxjQUF0QztBQUNBOUgsWUFBUSxDQUFDc0IsTUFBVCxDQUFnQjtBQUFFQyxTQUFHLEVBQUVvRCxPQUFPLENBQUNwRDtBQUFmLEtBQWhCLEVBQXNDO0FBQUV5RyxVQUFJLEVBQUU7QUFBRXhFLHlCQUFpQixFQUFFO0FBQXJCO0FBQVIsS0FBdEM7QUFDRCxHQTVGWTtBQTZGYiwyQkFBeUIsVUFBU21CLE9BQVQsRUFBa0I7QUFDekMsUUFBSTdCLElBQUksR0FBRzNELEtBQUssQ0FBQ3VCLElBQU4sQ0FBVztBQUNwQnFDLGFBQU8sRUFBRTRCLE9BQU8sQ0FBQ2xCLGNBQVIsQ0FBdUIsQ0FBdkIsRUFBMEJ6QyxJQURmO0FBRXBCRyxnQkFBVSxFQUFFd0QsT0FBTyxDQUFDbkIsaUJBQVIsR0FBNEI7QUFGcEIsS0FBWCxFQUdSN0MsS0FIUSxHQUdBLENBSEEsQ0FBWDs7QUFJQSxRQUFJbUMsSUFBSSxJQUFJQSxJQUFJLENBQUNtRixRQUFqQixFQUEyQjtBQUN6QixVQUFJLENBQUNsQixxQkFBcUIsQ0FBQ2pFLElBQUksQ0FBQ21GLFFBQU4sRUFBZ0J0RCxPQUFPLENBQUN0QixXQUF4QixDQUExQixFQUFnRTtBQUM5RHJELGdCQUFRLENBQUNzQixNQUFULENBQ0U7QUFBRUMsYUFBRyxFQUFFb0QsT0FBTyxDQUFDcEQ7QUFBZixTQURGLEVBRUU7QUFBRXlHLGNBQUksRUFBRTtBQUFFeEUsNkJBQWlCLEVBQUU7QUFBckI7QUFBUixTQUZGO0FBSUE7QUFDRDtBQUNGOztBQUNEeEQsWUFBUSxDQUFDc0IsTUFBVCxDQUFnQjtBQUFFQyxTQUFHLEVBQUVvRCxPQUFPLENBQUNwRDtBQUFmLEtBQWhCLEVBQXNDO0FBQUV5RyxVQUFJLEVBQUU7QUFBRXhFLHlCQUFpQixFQUFFO0FBQXJCO0FBQVIsS0FBdEM7QUFDRCxHQTVHWTtBQTZHYiwrQkFBNkIsVUFBU21CLE9BQVQsRUFBa0I7QUFDN0MsUUFBSTdCLElBQUksR0FBRzNELEtBQUssQ0FBQ3VCLElBQU4sQ0FBVztBQUNwQnFDLGFBQU8sRUFBRTRCLE9BQU8sQ0FBQ2xCLGNBQVIsQ0FBdUIsQ0FBdkIsRUFBMEJ6QyxJQURmO0FBRXBCRyxnQkFBVSxFQUFFd0QsT0FBTyxDQUFDbkIsaUJBQVIsR0FBNEI7QUFGcEIsS0FBWCxFQUdSN0MsS0FIUSxHQUdBLENBSEEsQ0FBWDs7QUFJQSxRQUFJbUMsSUFBSSxDQUFDbUYsUUFBVCxFQUFtQjtBQUNqQixVQUFJLENBQUNsQixxQkFBcUIsQ0FBQ2pFLElBQUksQ0FBQ21GLFFBQU4sRUFBZ0J0RCxPQUFPLENBQUN0QixXQUF4QixDQUExQixFQUFnRTtBQUM5RHJELGdCQUFRLENBQUNzQixNQUFULENBQ0U7QUFBRUMsYUFBRyxFQUFFb0QsT0FBTyxDQUFDcEQ7QUFBZixTQURGLEVBRUU7QUFBRXlHLGNBQUksRUFBRTtBQUFFeEUsNkJBQWlCLEVBQUUsQ0FBQztBQUF0QjtBQUFSLFNBRkY7QUFJQTtBQUNEO0FBQ0Y7O0FBRUR4RCxZQUFRLENBQUNzQixNQUFULENBQWdCO0FBQUVDLFNBQUcsRUFBRW9ELE9BQU8sQ0FBQ3BEO0FBQWYsS0FBaEIsRUFBc0M7QUFBRXlHLFVBQUksRUFBRTtBQUFFeEUseUJBQWlCLEVBQUUsQ0FBQztBQUF0QjtBQUFSLEtBQXRDO0FBQ0Q7QUE3SFksQ0FBZjs7QUFnSUEsSUFBSXRHLE1BQU0sQ0FBQytHLFFBQVgsRUFBcUI7QUFDbkI7QUFDQS9HLFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxTQUFmLEVBQTBCLE1BQU07QUFDOUIsUUFBSW5ILE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FBdkIsRUFBdUU7QUFDckUsYUFBT3ZFLFFBQVEsQ0FBQ1UsSUFBVCxDQUFjO0FBQUV1QixjQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsT0FBZCxDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJL0UsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEdBTEQsRUFGbUIsQ0FRbkI7O0FBQ0F2SCxRQUFNLENBQUNtSCxPQUFQLENBQWUsaUJBQWYsRUFBa0NPLE9BQU8sSUFBSTtBQUMzQyxVQUFNc0QsT0FBTyxHQUFHcEksUUFBUSxDQUFDeUMsT0FBVCxDQUFpQjtBQUFFTixZQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsS0FBakIsQ0FBaEI7O0FBQ0EsUUFBSWlHLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxVQUFSLENBQW1CQyxRQUFuQixDQUE0QnhELE9BQTVCLENBQWYsRUFBcUQ7QUFDbkQsYUFBT3lELE1BQU0sQ0FBQzNILElBQVAsQ0FBWTtBQUFFa0U7QUFBRixPQUFaLENBQVA7QUFDRDs7QUFDRCxVQUFNLElBQUkxSCxNQUFNLENBQUN1SCxLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0QsR0FORCxFQVRtQixDQWdCbkI7O0FBQ0F2SCxRQUFNLENBQUNtSCxPQUFQLENBQWUsY0FBZixFQUErQixNQUFNO0FBQ25DLFVBQU1pRSxLQUFLLEdBQUdELE1BQU0sQ0FBQzlGLE9BQVAsQ0FBZTtBQUFFTixZQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsS0FBZixDQUFkOztBQUNBLFFBQUlxRyxLQUFKLEVBQVc7QUFDVCxhQUFPRCxNQUFNLENBQUMzSCxJQUFQLENBQVk7QUFBRTZILGlCQUFTLEVBQUVELEtBQUssQ0FBQ0M7QUFBbkIsT0FBWixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJckwsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEdBTkQsRUFqQm1CLENBd0JuQjs7QUFDQXZILFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxNQUFNO0FBQ3RDLFVBQU02RCxPQUFPLEdBQUdwSSxRQUFRLENBQUN5QyxPQUFULENBQWlCO0FBQUVOLFlBQU0sRUFBRS9FLE1BQU0sQ0FBQytFLE1BQVA7QUFBVixLQUFqQixDQUFoQjs7QUFDQSxRQUFJaUcsT0FBSixFQUFhO0FBQ1gsYUFBT0csTUFBTSxDQUFDM0gsSUFBUCxDQUFZO0FBQUVrRSxlQUFPLEVBQUU7QUFBRTRELGFBQUcsRUFBRU4sT0FBTyxDQUFDQztBQUFmO0FBQVgsT0FBWixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJakwsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNELEdBTkQ7QUFPRCxDOzs7Ozs7Ozs7OztBQ3hMRHRILE1BQU0sQ0FBQ0csTUFBUCxDQUFjO0FBQUM2QixPQUFLLEVBQUMsTUFBSUE7QUFBWCxDQUFkO0FBQWlDLElBQUlqQyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxLQUFKO0FBQVUzRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwRyxPQUFLLENBQUN6RyxDQUFELEVBQUc7QUFBQ3lHLFNBQUssR0FBQ3pHLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTBHLFlBQUo7QUFBaUI1RyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5QyxTQUFPLENBQUN4QyxDQUFELEVBQUc7QUFBQzBHLGdCQUFZLEdBQUMxRyxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUl1QyxPQUFKO0FBQVl6QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUN5QyxTQUFPLENBQUN4QyxDQUFELEVBQUc7QUFBQ3VDLFdBQU8sR0FBQ3ZDLENBQVI7QUFBVTs7QUFBdEIsQ0FBdEIsRUFBOEMsQ0FBOUM7QUFXOU8sTUFBTThCLEtBQUssR0FBRyxJQUFJMkUsS0FBSyxDQUFDRSxVQUFWLENBQXFCLE9BQXJCLENBQWQ7QUFFUCxNQUFNeUUsVUFBVSxHQUFHLElBQUkxRSxZQUFKLENBQWlCO0FBQ2xDcUQsUUFBTSxFQUFFO0FBQ05YLFFBQUksRUFBRUMsTUFEQTtBQUVOZ0MsWUFBUSxFQUFFO0FBRkosR0FEMEI7QUFLbENDLGtCQUFnQixFQUFFO0FBQ2hCbEMsUUFBSSxFQUFFQztBQURVLEdBTGdCO0FBUWxDRCxNQUFJLEVBQUU7QUFDSkEsUUFBSSxFQUFFQztBQURGLEdBUjRCO0FBV2xDakYsWUFBVSxFQUFFO0FBQ1ZnRixRQUFJLEVBQUVDLE1BREk7QUFFVmdDLFlBQVEsRUFBRTtBQUZBLEdBWHNCO0FBZWxDM0YsU0FBTyxFQUFFO0FBQ1AwRCxRQUFJLEVBQUVDO0FBREMsR0FmeUI7QUFrQmxDMUgsWUFBVSxFQUFFO0FBQ1Z5SCxRQUFJLEVBQUVDLE1BREk7QUFFVmdDLFlBQVEsRUFBRTtBQUZBLEdBbEJzQjtBQXNCbENFLFdBQVMsRUFBRTtBQUNUbkMsUUFBSSxFQUFFRSxLQURHO0FBRVQrQixZQUFRLEVBQUU7QUFGRCxHQXRCdUI7QUEwQmxDRyxXQUFTLEVBQUU7QUFDVHBDLFFBQUksRUFBRUUsS0FERztBQUVUK0IsWUFBUSxFQUFFO0FBRkQsR0ExQnVCO0FBOEJsQ0ksV0FBUyxFQUFFO0FBQ1RyQyxRQUFJLEVBQUVFLEtBREc7QUFFVCtCLFlBQVEsRUFBRTtBQUZELEdBOUJ1QjtBQWtDbENLLFdBQVMsRUFBRTtBQUNUdEMsUUFBSSxFQUFFRSxLQURHO0FBRVQrQixZQUFRLEVBQUU7QUFGRCxHQWxDdUI7QUFzQ2xDTSxhQUFXLEVBQUU7QUFDWHZDLFFBQUksRUFBRUUsS0FESztBQUVYK0IsWUFBUSxFQUFFO0FBRkMsR0F0Q3FCO0FBMkNsQyxtQkFBaUI7QUFDZmpDLFFBQUksRUFBRUMsTUFEUztBQUVmZ0MsWUFBUSxFQUFFO0FBRkssR0EzQ2lCO0FBK0NsQyxpQkFBZTtBQUNiakMsUUFBSSxFQUFFQyxNQURPO0FBRWJnQyxZQUFRLEVBQUU7QUFGRyxHQS9DbUI7QUFtRGxDLGlCQUFlO0FBQ2JqQyxRQUFJLEVBQUVDLE1BRE87QUFFYmdDLFlBQVEsRUFBRTtBQUZHLEdBbkRtQjtBQXVEbEMsaUJBQWU7QUFDYmpDLFFBQUksRUFBRUMsTUFETztBQUViZ0MsWUFBUSxFQUFFO0FBRkcsR0F2RG1CO0FBMkRsQyxpQkFBZTtBQUNiakMsUUFBSSxFQUFFQyxNQURPO0FBRWJnQyxZQUFRLEVBQUU7QUFGRyxHQTNEbUI7QUFnRWxDTyxhQUFXLEVBQUU7QUFDWHhDLFFBQUksRUFBRUM7QUFESyxHQWhFcUI7QUFtRWxDd0MsYUFBVyxFQUFFO0FBQ1h6QyxRQUFJLEVBQUVDO0FBREssR0FuRXFCO0FBc0VsQzFELFNBQU8sRUFBRTtBQUNQeUQsUUFBSSxFQUFFMEM7QUFEQyxHQXRFeUI7QUEwRWxDQyxVQUFRLEVBQUU7QUFDUjNDLFFBQUksRUFBRTBDO0FBREUsR0ExRXdCO0FBNkVsQztBQUNBakcsT0FBSyxFQUFFO0FBQ0x1RCxRQUFJLEVBQUUwQztBQURELEdBOUUyQjtBQWlGbENFLFNBQU8sRUFBRTtBQUNQNUMsUUFBSSxFQUFFQyxNQURDO0FBRVBnQyxZQUFRLEVBQUU7QUFGSCxHQWpGeUI7QUFxRmxDWSxjQUFZLEVBQUU7QUFDWjdDLFFBQUksRUFBRUMsTUFETTtBQUVaZ0MsWUFBUSxFQUFFO0FBRkUsR0FyRm9CO0FBeUZsQztBQUNBYSxhQUFXLEVBQUU7QUFDWDlDLFFBQUksRUFBRStDLE9BREs7QUFFWGQsWUFBUSxFQUFFO0FBRkM7QUExRnFCLENBQWpCLEVBOEZoQjlCLFVBOUZnQixFQUFuQjtBQWdHQTFKLE1BQU0sQ0FBQzJILE9BQVAsQ0FBZTtBQUNiLGlCQUFlL0IsSUFBZixFQUFxQjtBQUNuQjNELFNBQUssQ0FBQzZDLE1BQU4sQ0FBYWMsSUFBYjtBQUNEOztBQUhZLENBQWY7O0FBTUEsSUFBSTVGLE1BQU0sQ0FBQytHLFFBQVgsRUFBcUI7QUFDbkIvRyxRQUFNLENBQUNtSCxPQUFQLENBQWUsT0FBZixFQUF3QixNQUFNO0FBQzVCLFdBQU9sRixLQUFLLENBQUN1QixJQUFOLENBQVcsRUFBWCxDQUFQO0FBQ0QsR0FGRDtBQUdBeEQsUUFBTSxDQUFDbUgsT0FBUCxDQUFlLFlBQWYsRUFBNkJvRixPQUFPLElBQUk7QUFDdEMsV0FBT3RLLEtBQUssQ0FBQ3VCLElBQU4sQ0FBVztBQUFFMEcsWUFBTSxFQUFFO0FBQUVvQixXQUFHLEVBQUVpQjtBQUFQO0FBQVYsS0FBWCxDQUFQO0FBQ0QsR0FGRDtBQUdBdk0sUUFBTSxDQUFDbUgsT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBUytDLE1BQVQsRUFBaUI7QUFDMUMsV0FBT2pJLEtBQUssQ0FBQ3VCLElBQU4sQ0FBVztBQUFFMEcsWUFBTSxFQUFFQTtBQUFWLEtBQVgsQ0FBUDtBQUNELEdBRkQ7QUFJQWxLLFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxnQkFBZixFQUFpQ3JELElBQUksSUFBSTtBQUN2QyxXQUFPN0IsS0FBSyxDQUFDdUIsSUFBTixDQUFXO0FBQUVnSixpQkFBVyxFQUFFMUk7QUFBZixLQUFYLENBQVA7QUFDRCxHQUZEO0FBR0QsQzs7Ozs7Ozs7Ozs7QUNqSUQ3RCxNQUFNLENBQUNHLE1BQVAsQ0FBYztBQUFDd0MsVUFBUSxFQUFDLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJNUMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUcsS0FBSjtBQUFVM0csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMEcsT0FBSyxDQUFDekcsQ0FBRCxFQUFHO0FBQUN5RyxTQUFLLEdBQUN6RyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkwRyxZQUFKO0FBQWlCNUcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDeUMsU0FBTyxDQUFDeEMsQ0FBRCxFQUFHO0FBQUMwRyxnQkFBWSxHQUFDMUcsQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJcUMsUUFBSjtBQUFhdkMsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ3NDLFVBQVEsQ0FBQ3JDLENBQUQsRUFBRztBQUFDcUMsWUFBUSxHQUFDckMsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJMkMsUUFBSjtBQUFhN0MsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDNEMsVUFBUSxDQUFDM0MsQ0FBRCxFQUFHO0FBQUMyQyxZQUFRLEdBQUMzQyxDQUFUO0FBQVc7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBQXNELElBQUl5SixVQUFKO0FBQWUzSixNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUMwSixZQUFVLENBQUN6SixDQUFELEVBQUc7QUFBQ3lKLGNBQVUsR0FBQ3pKLENBQVg7QUFBYTs7QUFBNUIsQ0FBeEIsRUFBc0QsQ0FBdEQ7QUFPdlksTUFBTXlDLFFBQVEsR0FBRyxJQUFJZ0UsS0FBSyxDQUFDRSxVQUFWLENBQXFCLFVBQXJCLENBQWpCOztBQUVQLElBQUk5RyxNQUFNLENBQUMrRyxRQUFYLEVBQXFCO0FBQ25CO0FBQ0EvRyxRQUFNLENBQUNtSCxPQUFQLENBQWUsU0FBZixFQUEwQixVQUFTeEMsU0FBVCxFQUFvQjtBQUM1QyxXQUFPL0IsUUFBUSxDQUFDWSxJQUFULENBQWM7QUFBRW1DLGtCQUFZLEVBQUVoQjtBQUFoQixLQUFkLENBQVA7QUFDRCxHQUZEO0FBR0EzRSxRQUFNLENBQUNtSCxPQUFQLENBQWUsaUJBQWYsRUFBa0MsVUFBU3BDLE1BQVQsRUFBaUI7QUFDakQsUUFBSS9FLE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FBdkIsRUFBdUU7QUFDckUsYUFBT3pFLFFBQVEsQ0FBQ1ksSUFBVCxDQUFjO0FBQUV1QixjQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsT0FBZCxDQUFQO0FBQ0Q7O0FBQ0QsVUFBTSxJQUFJL0UsTUFBTSxDQUFDdUgsS0FBWCxDQUFpQixlQUFqQixDQUFOO0FBQ0QsR0FMRCxFQUxtQixDQVduQjs7QUFDQXZILFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFlBQVc7QUFDdEMsUUFBSW5ILE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFFBQUQsQ0FBbEMsQ0FBdkIsRUFBc0U7QUFDcEUsYUFBT3pFLFFBQVEsQ0FBQ1ksSUFBVCxDQUFjLEVBQWQsQ0FBUDtBQUNEOztBQUNELFVBQU0sSUFBSXhELE1BQU0sQ0FBQ3VILEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRCxHQUxEO0FBTUQ7O0FBRUR2SCxNQUFNLENBQUMySCxPQUFQLENBQWU7QUFDYixxQkFBbUIsVUFBUzVDLE1BQVQsRUFBaUJZLFlBQWpCLEVBQStCO0FBQ2hEL0MsWUFBUSxDQUFDa0MsTUFBVCxDQUFnQjtBQUNkQyxZQUFNLEVBQUVBLE1BRE07QUFFZFksa0JBQVksRUFBRUEsWUFGQTtBQUdkWCxhQUFPLEVBQUU7QUFISyxLQUFoQjtBQUtELEdBUFk7QUFTYixxQkFBbUIsVUFBU0QsTUFBVCxFQUFpQjtBQUNsQyxRQUFJL0UsTUFBTSxDQUFDK0csUUFBWCxFQUFxQjtBQUNuQixVQUFJaUUsT0FBTyxHQUFHLElBQWQ7O0FBQ0EsVUFBSWhMLE1BQU0sQ0FBQytFLE1BQVAsTUFBbUJ0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FBdkIsRUFBdUU7QUFDckUyRCxlQUFPLEdBQUdwSSxRQUFRLENBQUN5QyxPQUFULENBQWlCO0FBQUVOO0FBQUYsU0FBakIsQ0FBVjtBQUNBLFlBQUksQ0FBQ2lHLE9BQUwsRUFBYyxNQUFNLElBQUloTCxNQUFNLENBQUN1SCxLQUFYLENBQWlCLHdCQUFqQixDQUFOO0FBQ2YsT0FIRCxNQUdPLElBQ0x2SCxNQUFNLENBQUMrRSxNQUFQLE1BQ0F0QyxLQUFLLENBQUMyRSxZQUFOLENBQW1CcEgsTUFBTSxDQUFDcUgsSUFBUCxFQUFuQixFQUFrQyxDQUFDLFNBQUQsQ0FBbEMsQ0FGSyxFQUdMO0FBQ0EyRCxlQUFPLEdBQUdwSSxRQUFRLENBQUN5QyxPQUFULENBQWlCO0FBQUVOLGdCQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsU0FBakIsQ0FBVjtBQUNEOztBQUNELFVBQUlpRyxPQUFKLEVBQWE7QUFDWCxjQUFNQyxVQUFVLEdBQUdyQixVQUFVLENBQUNwRyxJQUFYLENBQWdCO0FBQ2pDYSxhQUFHLEVBQUU7QUFBRWlILGVBQUcsRUFBRU4sT0FBTyxDQUFDQztBQUFmO0FBRDRCLFNBQWhCLENBQW5CO0FBR0FBLGtCQUFVLENBQUN3QixPQUFYLENBQW1CQyxTQUFTLElBQUk7QUFDOUJDLG1CQUFTLENBQUNqRyxNQUFWLENBQWlCO0FBQUVyQyxlQUFHLEVBQUU7QUFBRWlILGlCQUFHLEVBQUVvQixTQUFTLENBQUNFO0FBQWpCO0FBQVAsV0FBakI7QUFDQTlKLGtCQUFRLENBQUM0RCxNQUFULENBQWdCO0FBQUUzQixrQkFBTSxFQUFFO0FBQUV1RyxpQkFBRyxFQUFFb0IsU0FBUyxDQUFDN0U7QUFBakI7QUFBVixXQUFoQjtBQUNBN0gsZ0JBQU0sQ0FBQzJHLEtBQVAsQ0FBYUQsTUFBYixDQUFvQjtBQUFFckMsZUFBRyxFQUFFO0FBQUVpSCxpQkFBRyxFQUFFb0IsU0FBUyxDQUFDN0U7QUFBakI7QUFBUCxXQUFwQjtBQUNELFNBSkQ7QUFLQStCLGtCQUFVLENBQUNsRCxNQUFYLENBQWtCO0FBQUVyQyxhQUFHLEVBQUU7QUFBRWlILGVBQUcsRUFBRU4sT0FBTyxDQUFDQztBQUFmO0FBQVAsU0FBbEI7QUFDQXJJLGdCQUFRLENBQUM4RCxNQUFULENBQWdCO0FBQUUzQixnQkFBTSxFQUFFaUcsT0FBTyxDQUFDakc7QUFBbEIsU0FBaEI7QUFDQS9FLGNBQU0sQ0FBQzJHLEtBQVAsQ0FBYUQsTUFBYixDQUFvQjtBQUFFckMsYUFBRyxFQUFFMkcsT0FBTyxDQUFDakc7QUFBZixTQUFwQjtBQUNELE9BWkQsTUFZTztBQUNMLGNBQU0sSUFBSS9FLE1BQU0sQ0FBQ3VILEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDRDtBQUNGO0FBQ0Y7QUFyQ1ksQ0FBZixFOzs7Ozs7Ozs7OztBQzdCQXRILE1BQU0sQ0FBQ0csTUFBUCxDQUFjO0FBQUN5TSxRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUk3TSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5RyxLQUFKO0FBQVUzRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwRyxPQUFLLENBQUN6RyxDQUFELEVBQUc7QUFBQ3lHLFNBQUssR0FBQ3pHLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTBHLFlBQUo7QUFBaUI1RyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN5QyxTQUFPLENBQUN4QyxDQUFELEVBQUc7QUFBQzBHLGdCQUFZLEdBQUMxRyxDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlxQyxRQUFKO0FBQWF2QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQkFBWixFQUFtQztBQUFDc0MsVUFBUSxDQUFDckMsQ0FBRCxFQUFHO0FBQUNxQyxZQUFRLEdBQUNyQyxDQUFUO0FBQVc7O0FBQXhCLENBQW5DLEVBQTZELENBQTdEO0FBS2pQLE1BQU0wTSxNQUFNLEdBQUcsSUFBSWpHLEtBQUssQ0FBQ0UsVUFBVixDQUFxQixRQUFyQixDQUFmOztBQUVQLElBQUk5RyxNQUFNLENBQUMrRyxRQUFYLEVBQXFCO0FBQ25CL0csUUFBTSxDQUFDbUgsT0FBUCxDQUFlLGFBQWYsRUFBOEIsWUFBVztBQUN2QyxXQUFPMEYsTUFBTSxDQUFDckosSUFBUCxDQUFZO0FBQUV1QixZQUFNLEVBQUUvRSxNQUFNLENBQUMrRSxNQUFQO0FBQVYsS0FBWixDQUFQO0FBQ0QsR0FGRDtBQUdBL0UsUUFBTSxDQUFDMkgsT0FBUCxDQUFlO0FBQ2IscUJBQWlCLFVBQVM1QyxNQUFULEVBQWlCa0QsS0FBakIsRUFBd0I7QUFDdkM0RSxZQUFNLENBQUMvSCxNQUFQLENBQWM7QUFDWkMsY0FBTSxFQUFFQSxNQURJO0FBRVprRCxhQUFLLEVBQUVBO0FBRkssT0FBZDtBQUlEO0FBTlksR0FBZjtBQVFELEM7Ozs7Ozs7Ozs7O0FDbkJEaEksTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQzhCLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSWxDLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXlHLEtBQUo7QUFBVTNHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBHLE9BQUssQ0FBQ3pHLENBQUQsRUFBRztBQUFDeUcsU0FBSyxHQUFDekcsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJMEcsWUFBSjtBQUFpQjVHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lDLFNBQU8sQ0FBQ3hDLENBQUQsRUFBRztBQUFDMEcsZ0JBQVksR0FBQzFHLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFJN0ssTUFBTStCLFFBQVEsR0FBRyxJQUFJMEUsS0FBSyxDQUFDRSxVQUFWLENBQXFCLFVBQXJCLENBQWpCO0FBRVAsTUFBTXdDLGNBQWMsR0FBRyxJQUFJekMsWUFBSixDQUFpQjtBQUN0Qy9DLE1BQUksRUFBRTtBQUNKeUYsUUFBSSxFQUFFQztBQURGLEdBRGdDO0FBS3RDM0QsU0FBTyxFQUFFO0FBQ1AwRCxRQUFJLEVBQUVDO0FBREMsR0FMNkI7QUFTdENzRCxZQUFVLEVBQUU7QUFDVnZELFFBQUksRUFBRUMsTUFESTtBQUVWZ0MsWUFBUSxFQUFFO0FBRkEsR0FUMEI7QUFhdEN1QixVQUFRLEVBQUU7QUFDUnhELFFBQUksRUFBRStDO0FBREUsR0FiNEI7QUFpQnRDVSxRQUFNLEVBQUU7QUFDTnpELFFBQUksRUFBRUM7QUFEQTtBQWpCOEIsQ0FBakIsRUFvQnBCRSxVQXBCb0IsRUFBdkI7O0FBc0JBLElBQUkxSixNQUFNLENBQUMrRyxRQUFYLEVBQXFCO0FBQ25CL0csUUFBTSxDQUFDbUgsT0FBUCxDQUFlLFVBQWYsRUFBMkIsTUFBTTtBQUMvQixXQUFPakYsUUFBUSxDQUFDc0IsSUFBVCxDQUFjLEVBQWQsQ0FBUDtBQUNELEdBRkQ7QUFHRDs7QUFFRHhELE1BQU0sQ0FBQzJILE9BQVAsQ0FBZTtBQUNiLG9CQUFrQmdDLFFBQWxCLEVBQTRCO0FBQzFCekgsWUFBUSxDQUFDNEMsTUFBVCxDQUFnQjZFLFFBQWhCO0FBQ0Q7O0FBSFksQ0FBZixFOzs7Ozs7Ozs7OztBQ2xDQSxJQUFJM0osTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMEcsWUFBSjtBQUFpQjVHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3lDLFNBQU8sQ0FBQ3hDLENBQUQsRUFBRztBQUFDMEcsZ0JBQVksR0FBQzFHLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXFDLFFBQUo7QUFBYXZDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNzQyxVQUFRLENBQUNyQyxDQUFELEVBQUc7QUFBQ3FDLFlBQVEsR0FBQ3JDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBbkMsRUFBNkQsQ0FBN0Q7QUFBZ0UsSUFBSWdMLE1BQUo7QUFBV2xMLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ2lMLFFBQU0sQ0FBQ2hMLENBQUQsRUFBRztBQUFDZ0wsVUFBTSxHQUFDaEwsQ0FBUDtBQUFTOztBQUFwQixDQUF6QixFQUErQyxDQUEvQztBQUFrRCxJQUFJeUMsUUFBSjtBQUFhM0MsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDMEMsVUFBUSxDQUFDekMsQ0FBRCxFQUFHO0FBQUN5QyxZQUFRLEdBQUN6QyxDQUFUO0FBQVc7O0FBQXhCLENBQXpCLEVBQW1ELENBQW5EO0FBQXNELElBQUkwQyxPQUFKO0FBQVk1QyxNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUMyQyxTQUFPLENBQUMxQyxDQUFELEVBQUc7QUFBQzBDLFdBQU8sR0FBQzFDLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEIsRUFBZ0QsQ0FBaEQ7QUFPcldxQyxRQUFRLENBQUN5SyxlQUFULENBQXlCNUYsSUFBSSxJQUFJO0FBQy9CLFNBQU8sSUFBUDtBQUNELENBRkQ7O0FBSUEsSUFBSXJILE1BQU0sQ0FBQytHLFFBQVgsRUFBcUI7QUFDbkI7QUFDQS9HLFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxVQUFTTyxPQUFULEVBQWtCLENBQUUsQ0FBdkQ7QUFFQTFILFFBQU0sQ0FBQ21ILE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFVBQVMrRixRQUFULEVBQW1CO0FBQzlDLFdBQU9sTixNQUFNLENBQUMyRyxLQUFQLENBQWF0QixPQUFiLENBQXFCO0FBQUVHLGNBQVEsRUFBRTBIO0FBQVosS0FBckIsQ0FBUDtBQUNELEdBRkQ7QUFHRDs7QUFDRGxOLE1BQU0sQ0FBQzJILE9BQVAsQ0FBZTtBQUNiO0FBQ0EsZ0JBQWMsVUFBU00sS0FBVCxFQUFnQnhELEtBQWhCLEVBQXVCQyxRQUF2QixFQUFpQztBQUM3QyxRQUFJO0FBQ0YsWUFBTXlJLE1BQU0sR0FBR2hGLElBQUksQ0FBQ3BHLElBQUwsQ0FDYixLQURhLEVBRWIsOERBRmEsRUFHYjtBQUNFcUcsZUFBTyxFQUFFO0FBQUVDLHVCQUFhLEVBQUVKO0FBQWpCO0FBRFgsT0FIYSxDQUFmO0FBT0EsVUFBSW1GLFFBQVEsR0FBR2hNLElBQUksQ0FBQ0MsS0FBTCxDQUFXOEwsTUFBTSxDQUFDekosT0FBbEIsQ0FBZjtBQUNBLFVBQUlpQyxZQUFZLEdBQUd5SCxRQUFRLENBQUM1RSxJQUFULENBQWNHLEVBQWpDOztBQUNBLFVBQUkzSSxNQUFNLENBQUMyRyxLQUFQLENBQWF0QixPQUFiLENBQXFCO0FBQUVHLGdCQUFRLEVBQUVmO0FBQVosT0FBckIsQ0FBSixFQUErQztBQUM3QyxZQUFJNEMsSUFBSSxHQUFHckgsTUFBTSxDQUFDMkcsS0FBUCxDQUFhdEIsT0FBYixDQUFxQjtBQUFFRyxrQkFBUSxFQUFFZjtBQUFaLFNBQXJCLENBQVg7QUFDRCxPQUZELE1BRU87QUFDTCxjQUFNTSxNQUFNLEdBQUd2QyxRQUFRLENBQUNvQyxVQUFULENBQW9CO0FBQ2pDWSxrQkFBUSxFQUFFZixLQUR1QjtBQUVqQ0Msa0JBQVEsRUFBRUE7QUFGdUIsU0FBcEIsQ0FBZjtBQUlEOztBQUNELFVBQUkySSxPQUFPLEdBQUcsQ0FBQ0YsTUFBRCxFQUFTeEgsWUFBVCxDQUFkO0FBQ0EsYUFBTzBILE9BQVA7QUFDRCxLQXBCRCxDQW9CRSxPQUFPbEUsQ0FBUCxFQUFVO0FBQ1ZDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaLEVBRFUsQ0FFVjs7QUFDQSxhQUFPLEtBQVA7QUFDRDtBQUNGLEdBNUJZO0FBNkJiLDBCQUF3QixVQUFTM0QsUUFBVCxFQUFtQkcsWUFBbkIsRUFBaUM7QUFDdkQsUUFBSWhCLFNBQVMsR0FBRzNFLE1BQU0sQ0FBQzJHLEtBQVAsQ0FBYXRCLE9BQWIsQ0FBcUI7QUFBRUcsY0FBUSxFQUFFQTtBQUFaLEtBQXJCLEVBQTZDbkIsR0FBN0Q7O0FBQ0E1QixTQUFLLENBQUNvQyxlQUFOLENBQXNCRixTQUF0QixFQUFpQyxTQUFqQztBQUNBM0UsVUFBTSxDQUFDK0IsSUFBUCxDQUFZLGlCQUFaLEVBQStCNEMsU0FBL0IsRUFBMENnQixZQUExQztBQUNBLFdBQU9oQixTQUFQO0FBQ0QsR0FsQ1k7QUFtQ2IseUJBQXVCLFVBQVNhLFFBQVQsRUFBbUJHLFlBQW5CLEVBQWlDO0FBQ3RELFFBQUkyQixTQUFTLEdBQUd0SCxNQUFNLENBQUMyRyxLQUFQLENBQWF0QixPQUFiLENBQXFCO0FBQUVHLGNBQVEsRUFBRUE7QUFBWixLQUFyQixFQUE2Q25CLEdBQTdEOztBQUNBNUIsU0FBSyxDQUFDb0MsZUFBTixDQUFzQnlDLFNBQXRCLEVBQWlDLFNBQWpDO0FBQ0F0SCxVQUFNLENBQUMrQixJQUFQLENBQVksaUJBQVosRUFBK0J1RixTQUEvQixFQUEwQzNCLFlBQTFDO0FBQ0EsV0FBTzJCLFNBQVA7QUFDRDtBQXhDWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDbkJBckgsTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQ2tOLFVBQVEsRUFBQyxNQUFJQTtBQUFkLENBQWQ7O0FBQU8sU0FBU0EsUUFBVCxDQUFrQmhHLFNBQWxCLEVBQTZCNEMsTUFBN0IsRUFBcUM7QUFDMUMsUUFBTXRFLElBQUksR0FBR3NFLE1BQWI7QUFDRCxDOzs7Ozs7Ozs7OztBQ0ZEakssTUFBTSxDQUFDRyxNQUFQLENBQWM7QUFBQ21OLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkOztBQUFPLFNBQVNBLFVBQVQsQ0FBb0JDLFFBQXBCLEVBQThCQyxlQUE5QixFQUErQ0MsZUFBL0MsRUFBZ0U7QUFDckUsUUFBTUMsT0FBTyxHQUFHSCxRQUFRLENBQUNJLFNBQXpCO0FBQ0EsTUFBSUMsVUFBVSxHQUFHLENBQWpCLENBRnFFLENBSXJFOztBQUNBLE1BQUlKLGVBQWUsQ0FBQ25MLE1BQWhCLEdBQXlCLENBQTdCLEVBQWdDO0FBQzlCbUwsbUJBQWUsR0FBR0EsZUFBZSxDQUFDSyxNQUFoQixDQUF1QjdELElBQUksSUFBSTtBQUMvQyxhQUFPQSxJQUFJLENBQUN0QixFQUFMLENBQVFvRixRQUFSLE9BQXVCUCxRQUFRLENBQUNRLFVBQVQsQ0FBb0JELFFBQXBCLEVBQTlCO0FBQ0QsS0FGaUIsQ0FBbEI7QUFHRDs7QUFFRCxPQUFLLElBQUl0TSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHa00sT0FBTyxDQUFDckwsTUFBNUIsRUFBb0NiLENBQUMsRUFBckMsRUFBeUM7QUFDdkMsUUFBSXdNLGdCQUFnQixHQUNsQlIsZUFBZSxDQUFDbkwsTUFBaEIsR0FBeUIsQ0FBekIsR0FDSW1MLGVBQWUsQ0FBQyxDQUFELENBQWYsQ0FBbUJTLE1BQW5CLENBQTBCaEQsUUFBMUIsQ0FBbUN5QyxPQUFPLENBQUNsTSxDQUFELENBQTFDLENBREosR0FFSSxLQUhOO0FBSUEsUUFBSTBNLGVBQWUsR0FBR1QsZUFBZSxDQUFDVSxPQUFoQixDQUF3QmxELFFBQXhCLENBQWlDeUMsT0FBTyxDQUFDbE0sQ0FBRCxDQUF4QyxDQUF0Qjs7QUFFQSxRQUFJd00sZ0JBQWdCLElBQUlFLGVBQXhCLEVBQXlDO0FBQ3ZDLFVBQUlFLGFBQWEsR0FDZlgsZUFBZSxDQUFDWSxPQUFoQixLQUE0Qm5FLFNBQTVCLElBQ0F1RCxlQUFlLENBQUNZLE9BQWhCLENBQXdCcEQsUUFBeEIsQ0FBaUN5QyxPQUFPLENBQUNsTSxDQUFELENBQXhDLENBRkY7O0FBR0EsVUFBSSxDQUFDNE0sYUFBTCxFQUFvQjtBQUNsQlIsa0JBQVU7QUFDWDtBQUNGO0FBQ0Y7O0FBQ0QsTUFBSVUsY0FBYyxHQUFHLEVBQXJCOztBQUNBLE1BQUlWLFVBQVUsR0FBRyxDQUFqQixFQUFvQjtBQUNsQlUsa0JBQWMsQ0FBQzNNLElBQWYsQ0FBb0I4TCxlQUFwQjtBQUNEOztBQUVELE1BQUljLE1BQU0sR0FBRztBQUNYWCxjQURXO0FBRVhZLG9CQUFnQixFQUFFZCxPQUFPLENBQUNyTCxNQUZmO0FBR1hvTSxrQkFBYyxFQUFFaEIsZUFBZSxDQUFDWSxPQUhyQjtBQUlYQztBQUpXLEdBQWI7QUFPQSxTQUFPQyxNQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUN4Q0R2TyxNQUFNLENBQUNHLE1BQVAsQ0FBYztBQUFDdU8sV0FBUyxFQUFDLE1BQUlBO0FBQWYsQ0FBZDtBQUF5QyxJQUFJM08sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeU8sTUFBSjtBQUFXM08sTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQ3lDLFNBQU8sQ0FBQ3hDLENBQUQsRUFBRztBQUFDeU8sVUFBTSxHQUFDek8sQ0FBUDtBQUFTOztBQUFyQixDQUE5QixFQUFxRCxDQUFyRDtBQUF3RCxJQUFJeUcsS0FBSjtBQUFVM0csTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMEcsT0FBSyxDQUFDekcsQ0FBRCxFQUFHO0FBQUN5RyxTQUFLLEdBQUN6RyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkyQyxRQUFKO0FBQWE3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDNEMsVUFBUSxDQUFDM0MsQ0FBRCxFQUFHO0FBQUMyQyxZQUFRLEdBQUMzQyxDQUFUO0FBQVc7O0FBQXhCLENBQXpDLEVBQW1FLENBQW5FO0FBQXNFLElBQUk4QixLQUFKO0FBQVVoQyxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWixFQUFzQztBQUFDK0IsT0FBSyxDQUFDOUIsQ0FBRCxFQUFHO0FBQUM4QixTQUFLLEdBQUM5QixDQUFOO0FBQVE7O0FBQWxCLENBQXRDLEVBQTBELENBQTFEOztBQU85VCxTQUFTd08sU0FBVCxDQUFtQnJILFNBQW5CLEVBQThCNEMsTUFBOUIsRUFBc0MyRSxnQkFBdEMsRUFBd0Q7QUFDN0QsUUFBTXBILE9BQU8sR0FBRzNFLFFBQVEsQ0FBQ3VDLE9BQVQsQ0FBaUI7QUFBRWhCLE9BQUcsRUFBRWlEO0FBQVAsR0FBakIsQ0FBaEI7QUFDQSxNQUFJMUIsSUFBSSxHQUFHa0osT0FBTyxDQUFDeEgsU0FBRCxFQUFZNEMsTUFBWixDQUFsQjtBQUNBLE1BQUksQ0FBQ3RFLElBQUwsRUFBVztBQUNYbUoseUJBQXVCLENBQUN0SCxPQUFELEVBQVU3QixJQUFWLEVBQWdCaUosZ0JBQWhCLENBQXZCO0FBQ0FHLHNCQUFvQixDQUFDdkgsT0FBRCxFQUFVN0IsSUFBVixFQUFnQmlKLGdCQUFoQixDQUFwQjtBQUNBSSxlQUFhLENBQUN4SCxPQUFELEVBQVU3QixJQUFWLENBQWI7QUFDRDs7QUFFRDs7Ozs7QUFLQSxTQUFTa0osT0FBVCxDQUFpQnhILFNBQWpCLEVBQTRCNEMsTUFBNUIsRUFBb0M7QUFDbEMsTUFBSTtBQUNGLFFBQUlnRixXQUFXLEdBQUdwTSxRQUFRLENBQUNVLElBQVQsQ0FDaEI7QUFBRWEsU0FBRyxFQUFFaUQsU0FBUDtBQUFrQixzQkFBZ0I0QztBQUFsQyxLQURnQixFQUVoQjtBQUFFaUYsWUFBTSxFQUFFO0FBQUUsbUJBQVcsQ0FBYjtBQUFnQjlLLFdBQUcsRUFBRTtBQUFyQjtBQUFWLEtBRmdCLEVBR2hCWixLQUhnQixHQUdSLENBSFEsQ0FBbEI7QUFJQSxRQUFJLENBQUN5TCxXQUFMLEVBQWtCLE9BQU8sSUFBUDtBQUNsQixXQUFPQSxXQUFXLENBQUMvTixLQUFaLENBQWtCLENBQWxCLENBQVA7QUFDRCxHQVBELENBT0UsT0FBT2lPLEtBQVAsRUFBYztBQUNkaEcsV0FBTyxDQUFDQyxHQUFSLENBQVkrRixLQUFaO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7O0FBS0EsU0FBU0gsYUFBVCxDQUF1QnhILE9BQXZCLEVBQWdDN0IsSUFBaEMsRUFBc0M7QUFDcEMsTUFBSXlKLE9BQU8sR0FBR0MsTUFBTSxHQUFHdEMsTUFBVCxDQUFnQixnQ0FBaEIsQ0FBZDtBQUNBcEgsTUFBSSxDQUFDLFNBQUQsQ0FBSixHQUFrQnlKLE9BQWxCO0FBQ0F6SixNQUFJLENBQUMsV0FBRCxDQUFKLEdBQW9CLFFBQXBCO0FBRUEySixtQkFBaUIsQ0FBQzlILE9BQU8sQ0FBQ3BELEdBQVQsRUFBYztBQUM3Qm1MLFNBQUssRUFBRTtBQUFFckosaUJBQVcsRUFBRVA7QUFBZixLQURzQjtBQUU3QnpCLFFBQUksRUFBRTtBQUFFK0Isc0JBQWdCLEVBQUVOLElBQUksQ0FBQ3NFO0FBQXpCLEtBRnVCO0FBRzdCVyxTQUFLLEVBQUU7QUFBRTFKLFdBQUssRUFBRTtBQUFFK0ksY0FBTSxFQUFFdEUsSUFBSSxDQUFDc0U7QUFBZjtBQUFULEtBSHNCO0FBSTdCWSxRQUFJLEVBQUU7QUFBRXhFLHVCQUFpQixFQUFFO0FBQXJCO0FBSnVCLEdBQWQsQ0FBakI7QUFNRDtBQUVEOzs7Ozs7OztBQU1BLFNBQVN5SSx1QkFBVCxDQUFpQ3RILE9BQWpDLEVBQTBDN0IsSUFBMUMsRUFBZ0RpSixnQkFBaEQsRUFBa0U7QUFDaEUsTUFBSVksT0FBTyxHQUFHN0osSUFBSSxDQUFDRSxPQUFuQjtBQUNBLE1BQUlFLEtBQUssR0FBR3lCLE9BQU8sQ0FBQ3pCLEtBQXBCLENBRmdFLENBSWhFOztBQUNBLFFBQU0wSixTQUFTLEdBQUcxSixLQUFLLEdBQUdBLEtBQVIsR0FBZ0IsRUFBbEMsQ0FMZ0UsQ0FPaEU7O0FBQ0EsTUFBSTZJLGdCQUFnQixJQUFJQSxnQkFBZ0IsSUFBSSxDQUE1QyxFQUErQztBQUM3Q1ksV0FBTyxHQUFHRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsT0FBTyxHQUFHWixnQkFBckIsQ0FBVjtBQUNEOztBQUVELE1BQUlnQixNQUFNLEdBQUdwSSxPQUFPLENBQUMxQixHQUFSLEdBQWMwSixPQUEzQjs7QUFFQSxNQUFJSSxNQUFNLEdBQUdILFNBQWIsRUFBd0I7QUFDdEIxSixTQUFLO0FBQ0w2SixVQUFNLElBQUlILFNBQVY7QUFDRDs7QUFFREgsbUJBQWlCLENBQUM5SCxPQUFPLENBQUNwRCxHQUFULEVBQWM7QUFBRUYsUUFBSSxFQUFFO0FBQUU2QixXQUFLLEVBQUVBLEtBQVQ7QUFBZ0JELFNBQUcsRUFBRThKO0FBQXJCO0FBQVIsR0FBZCxDQUFqQjtBQUNEO0FBRUQ7Ozs7Ozs7O0FBTUEsU0FBU2Isb0JBQVQsQ0FBOEJ2SCxPQUE5QixFQUF1QzdCLElBQXZDLEVBQTZDaUosZ0JBQTdDLEVBQStEO0FBQzdELE1BQUlpQixVQUFVLEdBQUdsSyxJQUFJLENBQUNFLE9BQXRCOztBQUNBLE1BQUkrSSxnQkFBZ0IsSUFBSUEsZ0JBQWdCLElBQUksQ0FBNUMsRUFBK0M7QUFDN0NpQixjQUFVLEdBQUdILElBQUksQ0FBQ0MsS0FBTCxDQUFXRSxVQUFVLEdBQUdqQixnQkFBeEIsQ0FBYjtBQUNEOztBQUVEVSxtQkFBaUIsQ0FBQzlILE9BQU8sQ0FBQ3BELEdBQVQsRUFBYztBQUFFeUcsUUFBSSxFQUFFO0FBQUVoRixhQUFPLEVBQUVnSztBQUFYO0FBQVIsR0FBZCxDQUFqQjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQSxTQUFTUCxpQkFBVCxDQUEyQmpJLFNBQTNCLEVBQXNDa0IsSUFBdEMsRUFBNEM7QUFDMUMxRixVQUFRLENBQUNzQixNQUFULENBQWdCO0FBQUVDLE9BQUcsRUFBRWlEO0FBQVAsR0FBaEIsRUFBb0NrQixJQUFwQztBQUNELEM7Ozs7Ozs7Ozs7O0FDdEdELElBQUl4SSxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl5TyxNQUFKO0FBQVczTyxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQkFBWixFQUE4QjtBQUFDeUMsU0FBTyxDQUFDeEMsQ0FBRCxFQUFHO0FBQUN5TyxVQUFNLEdBQUN6TyxDQUFQO0FBQVM7O0FBQXJCLENBQTlCLEVBQXFELENBQXJEO0FBQXdELElBQUltTixRQUFKO0FBQWFyTixNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDb04sVUFBUSxDQUFDbk4sQ0FBRCxFQUFHO0FBQUNtTixZQUFRLEdBQUNuTixDQUFUO0FBQVc7O0FBQXhCLENBQTNDLEVBQXFFLENBQXJFO0FBQXdFLElBQUl3TyxTQUFKO0FBQWMxTyxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDeU8sV0FBUyxDQUFDeE8sQ0FBRCxFQUFHO0FBQUN3TyxhQUFTLEdBQUN4TyxDQUFWO0FBQVk7O0FBQTFCLENBQTVDLEVBQXdFLENBQXhFO0FBQTJFLElBQUlvTixVQUFKO0FBQWV0TixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDcU4sWUFBVSxDQUFDcE4sQ0FBRCxFQUFHO0FBQUNvTixjQUFVLEdBQUNwTixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUkyQyxRQUFKO0FBQWE3QyxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWixFQUFzQztBQUFDNEMsVUFBUSxDQUFDM0MsQ0FBRCxFQUFHO0FBQUMyQyxZQUFRLEdBQUMzQyxDQUFUO0FBQVc7O0FBQXhCLENBQXRDLEVBQWdFLENBQWhFO0FBUzNaLElBQUk0UCxTQUFTLEdBQUczTyxJQUFJLENBQUNDLEtBQUwsQ0FBV0MsTUFBTSxDQUFDQyxPQUFQLENBQWUsZ0JBQWYsQ0FBWCxDQUFoQjtBQUVBdkIsTUFBTSxDQUFDMkgsT0FBUCxDQUFlO0FBQ2IsK0JBQTZCTCxTQUE3QixFQUF3QzFCLElBQXhDLEVBQThDO0FBQzVDMEgsWUFBUSxDQUFDaEcsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsQ0FBUjtBQUNBeUUsYUFBUyxDQUFDckgsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsRUFBeUIsR0FBekIsQ0FBVDtBQUNELEdBSlk7O0FBS2IsK0JBQ0V1RCxlQURGLEVBRUVuRyxTQUZGLEVBR0UxQixJQUhGLEVBSUVpSixnQkFKRixFQUtFO0FBQ0F6RixXQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaO0FBQ0FELFdBQU8sQ0FBQ0MsR0FBUixDQUFZb0UsZUFBWjs7QUFDQSxRQUFJb0IsZ0JBQWdCLEtBQUsxRSxTQUF6QixFQUFvQztBQUNsQ3dFLGVBQVMsQ0FBQ3JILFNBQUQsRUFBWTFCLElBQUksQ0FBQ3NFLE1BQWpCLEVBQXlCMkUsZ0JBQXpCLENBQVQ7QUFDRCxLQUxELENBT0E7OztBQUNBLFFBQUlULE9BQU8sR0FBRyxJQUFkO0FBQ0FYLG1CQUFlLENBQUN1QyxHQUFoQixDQUFvQkMsUUFBUSxJQUFJO0FBQzlCQSxjQUFRLENBQUNDLFFBQVQsQ0FBa0JGLEdBQWxCLENBQXNCLENBQUNHLEtBQUQsRUFBUUMsS0FBUixLQUFrQjtBQUN0QyxZQUFJeEssSUFBSSxDQUFDeUssZUFBVCxFQUEwQjtBQUN4QixjQUFJSixRQUFRLENBQUNLLFNBQVQsSUFBc0JILEtBQUssQ0FBQ0YsUUFBaEMsRUFBMEM7QUFDeEM3QixtQkFBTyxHQUFHLEtBQVY7QUFDRDtBQUNGLFNBSkQsTUFJTztBQUNMLGNBQUkrQixLQUFLLENBQUNGLFFBQU4sSUFBa0JySyxJQUFJLENBQUMySyxRQUFMLENBQWNILEtBQWQsQ0FBdEIsRUFBNEM7QUFDMUNoQyxtQkFBTyxHQUFHLEtBQVY7QUFDRDtBQUNGO0FBQ0YsT0FWRDtBQVdELEtBWkQ7O0FBY0EsUUFBSUEsT0FBSixFQUFhO0FBQ1hPLGVBQVMsQ0FBQ3JILFNBQUQsRUFBWTFCLElBQUksQ0FBQ3NFLE1BQWpCLENBQVQ7QUFDRDs7QUFDRCxXQUFPa0UsT0FBUDtBQUNELEdBckNZOztBQXNDYixnQ0FDRVgsZUFERixFQUVFbkcsU0FGRixFQUdFMUIsSUFIRixFQUlFaUosZ0JBSkYsRUFLRTtBQUNBLFFBQUlBLGdCQUFnQixLQUFLMUUsU0FBekIsRUFBb0M7QUFDbEN3RSxlQUFTLENBQUNySCxTQUFELEVBQVkxQixJQUFJLENBQUNzRSxNQUFqQixFQUF5QjJFLGdCQUF6QixDQUFUO0FBQ0Q7O0FBQ0QsUUFBSTJCLGNBQWMsR0FBRyxFQUFyQjtBQUNBLFFBQUlDLFVBQVUsR0FBRyxJQUFqQjs7QUFDQSxTQUFLLElBQUloUCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHZ00sZUFBZSxDQUFDbkwsTUFBcEMsRUFBNENiLENBQUMsRUFBN0MsRUFBaUQ7QUFDL0MsVUFDRWdNLGVBQWUsQ0FBQ2hNLENBQUQsQ0FBZixDQUFtQnNNLFFBQW5CLEdBQThCMkMsV0FBOUIsT0FDQVgsU0FBUyxDQUFDbkssSUFBSSxDQUFDc0UsTUFBTixDQUFULENBQXVCekksQ0FBdkIsRUFBMEJzTSxRQUExQixHQUFxQzJDLFdBQXJDLEVBRkYsRUFHRTtBQUNBRixzQkFBYyxDQUFDNU8sSUFBZixDQUFvQixJQUFwQjtBQUNELE9BTEQsTUFLTztBQUNMNE8sc0JBQWMsQ0FBQzVPLElBQWYsQ0FBb0IsS0FBcEI7QUFDQTZPLGtCQUFVLEdBQUcsS0FBYjtBQUNEO0FBQ0Y7O0FBQ0QsUUFBSUEsVUFBSixFQUFnQjtBQUNkOUIsZUFBUyxDQUFDckgsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsQ0FBVDtBQUNEOztBQUNELFdBQU9zRyxjQUFQO0FBQ0QsR0FoRVk7O0FBaUViLDhCQUE0Qi9DLGVBQTVCLEVBQTZDbkcsU0FBN0MsRUFBd0QxQixJQUF4RCxFQUE4RDtBQUM1RCxRQUFJd0ksT0FBTyxHQUNULENBQUMyQixTQUFTLENBQUNuSyxJQUFJLENBQUNzRSxNQUFOLENBQVYsSUFDQXVELGVBQWUsQ0FBQ25MLE1BQWhCLElBQTBCeU4sU0FBUyxDQUFDbkssSUFBSSxDQUFDc0UsTUFBTixDQUFULENBQXVCNUgsTUFGbkQ7O0FBR0EsUUFBSThMLE9BQUosRUFBYTtBQUNYTyxlQUFTLENBQUNySCxTQUFELEVBQVkxQixJQUFJLENBQUNzRSxNQUFqQixDQUFUO0FBQ0Q7O0FBQ0QsV0FBT2tFLE9BQVA7QUFDRCxHQXpFWTs7QUEwRWIsaUNBQStCWCxlQUEvQixFQUFnRG5HLFNBQWhELEVBQTJEMUIsSUFBM0QsRUFBaUU7QUFDL0QsUUFBSXdJLE9BQU8sR0FBR1gsZUFBZSxDQUFDbkwsTUFBaEIsSUFBMEJzRCxJQUFJLENBQUNsQyxPQUFMLENBQWEsQ0FBYixFQUFnQmlOLFFBQWhCLENBQXlCck8sTUFBekIsR0FBa0MsQ0FBMUU7O0FBQ0EsUUFBSThMLE9BQUosRUFBYTtBQUNYTyxlQUFTLENBQUNySCxTQUFELEVBQVkxQixJQUFJLENBQUNzRSxNQUFqQixDQUFUO0FBQ0Q7O0FBQ0QsV0FBT2tFLE9BQVA7QUFDRCxHQWhGWTs7QUFpRmIsZ0NBQ0VYLGVBREYsRUFFRW5HLFNBRkYsRUFHRTFCLElBSEYsRUFJRWdMLGFBSkYsRUFLRS9CLGdCQUxGLEVBTUU7QUFDQSxRQUFJQSxnQkFBZ0IsS0FBSzFFLFNBQXpCLEVBQW9DO0FBQ2xDd0UsZUFBUyxDQUFDckgsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsRUFBeUIyRSxnQkFBekIsQ0FBVDtBQUNBLGFBQU8sSUFBUDtBQUNEOztBQUNELFFBQUlvQixRQUFRLEdBQUdGLFNBQVMsQ0FBQ25LLElBQUksQ0FBQ3NFLE1BQU4sQ0FBeEI7QUFDQSxRQUFJLENBQUMrRixRQUFMLEVBQWUsT0FBTyxJQUFQO0FBRWYsVUFBTVksZUFBZSxHQUFHWixRQUFRLENBQUN6TSxJQUFULENBQWNzTixPQUFPLElBQUk7QUFDL0MsVUFBSWxMLElBQUksQ0FBQ2xDLE9BQVQsRUFBa0I7QUFDaEIsZUFDRW9OLE9BQU8sQ0FBQ25JLEVBQVIsQ0FBV29GLFFBQVgsT0FDQW5JLElBQUksQ0FBQ2xDLE9BQUwsQ0FBYWtOLGFBQWIsRUFBNEI1QyxVQUE1QixDQUF1Q0QsUUFBdkMsRUFGRjtBQUlELE9BTEQsTUFLTztBQUNMLGVBQU8rQyxPQUFPLENBQUNuSSxFQUFSLENBQVdvRixRQUFYLE9BQTBCbkksSUFBSSxDQUFDb0ksVUFBTCxDQUFnQkQsUUFBaEIsRUFBakM7QUFDRDtBQUNGLEtBVHVCLENBQXhCLENBUkEsQ0FtQkE7O0FBQ0EsUUFBSThDLGVBQWUsQ0FBQ3pDLE9BQWhCLENBQXdCLENBQXhCLE1BQStCLE1BQW5DLEVBQTJDO0FBQ3pDLGFBQU95QyxlQUFlLENBQUN6QyxPQUFoQixDQUF3QjJDLE1BQXhCLENBQStCdEQsZUFBL0IsQ0FBUDtBQUNEOztBQUVELFFBQUllLE1BQU0sR0FBR2pCLFVBQVUsQ0FDckIzSCxJQUFJLENBQUNsQyxPQUFMLEdBQWVrQyxJQUFJLENBQUNsQyxPQUFMLENBQWFrTixhQUFiLENBQWYsR0FBNkNoTCxJQUR4QixFQUVyQjZILGVBRnFCLEVBR3JCb0QsZUFIcUIsQ0FBdkI7O0FBTUEsUUFBSWpMLElBQUksQ0FBQ29MLE9BQVQsRUFBa0I7QUFDaEIsYUFBT0MsTUFBTSxDQUFDQyxNQUFQLENBQWMxQyxNQUFkLEVBQXNCO0FBQUUyQyxZQUFJLEVBQUU7QUFBUixPQUF0QixDQUFQO0FBQ0Q7O0FBRUQsUUFBSTNDLE1BQU0sQ0FBQ1gsVUFBUCxLQUFzQixDQUExQixFQUE2QjtBQUMzQmMsZUFBUyxDQUFDckgsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsQ0FBVDtBQUNEOztBQUVELFdBQU9zRSxNQUFQO0FBQ0QsR0E5SFk7O0FBK0hiLGlDQUErQjRDLFVBQS9CLEVBQTJDOUosU0FBM0MsRUFBc0QxQixJQUF0RCxFQUE0RDtBQUMxRDtBQUNBK0ksYUFBUyxDQUFDckgsU0FBRCxFQUFZMUIsSUFBSSxDQUFDc0UsTUFBakIsQ0FBVCxDQUYwRCxDQUcxRDs7QUFDQSxRQUFJbUgsa0JBQWtCLEdBQUd2TyxRQUFRLENBQUN1QyxPQUFULENBQWlCO0FBQUVoQixTQUFHLEVBQUVpRDtBQUFQLEtBQWpCLENBQXpCO0FBQ0EsUUFBSWdLLGlCQUFpQixHQUFHRCxrQkFBa0IsQ0FBQ2xMLFdBQW5CLENBQStCM0MsSUFBL0IsQ0FDdEJ5RyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsTUFBTCxLQUFnQnRFLElBQUksQ0FBQ3NFLE1BRFAsQ0FBeEIsQ0FMMEQsQ0FRMUQ7O0FBQ0FvSCxxQkFBaUIsQ0FBQ0YsVUFBbEIsR0FBK0JBLFVBQS9CO0FBQ0FFLHFCQUFpQixDQUFDNU4sT0FBbEIsR0FBNEIwTixVQUFVLENBQUMxTixPQUF2QyxDQVYwRCxDQVcxRDs7QUFDQSxVQUFNNk4sU0FBUyxHQUFHO0FBQ2hCQyxjQUFRLEVBQUU1TCxJQUFJLENBQUNzRSxNQURDO0FBRWhCdUgsV0FBSyxFQUFFN0wsSUFBSSxDQUFDNkwsS0FGSTtBQUdoQjVMLGFBQU8sRUFBRUQsSUFBSSxDQUFDQyxPQUhFO0FBSWhCMkgsY0FBUSxFQUFFNUgsSUFBSSxDQUFDNEgsUUFKQztBQUtoQkcsYUFBTyxFQUFFL0gsSUFBSSxDQUFDK0ssUUFMRTtBQU1oQlYsY0FBUSxFQUFFbUIsVUFBVSxDQUFDTSxjQU5MO0FBT2hCQyxhQUFPLEVBQUVQLFVBQVUsQ0FBQzFOO0FBUEosS0FBbEI7QUFTQVosWUFBUSxDQUFDc0IsTUFBVCxDQUFnQjtBQUFFQyxTQUFHLEVBQUVpRDtBQUFQLEtBQWhCLEVBQW9DO0FBQUVuRCxVQUFJLEVBQUU7QUFBRWtDLHFCQUFhLEVBQUVrTDtBQUFqQjtBQUFSLEtBQXBDO0FBQ0EsV0FBTyxJQUFQO0FBQ0QsR0F0Slk7O0FBdUpiLCtCQUE2QjlELGVBQTdCLEVBQThDN0gsSUFBOUMsRUFBb0RnTCxhQUFwRCxFQUFtRTtBQUNqRSxRQUFJWCxRQUFRLEdBQUdGLFNBQVMsQ0FBQ25LLElBQUksQ0FBQ3NFLE1BQU4sQ0FBeEI7QUFDQSxRQUFJLENBQUMrRixRQUFMLEVBQWUsT0FBTyxJQUFQO0FBRWYsVUFBTVksZUFBZSxHQUFHWixRQUFRLENBQUN6TSxJQUFULENBQWNzTixPQUFPLElBQUk7QUFDL0MsVUFBSWxMLElBQUksQ0FBQ2xDLE9BQVQsRUFBa0I7QUFDaEIsZUFDRW9OLE9BQU8sQ0FBQ25JLEVBQVIsQ0FBV29GLFFBQVgsT0FDQW5JLElBQUksQ0FBQ2xDLE9BQUwsQ0FBYWtOLGFBQWIsRUFBNEI1QyxVQUE1QixDQUF1Q0QsUUFBdkMsRUFGRjtBQUlELE9BTEQsTUFLTztBQUNMLGVBQU8rQyxPQUFPLENBQUNuSSxFQUFSLENBQVdvRixRQUFYLE9BQTBCbkksSUFBSSxDQUFDb0ksVUFBTCxDQUFnQkQsUUFBaEIsRUFBakM7QUFDRDtBQUNGLEtBVHVCLENBQXhCLENBSmlFLENBZWpFOztBQUNBLFFBQUk4QyxlQUFlLENBQUN6QyxPQUFoQixDQUF3QixDQUF4QixNQUErQixNQUFuQyxFQUEyQztBQUN6QyxhQUFPeUMsZUFBZSxDQUFDekMsT0FBaEIsQ0FBd0IyQyxNQUF4QixDQUErQnRELGVBQS9CLENBQVA7QUFDRDs7QUFFRCxRQUFJZSxNQUFNLEdBQUdqQixVQUFVLENBQ3JCM0gsSUFBSSxDQUFDbEMsT0FBTCxHQUFla0MsSUFBSSxDQUFDbEMsT0FBTCxDQUFha04sYUFBYixDQUFmLEdBQTZDaEwsSUFEeEIsRUFFckI2SCxlQUZxQixFQUdyQm9ELGVBSHFCLENBQXZCOztBQU1BLFFBQUlqTCxJQUFJLENBQUNvTCxPQUFULEVBQWtCO0FBQ2hCLGFBQU9DLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjMUMsTUFBZCxFQUFzQjtBQUFFMkMsWUFBSSxFQUFFO0FBQVIsT0FBdEIsQ0FBUDtBQUNEOztBQUVELFdBQU8zQyxNQUFQO0FBQ0Q7O0FBdExZLENBQWYsRTs7Ozs7Ozs7Ozs7QUNYQSxJQUFJeE8sTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUMsUUFBSjtBQUFhdkMsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQ3NDLFVBQVEsQ0FBQ3JDLENBQUQsRUFBRztBQUFDcUMsWUFBUSxHQUFDckMsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJb0MsYUFBSjtBQUFrQnRDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRDQUFaLEVBQXlEO0FBQUNxQyxlQUFhLENBQUNwQyxDQUFELEVBQUc7QUFBQ29DLGlCQUFhLEdBQUNwQyxDQUFkO0FBQWdCOztBQUFsQyxDQUF6RCxFQUE2RixDQUE3RjtBQUFnR0YsTUFBTSxDQUFDQyxJQUFQLENBQVksb0JBQVo7QUFBa0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaO0FBQW9DRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWjtBQUF1Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVo7QUFBc0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaO0FBV2xaRixNQUFNLENBQUM0UixPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBclAsZUFBYTtBQUNkLENBSEQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbi8vIGltcG9ydCB7IENpdGllcyB9IGZyb20gXCIuLi8uLi9hcGkvY2l0aWVzXCI7XG4vLyBpbXBvcnQgeyBPZmZpY2VzIH0gZnJvbSBcIi4uLy4uL2FwaS9vZmZpY2VzXCI7XG4vLyBpbXBvcnQgeyBJdGVtcyB9IGZyb20gXCIuLi8uLi9hcGkvaXRlbXNcIjtcbi8vIGltcG9ydCB7IEJhZGdlcyB9IGZyb20gXCIuLi8uLi9hcGkvYmFkZ2VzXCI7XG4vLyBpbXBvcnQgeyBTdXJ2ZXlzIH0gZnJvbSBcIi4uLy4uL2FwaS9zdXJ2ZXlzXCI7XG5cbi8vIGZ1bmN0aW9uIGNyZWF0ZUNpdHkoY2l0eVNwZWNzKSB7XG4vLyAgIGNpdHlTcGVjc1tcInNtYWxsSW1hZ2VcIl0gPSBcIi9Zb3VyQ2l0eVNtYWxsL1wiICsgY2l0eVNwZWNzW1wiY2l0eVwiXSArIFwiLmpwZ1wiO1xuLy8gICBjaXR5U3BlY3NbXCJiYW5uZXJJbWFnZVwiXSA9IFwiL1lvdXJDaXR5UGFub3JhbWEvXCIgKyBjaXR5U3BlY3NbXCJjaXR5XCJdICsgXCIuanBnXCI7XG4vLyAgIHJldHVybiBjaXR5U3BlY3M7XG4vLyB9XG4vL1xuLy8gZnVuY3Rpb24gY3JlYXRlT2ZmaWNlKG9mZmljZVNwZWNzKSB7XG4vLyAgIG9mZmljZVNwZWNzW1wic21hbGxJbWFnZVwiXSA9XG4vLyAgICAgXCIvWW91ck9mZmljZVNtYWxsL1wiICsgb2ZmaWNlU3BlY3NbXCJvZmZpY2VcIl0gKyBcIl9TbWFsbC5qcGdcIjtcbi8vICAgb2ZmaWNlU3BlY3NbXCJiYW5uZXJJbWFnZVwiXSA9IFwiL1lvdXJPZmZpY2UvXCIgKyBvZmZpY2VTcGVjc1tcIm9mZmljZVwiXSArIFwiLmpwZ1wiO1xuLy8gICByZXR1cm4gb2ZmaWNlU3BlY3M7XG4vLyB9XG4vL1xuLy8gZnVuY3Rpb24gY3JlYXRlQmFkZ2UoYmFkZ2VTcGVjcykge1xuLy8gICBiYWRnZVNwZWNzW1widXJsXCJdID0gXCIvQmFkZ2VzL1wiICsgYmFkZ2VTcGVjc1tcIm5hbWVcIl0gKyBcIi5wbmdcIjtcbi8vICAgcmV0dXJuIGJhZGdlU3BlY3M7XG4vLyB9XG4vL1xuLy8gZXhwb3J0IGZ1bmN0aW9uIGFkZEdhbWVEYXRhKCkge1xuLy8gICB2YXIgR2FtZURhdGEgPSBKU09OLnBhcnNlKEFzc2V0cy5nZXRUZXh0KFwiZ2FtZURhdGEuanNvblwiKSk7XG4vLyAgIEdhbWVEYXRhW1wiY2l0aWVzXCJdLmZvckVhY2goY2l0eSA9PlxuLy8gICAgIE1ldGVvci5jYWxsKFwiY2l0aWVzLmluc2VydFwiLCBjcmVhdGVDaXR5KGNpdHkpKVxuLy8gICApO1xuLy8gICBHYW1lRGF0YVtcIm9mZmljZXNcIl0uZm9yRWFjaChvZmZpY2UgPT5cbi8vICAgICBNZXRlb3IuY2FsbChcIm9mZmljZXMuaW5zZXJ0XCIsIGNyZWF0ZU9mZmljZShvZmZpY2UpKVxuLy8gICApO1xuLy8gICBHYW1lRGF0YVtcIml0ZW1zXCJdLmZvckVhY2goaXRlbSA9PiBNZXRlb3IuY2FsbChcIml0ZW1zLmluc2VydFwiLCBpdGVtKSk7XG4vLyAgIEdhbWVEYXRhW1wiYmFkZ2VzXCJdLmZvckVhY2goYmFkZ2UgPT5cbi8vICAgICBNZXRlb3IuY2FsbChcImJhZGdlcy5pbnNlcnRcIiwgY3JlYXRlQmFkZ2UoYmFkZ2UpKVxuLy8gICApO1xuLy8gICBHYW1lRGF0YVtcInRyYWluaW5nXCJdLmZvckVhY2godHJhaW5pbmcgPT5cbi8vICAgICBNZXRlb3IuY2FsbChcInRyYWluaW5nLmluc2VydFwiLCB0cmFpbmluZylcbi8vICAgKTtcbi8vIH1cbi8vXG4vLyBleHBvcnQgZnVuY3Rpb24gYWRkU3VydmV5RGF0YSgpIHtcbi8vICAgdmFyIFN1cnZleXNEYXRhID0gSlNPTi5wYXJzZShBc3NldHMuZ2V0VGV4dChcInN1cnZleXMuanNvblwiKSk7XG4vLyAgIFN1cnZleXNEYXRhW1wic3VydmV5c1wiXS5mb3JFYWNoKHN1cnZleSA9PiB7XG4vLyAgICAgTWV0ZW9yLmNhbGwoXCJzdXJ2ZXlzLmluc2VydFwiLCBzdXJ2ZXkpO1xuLy8gICB9KTtcbi8vIH1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5cbmZ1bmN0aW9uIGNyZWF0ZURyYWdUYXNrKHRhc2tTcGVjcykge1xuICB0YXNrU3BlY3NbXCJpc1Rhc2tcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJ0YXNrSWRcIl0gPSB0YXNrU3BlY3NbXCJ0YXNrSWRcIl07XG4gIHRhc2tTcGVjc1tcInR5cGVcIl0gPSBcImRyYWdcIjtcbiAgdGFza1NwZWNzW1wicGFja2FnZVwiXSA9IHRhc2tTcGVjc1tcInBhY2thZ2VcIl07XG4gIHRhc2tTcGVjc1tcImF1dG9HcmFkaW5nXCJdID0gdHJ1ZTtcbiAgdGFza1NwZWNzW1wiZmlsZVByZWZpeFwiXSA9IHRhc2tTcGVjc1tcImZpbGVQcmVmaXhcIl07XG4gIHRhc2tTcGVjc1tcInRhc2tTdGF0ZVwiXSA9IHsgc2F2ZTogZmFsc2UsIGhlbHA6IGZhbHNlIH07XG5cbiAgcmV0dXJuIHRhc2tTcGVjcztcbn1cbmZ1bmN0aW9uIGNyZWF0ZVRhZ1Rhc2sodGFza1NwZWNzKSB7XG4gIHRhc2tTcGVjc1tcImlzVGFza1wiXSA9IHRydWU7XG4gIHRhc2tTcGVjc1tcInRhc2tJZFwiXSA9IHRhc2tTcGVjc1tcInRhc2tJZFwiXTtcbiAgdGFza1NwZWNzW1widHlwZVwiXSA9IFwidGFnXCI7XG4gIHRhc2tTcGVjc1tcImNvbnRlbnRcIl0gPSB0YXNrU3BlY3NbXCJjb250ZW50XCJdO1xuICB0YXNrU3BlY3NbXCJwYWNrYWdlXCJdID0gdGFza1NwZWNzW1wicGFja2FnZVwiXTtcbiAgdGFza1NwZWNzW1wiYXV0b0dyYWRpbmdcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJmaWxlUHJlZml4XCJdID0gdGFza1NwZWNzW1wiZmlsZVByZWZpeFwiXTtcbiAgdGFza1NwZWNzW1widGFza1N0YXRlXCJdID0geyBzYXZlOiBmYWxzZSwgaGVscDogZmFsc2UsIHJlYWRGaW5pc2hlZDogZmFsc2UgfTtcblxuICByZXR1cm4gdGFza1NwZWNzO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVDbG96ZVRhc2sodGFza1NwZWNzKSB7XG4gIHRhc2tTcGVjc1tcImlzVGFza1wiXSA9IHRydWU7XG4gIHRhc2tTcGVjc1tcInRhc2tJZFwiXSA9IHRhc2tTcGVjc1tcInRhc2tJZFwiXTtcbiAgdGFza1NwZWNzW1widHlwZVwiXSA9IFwiY2xvemVcIjtcbiAgdGFza1NwZWNzW1wiY29udGVudFwiXSA9IHRhc2tTcGVjc1tcImNvbnRlbnRcIl07XG4gIHRhc2tTcGVjc1tcInBhY2thZ2VcIl0gPSB0YXNrU3BlY3NbXCJwYWNrYWdlXCJdO1xuICB0YXNrU3BlY3NbXCJhdXRvR3JhZGluZ1wiXSA9IHRydWU7XG4gIHRhc2tTcGVjc1tcImZpbGVQcmVmaXhcIl0gPSB0YXNrU3BlY3NbXCJmaWxlUHJlZml4XCJdO1xuICB0YXNrU3BlY3NbXCJ0YXNrU3RhdGVcIl0gPSB7IHNhdmU6IGZhbHNlLCBoZWxwOiBmYWxzZSB9O1xuXG4gIHJldHVybiB0YXNrU3BlY3M7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZU1lbW9yeSh0YXNrU3BlY3MpIHtcbiAgdGFza1NwZWNzW1wiaXNUYXNrXCJdID0gdHJ1ZTtcbiAgdGFza1NwZWNzW1widGFza0lkXCJdID0gdGFza1NwZWNzW1widGFza0lkXCJdO1xuICB0YXNrU3BlY3NbXCJ0eXBlXCJdID0gXCJtZW1vcnlcIjtcbiAgdGFza1NwZWNzW1wiY29udGVudFwiXSA9IHRhc2tTcGVjc1tcImNvbnRlbnRcIl07XG4gIHRhc2tTcGVjc1tcInBhY2thZ2VcIl0gPSB0YXNrU3BlY3NbXCJwYWNrYWdlXCJdO1xuICB0YXNrU3BlY3NbXCJhdXRvR3JhZGluZ1wiXSA9IHRydWU7XG4gIHRhc2tTcGVjc1tcImZpbGVQcmVmaXhcIl0gPSB0YXNrU3BlY3NbXCJmaWxlUHJlZml4XCJdO1xuICB0YXNrU3BlY3NbXCJ0YXNrU3RhdGVcIl0gPSB7IHNhdmU6IGZhbHNlLCBoZWxwOiBmYWxzZSB9O1xuXG4gIHJldHVybiB0YXNrU3BlY3M7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZU11bHRpQ2hvaWNlKHRhc2tTcGVjcykge1xuICB0YXNrU3BlY3NbXCJpc1Rhc2tcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJ0YXNrSWRcIl0gPSB0YXNrU3BlY3NbXCJ0YXNrSWRcIl07XG4gIHRhc2tTcGVjc1tcInR5cGVcIl0gPSBcIm11bHRpQ2hvaWNlXCI7XG4gIHRhc2tTcGVjc1tcImNvbnRlbnRcIl0gPSB0YXNrU3BlY3NbXCJjb250ZW50XCJdO1xuICB0YXNrU3BlY3NbXCJwYWNrYWdlXCJdID0gdGFza1NwZWNzW1wicGFja2FnZVwiXTtcbiAgdGFza1NwZWNzW1wiYXV0b0dyYWRpbmdcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJmaWxlUHJlZml4XCJdID0gdGFza1NwZWNzW1wiZmlsZVByZWZpeFwiXTtcbiAgdGFza1NwZWNzW1widGFza1N0YXRlXCJdID0geyBzYXZlOiBmYWxzZSwgaGVscDogZmFsc2UgfTtcblxuICByZXR1cm4gdGFza1NwZWNzO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVTdXJ2ZXlUYXNrKHRhc2tTcGVjcykge1xuICB0YXNrU3BlY3NbXCJpc1Rhc2tcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJ0YXNrSWRcIl0gPSB0YXNrU3BlY3NbXCJ0YXNrSWRcIl07XG4gIHRhc2tTcGVjc1tcInR5cGVcIl0gPSBcInN1cnZleVwiO1xuICB0YXNrU3BlY3NbXCJwYWNrYWdlXCJdID0gdGFza1NwZWNzW1wicGFja2FnZVwiXTtcbiAgdGFza1NwZWNzW1wiYXV0b0dyYWRpbmdcIl0gPSB0cnVlO1xuICB0YXNrU3BlY3NbXCJmaWxlUHJlZml4XCJdID0gdGFza1NwZWNzW1wiZmlsZVByZWZpeFwiXTtcbiAgdGFza1NwZWNzW1widGFza1N0YXRlXCJdID0geyBzYXZlOiB0cnVlLCBoZWxwOiBmYWxzZSB9O1xuXG4gIHJldHVybiB0YXNrU3BlY3M7XG59XG5cbmZ1bmN0aW9uIGFkZFRhc2tzKHBhY2thZ2VOYW1lLCBwYXRoKSB7XG4gIGxldCB0YXNrcyA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQocGF0aCkpW1widGFza3NcIl07XG4gIGxldCB0cmFpbmluZ3MgPSBbXTtcblxuICBmb3IgKGxldCBpIGluIHRhc2tzKSB7XG4gICAgdGFza3NbaV1bXCJzZXF1ZW5jZUlkXCJdID0gcGFyc2VJbnQoaSk7XG4gICAgaWYgKHRhc2tzW2ldLmlzVHJhaW5pbmcpIHtcbiAgICAgIHRyYWluaW5ncy5wdXNoKHRhc2tzW2ldKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IG5ld3Rhc2sgPSB7fTtcbiAgICAgIHN3aXRjaCAodGFza3NbaV0uZmlsZVByZWZpeCkge1xuICAgICAgICBjYXNlIFwiRHJhZ1wiOlxuICAgICAgICAgIG5ld3Rhc2sgPSBjcmVhdGVEcmFnVGFzayh0YXNrc1tpXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJUYWdcIjpcbiAgICAgICAgICBuZXd0YXNrID0gY3JlYXRlVGFnVGFzayh0YXNrc1tpXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJNdWx0aVwiOlxuICAgICAgICAgIG5ld3Rhc2sgPSBjcmVhdGVNdWx0aUNob2ljZSh0YXNrc1tpXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJNZW1vcnlcIjpcbiAgICAgICAgICBuZXd0YXNrID0gY3JlYXRlTWVtb3J5KHRhc2tzW2ldKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIkNsb3plXCI6XG4gICAgICAgICAgbmV3dGFzayA9IGNyZWF0ZUNsb3plVGFzayh0YXNrc1tpXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJTdXJ2ZXlcIjpcbiAgICAgICAgICBuZXd0YXNrID0gY3JlYXRlU3VydmV5VGFzayh0YXNrc1tpXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBNZXRlb3IuY2FsbChcInRhc2tzLmluc2VydFwiLCBuZXd0YXNrKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRyYWluaW5ncztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZFBhY2thZ2VUYXNrcygpIHtcbiAgbGV0IHRyYWluaW5ncyA9IHt9O1xuICB0cmFpbmluZ3NbXCJNb3RpdmF0aW9uXCJdID0gYWRkVGFza3MoXCJNb3RpdmF0aW9uXCIsIFwidGFza3MvbW90aXZhdGlvbi5qc29uXCIpO1xuICB0cmFpbmluZ3NbXCJJZGVudGl0w6R0XCJdID0gYWRkVGFza3MoXCJJZGVudGl0w6R0XCIsIFwidGFza3MvaWRlbnRpdHkuanNvblwiKTtcblxuICBNZXRlb3IuY2FsbChcInRyYWluaW5nLmluc2VydFwiLCB0cmFpbmluZ3MpO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IFRhc2tzIH0gZnJvbSBcIi4uLy4uL2FwaS90YXNrc1wiO1xuaW1wb3J0IHsgVHJhaW5pbmcgfSBmcm9tIFwiLi4vLi4vYXBpL3RyYWluaW5nXCI7XG5pbXBvcnQgeyBQYWNrYWdlcyB9IGZyb20gXCIuLi8uLi9hcGkvcGFja2FnZVwiO1xuZnVuY3Rpb24gY3JlYXRlRHJhZ1Rhc2sodHJhaW5pbmdTcGVjcykge1xuICB0cmFpbmluZ1NwZWNzW1wibmFtZVwiXSA9IHRyYWluaW5nU3BlY3NbXCJuYW1lXCJdO1xuICB0cmFpbmluZ1NwZWNzW1wicGFja2FnZVwiXSA9IHRyYWluaW5nU3BlY3NbXCJwYWNrYWdlXCJdO1xuICB0cmFpbmluZ1NwZWNzW1wiaW1hZ2VWaWRlb1wiXSA9IFwibGlua1wiO1xuICB0cmFpbmluZ1NwZWNzW1wiZGlzY291bnRcIl0gPSBmYWxzZTtcbiAgdHJhaW5pbmdTcGVjc1tcImZvcm1hdFwiXSA9IFwicGRmXCI7XG5cbiAgLy8gdGFza1NwZWNzW1widGFza3VybFwiXSA9XG4gIC8vICAgXCIvVGFza3MvTWF6ZS9UYXNrUGljdHVyZXMvXCIgKyB0YXNrU3BlY3NbXCJ0YXNrSWRcIl0gKyBcIi5qcGVnXCI7XG4gIHJldHVybiB0cmFpbmluZ1NwZWNzO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkUGFja2FnZXMoKSB7XG4gIHZhciBwYWNrYWdlcyA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQoXCJwYWNrYWdlcy9wYWNrYWdlLmpzb25cIikpW1xuICAgIFwicGFja2FnZXNcIlxuICBdO1xuXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgcGFja2FnZXMubGVuZ3RoOyBpKyspIHtcbiAgICBNZXRlb3IuY2FsbChcInBhY2thZ2UuaW5zZXJ0XCIsIGNyZWF0ZURyYWdUYXNrKHBhY2thZ2VzW2ldKSk7XG4gIH1cbn1cbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xuaW1wb3J0IHsgUm9sZXMgfSBmcm9tIFwibWV0ZW9yL2FsYW5uaW5nOnJvbGVzXCI7XG5pbXBvcnQgc2hvcnRpZCBmcm9tIFwic2hvcnRpZFwiO1xuaW1wb3J0IHsgVGVhY2hlcnMgfSBmcm9tIFwiLi4vLi4vYXBpL3RlYWNoZXJzXCI7XG5pbXBvcnQgeyBUcmFpbmluZyB9IGZyb20gXCIuLi8uLi9hcGkvdHJhaW5pbmdcIjtcblxuaW1wb3J0IHsgQ291cnNlcyB9IGZyb20gXCIuLi8uLi9hcGkvY291cnNlc1wiO1xuaW1wb3J0IHsgU3R1ZGVudHMgfSBmcm9tIFwiLi4vLi4vYXBpL3N0dWRlbnRzXCI7XG5pbXBvcnQgeyBUYXNrcyB9IGZyb20gXCIuLi8uLi9hcGkvdGFza3NcIjtcbmltcG9ydCB7IFBhY2thZ2UgfSBmcm9tIFwiLi4vLi4vYXBpL3BhY2thZ2VcIjtcbmltcG9ydCB7IGFkZFBhY2thZ2VzIH0gZnJvbSBcIi4vYWRkUGFja2FnZXNcIjtcbmltcG9ydCB7IGFkZFBhY2thZ2VUYXNrcyB9IGZyb20gXCIuL2FkZFBhY2thZ2VUYXNrc1wiO1xuaW1wb3J0IHsgYWRkR2FtZURhdGEgfSBmcm9tIFwiLi9hZGRHYW1lRGF0YVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gcmVzZXREYXRhYmFzZSgpIHtcbiAgY2xlYXJEYXRhYmFzZSgpO1xuICAvLyByZW1vdmUgd2hlbiBsb2FkaW5nIGN1c3RvbSBkYXRhYmFzZSBzdGF0ZVxuICBzZXR1cEFkbWluKCk7XG4gIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgIHNldHVwVGVzdENvdXJzZSh0cnVlKTtcbiAgfVxuICBhZGRQYWNrYWdlVGFza3MoKTtcbiAgYWRkUGFja2FnZXMoKTtcbiAgaW5pdFBhY2thZ2VzKCk7XG4gIHNldHVwU3R1ZGVudHMoKTtcbiAgc2V0dXBUZWFjaGVyKCk7XG4gIC8vIHJlbW92ZSB3aGVuIGxvYWRpbmcgY3VzdG9tIGRhdGFiYXNlIHN0YXRlXG59XG4vL1RPRE8gU09VUkNFIFRISVMgT1VUXG5mdW5jdGlvbiBpbml0UGFja2FnZXMoKSB7XG4gIHZhciBwYWNrYWdlcyA9IFBhY2thZ2UuZmluZCh7fSkuZmV0Y2goKTtcbiAgZm9yICh2YXIgaSBpbiBwYWNrYWdlcykge1xuICAgIHZhciBjb250ZW50ID0gcGFja2FnZXNbaV0uY29udGVudDtcbiAgICB2YXIgdG1wMSA9IFtdO1xuICAgIHZhciB0bXAyID0gW107XG4gICAgdmFyIHBuYW1lID0gcGFja2FnZXNbaV0ubmFtZTtcbiAgICAvL3ZhciB0YXNrcyA9IFRhc2tzLmZpbmQoeyBwYWNrYWdlOiBwbmFtZSB9KS5mZXRjaCgpO1xuICAgIHZhciB0cmFpbmluZ3MgPSBUcmFpbmluZy5maW5kKHt9KS5mZXRjaCgpO1xuXG4gICAgZm9yICh2YXIgaiBpbiBjb250ZW50KSB7XG4gICAgICB2YXIgdGFza3MgPSBUYXNrcy5maW5kKHtcbiAgICAgICAgcGFyZW50SWQ6IHBhY2thZ2VzW2ldLm5hbWUgKyBjb250ZW50W2pdLnNlcXVlbmNlSWRcbiAgICAgIH0pLmZldGNoKCk7XG4gICAgICBjb250ZW50W2pdLnRhc2tzID0gdGFza3M7XG4gICAgfVxuXG4gICAgdmFyIHBhY2thZ2VVcGRhdGVzID0ge1xuICAgICAgJHNldDogeyBjb250ZW50OiBjb250ZW50IH1cbiAgICB9O1xuXG4gICAgUGFja2FnZS51cGRhdGUoeyBfaWQ6IHBhY2thZ2VzW2ldLl9pZCB9LCBwYWNrYWdlVXBkYXRlcyk7XG5cbiAgICBmb3IgKHZhciBrIGluIHRyYWluaW5nc1swXVtwbmFtZV0pIHtcbiAgICAgIHRtcDIucHVzaChcbiAgICAgICAgdHJhaW5pbmdzWzBdW3BuYW1lXVtrXS50cmFpbmluZ0lkICsgdHJhaW5pbmdzWzBdW3BuYW1lXVtrXS5zZXF1ZW5jZUlkXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vVE9ETyBQVVQgVEhJUyBJTiAxIFFVRVJZXG4gICAgUGFja2FnZS51cGRhdGUoeyBfaWQ6IHBhY2thZ2VzW2ldLl9pZCB9LCBwYWNrYWdlVXBkYXRlcyk7XG5cbiAgICBwYWNrYWdlVXBkYXRlcyA9IHtcbiAgICAgICRzZXQ6IHsgdHJhaW5pbmdzOiB0bXAyIH1cbiAgICB9O1xuICAgIFBhY2thZ2UudXBkYXRlKHsgX2lkOiBwYWNrYWdlc1tpXS5faWQgfSwgcGFja2FnZVVwZGF0ZXMpO1xuICAgIC8vVE9ETyBFTkRcbiAgfVxufVxuZnVuY3Rpb24gc2V0dXBUZXN0Q291cnNlKHNraXBTZXR1cCkge1xuICBjb25zdCBlbWFpbCA9IFwiZG96ZW50QHl1b3NoaS5kZVwiO1xuICBjb25zdCBwYXNzd29yZCA9IFwiMTIzXCI7XG4gIGNvbnN0IHRlYWNoZXJJZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIoeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyh0ZWFjaGVySWQsIFwidGVhY2hlclwiKTtcbiAgVGVhY2hlcnMuaW5zZXJ0KHtcbiAgICB1c2VySWQ6IHRlYWNoZXJJZCxcbiAgICBjb3Vyc2VzOiBbXVxuICB9KTtcbiAgY29uc3QgY291cnNlSWQgPSBzaG9ydGlkLmdlbmVyYXRlKCk7XG5cbiAgQ291cnNlcy5pbnNlcnQoe1xuICAgIF9pZDogY291cnNlSWQsXG4gICAgY291cnNlTmFtZTogXCJEZW1vLUt1cnNcIixcbiAgICBwdXBpbHM6IFtdLFxuICAgIHRhc2tzOiBbXSxcbiAgICB0ZWFjaGVySWQ6IFRlYWNoZXJzLmZpbmRPbmUoKS5faWRcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHNldHVwQWRtaW4oKSB7XG4gIGNvbnN0IHBwRW1haWwgPSBcImFkbWluQHl1b3NoaS5kZVwiO1xuICBjb25zdCBwYXNzd29yZCA9IFwiMTIzXCI7XG4gIHJlcyA9IEFjY291bnRzLmNyZWF0ZVVzZXIoeyB1c2VybmFtZTogXCJwcEFkbWluXCIsIGVtYWlsOiBwcEVtYWlsLCBwYXNzd29yZCB9KTtcbiAgY29uc3QgcHBJZCA9IEFjY291bnRzLmZpbmRVc2VyQnlFbWFpbChwcEVtYWlsKS5faWQ7XG4gIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyhwcElkLCBcInlhZG1pblwiKTtcbn1cbmZ1bmN0aW9uIHNldHVwVGVhY2hlcigpIHtcbiAgbGV0IHVzZXJuYW1lID0gXCJ0ZWFjaGVyXCI7XG4gIGxldCBlbWFpbCA9IHVzZXJuYW1lO1xuICBsZXQgdXNlcklkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7IHVzZXJuYW1lLCBlbWFpbCwgcGFzc3dvcmQ6IHVzZXJuYW1lIH0pO1xuICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCBcInRlYWNoZXJcIik7XG4gIFRlYWNoZXJzLmluc2VydCh7XG4gICAgdXNlcklkOiB1c2VySWQsXG4gICAgc3R1ZGlwVXNlcklkOiBcIlwiLFxuICAgIGNvdXJzZXM6IFtdXG4gIH0pO1xufVxuZnVuY3Rpb24gc2V0dXBTdHVkZW50cygpIHtcbiAgY29uc3QgY291cnNlcyA9IENvdXJzZXMuZmluZCh7fSkuZmV0Y2goKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA5OyBpKyspIHtcbiAgICBsZXQgdXNlcm5hbWUgPSBcInVzZXJcIiArIGk7XG4gICAgbGV0IGVtYWlsID0gdXNlcm5hbWU7XG4gICAgbGV0IHVzZXJJZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIoeyB1c2VybmFtZSwgZW1haWwsIHBhc3N3b3JkOiB1c2VybmFtZSB9KTtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcklkLCBcInN0dWRlbnRcIik7XG5cbiAgICAvL1RFU1RDQVNFIFdPUktTUEFDRSBUYXNrc1xuXG4gICAgaWYgKGkgPT0gMikge1xuICAgICAgdmFyIHRhc2sgPSBUYXNrcy5maW5kT25lKHsgcGFja2FnZTogXCJNb3RpdmF0aW9uXCIsIHNlcXVlbmNlSWQ6IDEgfSk7XG4gICAgICBTdHVkZW50cy5pbnNlcnQoe1xuICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgY3JlZGl0czogMCxcbiAgICAgICAgZXhwOiAwLFxuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgZWFybmluZzogWzFdLFxuICAgICAgICBzdHVkaXBVc2VySWQ6IFwiZTdhMGE4NGIxNjFmM2U4YzA5YjRhMGEyZThhNTgxNDdcIixcbiAgICAgICAgbGFzdEFjdGl2ZVRhc2tJZDogbnVsbCxcbiAgICAgICAgY291cnNlczogW10sXG4gICAgICAgIHRhc2tzOiBbdGFza10sXG4gICAgICAgIHNvbHZlZFRhc2tzOiBbXSxcbiAgICAgICAgbGVhcm5DYXJkczogW10sXG4gICAgICAgIHNvbHZlZFN1cnZleXM6IFtdLFxuICAgICAgICBjdXJyZW50U2VxdWVuY2VJZDogMCxcbiAgICAgICAgY3VycmVudFBhY2thZ2U6IFtdLFxuICAgICAgICBjdXJyZW50VHJhaW5pbmc6IFtdLFxuICAgICAgICBzb2x2ZWRUcmFpbmluZzogW11cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBTdHVkZW50cy5pbnNlcnQoe1xuICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgY3JlZGl0czogMCxcbiAgICAgICAgZXhwOiAwLFxuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgZWFybmluZzogWzFdLFxuICAgICAgICBzdHVkaXBVc2VySWQ6IFwiXCIsXG4gICAgICAgIGxhc3RBY3RpdmVUYXNrSWQ6IG51bGwsXG4gICAgICAgIGNvdXJzZXM6IFtdLFxuICAgICAgICB0YXNrczogW10sXG4gICAgICAgIHNvbHZlZFRhc2tzOiBbXSxcbiAgICAgICAgbGVhcm5DYXJkczogW10sXG5cbiAgICAgICAgY3VycmVudFNlcXVlbmNlSWQ6IDAsXG4gICAgICAgIGN1cnJlbnRQYWNrYWdlOiBbXSxcbiAgICAgICAgY3VycmVudFRyYWluaW5nOiBbXSxcbiAgICAgICAgc29sdmVkVHJhaW5pbmc6IFtdXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvL1RFU1RDQVNFIEVORFxuXG4gICAgLy8gRHVtbXktRW50cnkgZm9yIFN0dWRpcC1WYWxpZGF0ZWQgVXNlcjpcbiAgfVxuICAvLyBjb25zdCBkdW1teUlkID0gQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gIC8vICAgdXNlcm5hbWU6IFwidGVzdF9hdXRvclwiLFxuICAvLyAgIHBhc3N3b3JkOiBcInRlc3RpbmdcIlxuICAvLyB9KTtcbiAgLy8gU3R1ZGVudHMuaW5zZXJ0KHtcbiAgLy8gICBjb3Vyc2VJZDogY291cnNlc1swXS5faWQsXG4gIC8vICAgZHVtbXlJZCxcbiAgLy8gICB1c2VybmFtZTogYHRlc3RfYXV0b3JgXG4gIC8vIH0pO1xufVxuXG5mdW5jdGlvbiBjbGVhckRhdGFiYXNlKCkge1xuICBUZWFjaGVycy5yZW1vdmUoe30pO1xuICBTdHVkZW50cy5yZW1vdmUoe30pO1xuICBNZXRlb3IudXNlcnMucmVtb3ZlKHt9KTtcbiAgQ291cnNlcy5yZW1vdmUoe30pO1xuICBUYXNrcy5yZW1vdmUoe30pO1xuICBUcmFpbmluZy5yZW1vdmUoe30pO1xuICBQYWNrYWdlLnJlbW92ZSh7fSk7XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gXCJzaW1wbC1zY2hlbWFcIjtcbmltcG9ydCBzaG9ydGlkIGZyb20gXCJzaG9ydGlkXCI7XG5pbXBvcnQgeyBTdHVkZW50cyB9IGZyb20gXCIuL3N0dWRlbnRzXCI7XG5pbXBvcnQgeyBUZWFjaGVycyB9IGZyb20gXCIuL3RlYWNoZXJzXCI7XG5cbmV4cG9ydCBjb25zdCBDb3Vyc2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJjb3Vyc2VzXCIpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIC8vIGNvdXJzZU5hbWVzIG9mIG9uZSB0ZWFjaGVyIGFyZSB1bmlxdWVcbiAgQ291cnNlcy5yYXdDb2xsZWN0aW9uKCkuZW5zdXJlSW5kZXgoXG4gICAgeyB0ZWFjaGVySWQ6IDEsIGNvdXJzZU5hbWU6IDEgfSxcbiAgICB7IHVuaXF1ZTogdHJ1ZSB9XG4gICk7XG4gIC8vU3R1ZGVudHNcbiAgTWV0ZW9yLnB1Ymxpc2goXCJjb3Vyc2VzQnlTdHVkZW50XCIsICgpID0+IHtcbiAgICBpZiAoTWV0ZW9yLnVzZXJJZCgpICYmIFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcigpLCBbXCJzdHVkZW50XCJdKSkge1xuICAgICAgdmFyIHN0dWRlbnRJZCA9IFN0dWRlbnRzLmZpbmRPbmUoeyB1c2VySWQ6IE1ldGVvci51c2VySWQoKSB9KS5faWQ7XG4gICAgICBDb3Vyc2VzLmZpbmQoeyBzdHVkZW50SWQgfSk7XG4gICAgICByZXR1cm4gQ291cnNlcy5maW5kKHsgc3R1ZGVudElkIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICBNZXRlb3IucHVibGlzaChcImNvdXJzZXNCeUlkXCIsIGZ1bmN0aW9uKCkge1xuICAgIGlmIChNZXRlb3IudXNlcklkKCkpIHtcbiAgICAgIHJldHVybiBDb3Vyc2VzLmZpbmQoe30pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICAvLyB0ZWFjaGVyXG4gIE1ldGVvci5wdWJsaXNoKFwiY291cnNlc0J5VGVhY2hlclwiLCBjb3Vyc2VJZCA9PiB7XG4gICAgaWYgKE1ldGVvci51c2VySWQoKSAmJiBSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXIoKSwgW1widGVhY2hlclwiXSkpIHtcbiAgICAgIHZhciB0ZWFjaGVySWQgPSBUZWFjaGVycy5maW5kT25lKHsgdXNlcklkOiBNZXRlb3IudXNlcklkKCkgfSkuX2lkO1xuICAgICAgQ291cnNlcy5maW5kT25lKCk7XG4gICAgICByZXR1cm4gQ291cnNlcy5maW5kKHsgdGVhY2hlcklkIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICAvLyB0ZWFjaGVyXG4gIE1ldGVvci5wdWJsaXNoKFwiY2xhc3Nyb29tQnlOYW1lXCIsIGZ1bmN0aW9uKGNsYXNzTmFtZSkge1xuICAgIGlmIChNZXRlb3IudXNlcklkKCkgJiYgUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VyKCksIFtcInRlYWNoZXJcIl0pKSB7XG4gICAgICByZXR1cm4gQ291cnNlcy5maW5kKHsgdGVhY2hlcklkOiBNZXRlb3IudXNlcklkKCksIGNsYXNzTmFtZSB9KTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIkFjY2VzcyBkZW5pZWQhXCIpO1xuICB9KTtcbiAgLy8gYWRtaW5cbiAgTWV0ZW9yLnB1Ymxpc2goXCJjb3Vyc2VzXCIsIGZ1bmN0aW9uKCkge1xuICAgIGlmIChNZXRlb3IudXNlcklkKCkgJiYgUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VyKCksIFtcInlhZG1pblwiXSkpIHtcbiAgICAgIHJldHVybiBDb3Vyc2VzLmZpbmQoe30pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICAvLyBwdXBpbFxuICBNZXRlb3IucHVibGlzaChcImNvdXJzZXNPZlN0dWRlbnRcIiwgZnVuY3Rpb24oKSB7XG4gICAgY29uc3Qgc3R1ZGVudCA9IFN0dWRlbnRzLmZpbmRPbmUoeyB1c2VySWQ6IE1ldGVvci51c2VySWQoKSB9KTtcbiAgICBpZiAoc3R1ZGVudCkge1xuICAgICAgcmV0dXJuIENvdXJzZXMuZmluZCh7IF9pZDogc3R1ZGVudC5jbGFzc0lkIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gIC8vIHRlYWNoZXJcbiAgXCJjb3Vyc2VzLmluc2VydFwiOiBmdW5jdGlvbihjb3Vyc2VOYW1lLCBzdHVkaXBJZCwgdGVhY2hlcklkKSB7XG4gICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgaWYgKE1ldGVvci51c2VySWQoKSAmJiBSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXIoKSwgW1widGVhY2hlclwiXSkpIHtcbiAgICAgICAgaWYgKENvdXJzZXMuZmluZE9uZSh7IHRlYWNoZXJJZDogTWV0ZW9yLnVzZXJJZCgpLCBjb3Vyc2VOYW1lIH0pKVxuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJDbGFzcyBhbHJlYWR5IGV4aXN0cyFcIik7XG4gICAgICAgIGNvbnN0IGNvdXJzZUlkID0gc2hvcnRpZC5nZW5lcmF0ZSgpO1xuICAgICAgICBjb25zdCBzdHVkZW50cyA9IFtdO1xuICAgICAgICBDb3Vyc2VzLmluc2VydCh7XG4gICAgICAgICAgdGVhY2hlcklkOiB0ZWFjaGVySWQsXG4gICAgICAgICAgY291cnNlTmFtZSxcbiAgICAgICAgICBzdHVkaXBJZCxcbiAgICAgICAgICBzdHVkZW50cyxcbiAgICAgICAgICBzdGFydGVkOiBmYWxzZSxcbiAgICAgICAgICB0YXNrczogW10sXG4gICAgICAgICAgcGF0aHM6IFtdXG4gICAgICAgIH0pO1xuICAgICAgICBUZWFjaGVycy51cGRhdGUoeyAkYWRkVG9TZXQ6IHsgY291cnNlczogY291cnNlSWQgfSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJBY2Nlc3MgZGVuaWVkIVwiKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sXG4gIC8vIGFmdGVyIGJhc2ljLWF1dGggZ2V0IHRoZSB1c2VyLWNvdXJzZXMgd2hlcmUgdGhlIHRlYWNoZXIgaW5pdGlhbGl6ZWQgeXVvc2hpXG4gIFwiY291cnNlcy5nZXRUZWFjaGVyQ291cnNlc1wiOiBmdW5jdGlvbih0b2tlbiwgc3R1ZGlwVXNlcklkKSB7XG4gICAgLy9IVFRQIHJlcXVlc3RzIGdvZXMgc2VydmVyLXNpZGUgb25seVxuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHZhciBjb3Vyc2VSYXdEYXRhID0gSFRUUC5jYWxsKFxuICAgICAgICAgIFwiR0VUXCIsXG4gICAgICAgICAgXCJodHRwOi8vbG9jYWxob3N0L3N0dWRpcC9wbHVnaW5zLnBocC9hcmdvbmF1dHNwbHVnaW4vdXNlcnMvXCIgK1xuICAgICAgICAgICAgc3R1ZGlwVXNlcklkICtcbiAgICAgICAgICAgIFwiL2NvdXJzZXNcIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IFwiQmFzaWMgXCIgKyB0b2tlbiB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICB2YXIgY291cnNlRGF0YSA9IEpTT04ucGFyc2UoY291cnNlUmF3RGF0YS5jb250ZW50KTtcbiAgICAgICAgdmFyIG1lbWJlcnNoaXBzID0gW107XG4gICAgICAgIGZvciAodmFyIGkgaW4gY291cnNlRGF0YS5kYXRhKSB7XG4gICAgICAgICAgdmFyIHRtcENvdXJzZSA9IGNvdXJzZURhdGEuZGF0YVtpXTtcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB2YXIgbWVtYmVyc2hpcHNSYXcgPSBIVFRQLmNhbGwoXG4gICAgICAgICAgICAgIFwiR0VUXCIsXG4gICAgICAgICAgICAgIFwiaHR0cDovL2xvY2FsaG9zdC9zdHVkaXAvcGx1Z2lucy5waHAvYXJnb25hdXRzcGx1Z2luL2NvdXJzZXMvXCIgK1xuICAgICAgICAgICAgICAgIHRtcENvdXJzZS5pZCArXG4gICAgICAgICAgICAgICAgXCIvbWVtYmVyc2hpcHNcIixcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogXCJCYXNpYyBcIiArIHRva2VuIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHZhciBtZW1iZXJzaGlwRGF0YSA9IEpTT04ucGFyc2UobWVtYmVyc2hpcHNSYXcuY29udGVudCk7XG5cbiAgICAgICAgICAgIC8vU2VhcmNoIGZvciBjb3Vyc2VzIHdoZXJlIGN1cnJlbnQgdXNlciBpcyBcImRvemVudFwiXG4gICAgICAgICAgICBmb3IgKHZhciBrIGluIG1lbWJlcnNoaXBEYXRhLmRhdGEpIHtcbiAgICAgICAgICAgICAgdmFyIG1lbWJlclN0YXR1cyA9IG1lbWJlcnNoaXBEYXRhLmRhdGFba10uYXR0cmlidXRlcy5zdGF0dXM7XG4gICAgICAgICAgICAgIHZhciB0YXJnZXRjb3Vyc2VJZCA9IG1lbWJlcnNoaXBEYXRhLmRhdGFba10uaWQuc3BsaXQoXCJfXCIpWzFdO1xuXG4gICAgICAgICAgICAgIHZhciB2YWxpZERvemVudCA9IHRhcmdldGNvdXJzZUlkID09PSBzdHVkaXBVc2VySWQ7XG4gICAgICAgICAgICAgIGlmIChtZW1iZXJTdGF0dXMgPT0gXCJkb3plbnRcIiAmJiB2YWxpZERvemVudCkge1xuICAgICAgICAgICAgICAgIG1lbWJlcnNoaXBzLnB1c2godG1wQ291cnNlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWVtYmVyc2hpcHM7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICB9LFxuXG4gIFwiY291cnNlcy5nZXRTdHVkZW50Q291cnNlc1wiOiBmdW5jdGlvbih0b2tlbiwgc3R1ZGlwVXNlcklkKSB7XG4gICAgdmFyIHVzZXIgPSBTdHVkZW50cy5maW5kT25lKHsgc3R1ZGlwVXNlcklkOiBzdHVkaXBVc2VySWQgfSk7XG5cbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICB0cnkge1xuICAgICAgICB2YXIgY291cnNlUmF3RGF0YSA9IEhUVFAuY2FsbChcbiAgICAgICAgICBcIkdFVFwiLFxuICAgICAgICAgIFwiaHR0cDovL2xvY2FsaG9zdC9zdHVkaXAvcGx1Z2lucy5waHAvYXJnb25hdXRzcGx1Z2luL3VzZXJzL1wiICtcbiAgICAgICAgICAgIHN0dWRpcFVzZXJJZCArXG4gICAgICAgICAgICBcIi9jb3Vyc2VzXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBcIkJhc2ljIFwiICsgdG9rZW4gfVxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgdmFyIGNvdXJzZURhdGEgPSBKU09OLnBhcnNlKGNvdXJzZVJhd0RhdGEuY29udGVudCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gY291cnNlRGF0YTtcbiAgICB9XG4gIH0sXG5cbiAgXCJjb3Vyc2VzLnN0YXJ0XCI6IGZ1bmN0aW9uKGNvdXJzZUlkKSB7XG4gICAgQ291cnNlcy51cGRhdGUoeyBfaWQ6IGNvdXJzZUlkIH0sIHsgJHNldDogeyBzdGFydGVkOiB0cnVlIH0gfSk7XG4gIH0sXG4gIFwiY291cnNlcy5kZWxldGVcIjogZnVuY3Rpb24oY291cnNlSWQsIHRlYWNoZXJJZCkge1xuICAgIC8vVE9ETyBkZWx0ZSByb3V0aW5lXG4gIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tIFwic2ltcGwtc2NoZW1hXCI7XG5cbmV4cG9ydCBjb25zdCBQYWNrYWdlID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJwYWNrYWdlXCIpO1xuXG5jb25zdCB0cmFpbmluZ1NjaGVtYSA9IG5ldyBTaW1wbGVTY2hlbWEoe1xuICBuYW1lOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIHRhc2tzOiB7XG4gICAgdHlwZTogQXJyYXlcbiAgfSxcbiAgXCJ0YXNrcy4kXCI6IHtcbiAgICB0eXBlOiBTdHJpbmdcbiAgfSxcbiAgdHJhaW5pbmdzOiB7XG4gICAgdHlwZTogQXJyYXlcbiAgfSxcbiAgXCJ0cmFpbmluZ3MuJFwiOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH1cbn0pLm5ld0NvbnRleHQoKTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICBNZXRlb3IucHVibGlzaChcInBhY2thZ2VcIiwgKCkgPT4ge1xuICAgIHJldHVybiBQYWNrYWdlLmZpbmQoe30pO1xuICB9KTtcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBcInBhY2thZ2UuaW5zZXJ0XCIodHJhaW5pbmcpIHtcbiAgICBQYWNrYWdlLmluc2VydCh0cmFpbmluZyk7XG4gIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tIFwic2ltcGwtc2NoZW1hXCI7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xuaW1wb3J0IHsgQ2xhc3Nyb29tcyB9IGZyb20gXCIuL2NvdXJzZXNcIjtcbmltcG9ydCB7IFRlYWNoZXJzIH0gZnJvbSBcIi4vdGVhY2hlcnNcIjtcbmltcG9ydCB7IENvdXJzZXMgfSBmcm9tIFwiLi9jb3Vyc2VzXCI7XG5pbXBvcnQgeyBUYXNrcyB9IGZyb20gXCIuL3Rhc2tzXCI7XG5pbXBvcnQgeyBQYWNrYWdlIH0gZnJvbSBcIi4vcGFja2FnZVwiO1xuZXhwb3J0IGNvbnN0IFN0dWRlbnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJzdHVkZW50c1wiKTtcblxuZnVuY3Rpb24gY2hlY2tUYXNrUmVxdWlyZW1lbnRzKHJlcSwgc29sdmVkVGFza3MpIHtcbiAgbGV0IGFsbFJlcXVpcmVkRm91bmQgPSB0cnVlO1xuICBmb3IgKGxldCBpIGluIHJlcSkge1xuICAgIGxldCBmb3VuZCA9IHNvbHZlZFRhc2tzLmZpbmQoZWxlbSA9PiB7XG4gICAgICByZXR1cm4gZWxlbS50YXNrSWQgPT09IHJlcVtpXTtcbiAgICB9KTtcbiAgICBpZiAoZm91bmQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgYWxsUmVxdWlyZWRGb3VuZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYWxsUmVxdWlyZWRGb3VuZDtcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBcInN0dWRlbnRzLmluc2VydFwiOiBmdW5jdGlvbih1c2VySWQsIHN0dWRpcFVzZXJJZCkge1xuICAgIFN0dWRlbnRzLmluc2VydCh7XG4gICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgIGNyZWRpdHM6IDAsXG4gICAgICBleHA6IDAsXG4gICAgICBsZXZlbDogMSxcbiAgICAgIGVhcm5pbmc6IFsxXSxcbiAgICAgIHN0dWRpcFVzZXJJZDogc3R1ZGlwVXNlcklkLFxuICAgICAgbGFzdEFjdGl2ZVRhc2tJZDogbnVsbCxcbiAgICAgIGNvdXJzZXM6IFtdLFxuICAgICAgdGFza3M6IFtdLFxuICAgICAgc29sdmVkU3VydmV5czogW10sXG4gICAgICBjdXJyZW50U2VxdWVuY2VJZDogMCxcbiAgICAgIGN1cnJlbnRUcmFpbmluZzogW10sXG4gICAgICBzb2x2ZWRUcmFpbmluZzogW10sXG4gICAgICBsZWFybkNhcmRzOiBbXSxcbiAgICAgIHNvbHZlZFRhc2tzOiBbXSxcbiAgICAgIGN1cnJlbnRQYWNrYWdlOiBbXVxuICAgIH0pO1xuICB9LFxuICBcInN0dWRlbnQuc2F2ZUxlYXJuY2FyZFwiOiBmdW5jdGlvbihcbiAgICBfaWQsXG4gICAgc3ViamVjdCxcbiAgICBzdGF0ZW1lbnQsXG4gICAgZXhhbXBsZSxcbiAgICBpbWFnZSxcbiAgICBjb250ZW50XG4gICkge1xuICAgIGxldCBsZWFybkNhcmRPYmogPSB7XG4gICAgICBzdWJqZWN0LFxuICAgICAgc3RhdGVtZW50LFxuICAgICAgZXhhbXBsZSxcbiAgICAgIGltYWdlLFxuICAgICAgY29udGVudFxuICAgIH07XG5cbiAgICBTdHVkZW50cy51cGRhdGUoX2lkLCB7ICRhZGRUb1NldDogeyBsZWFybkNhcmRzOiBsZWFybkNhcmRPYmogfSB9KTtcbiAgfSxcbiAgXCJzdHVkZW50cy5hZGRDb3Vyc2VcIjogZnVuY3Rpb24oY291cnNlSWQsIF9pZCkge1xuICAgIFN0dWRlbnRzLnVwZGF0ZShfaWQsIHsgJGFkZFRvU2V0OiB7IGNvdXJzZXM6IGNvdXJzZUlkIH0gfSk7XG4gIH0sXG4gIFwic3R1ZGVudHMuZ2V0U3RhcnRlZENvdXJzZXNcIjogZnVuY3Rpb24oc3R1ZGVudENvdXJzZXMpIHtcbiAgICB2YXIgdG1wID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzdHVkZW50Q291cnNlcy5sZW5ndGg7IGkrKykge1xuICAgICAgdG1wLnB1c2goQ291cnNlcy5maW5kT25lKHsgc3R1ZGlwSWQ6IHN0dWRlbnRDb3Vyc2VzW2ldIH0pKTtcbiAgICB9XG4gICAgcmV0dXJuIHRtcDtcbiAgfSxcbiAgXCJzdHVkZW50cy5nZXRUYXNrc1wiOiBmdW5jdGlvbih0YXNrcywgX2lkKSB7XG4gICAgU3R1ZGVudHMudXBkYXRlKF9pZCwgeyAkYWRkVG9TZXQ6IHsgdGFza3MgfSB9KTtcbiAgfSxcbiAgXCJzdHVkZW50cy5nZXROZXh0VGFza1wiOiBmdW5jdGlvbihwYWNrYWdlTmFtZSwgc2VxdWVuY2VJZCwgX2lkKSB7XG4gICAgbGV0IHRhc2tzID0gVGFza3MuZmluZCh7XG4gICAgICBwYWNrYWdlOiBwYWNrYWdlTmFtZSxcbiAgICAgIHNlcXVlbmNlSWQ6IHNlcXVlbmNlSWRcbiAgICB9KS5mZXRjaCgpWzBdO1xuICAgIFN0dWRlbnRzLnVwZGF0ZShfaWQsIHsgJGFkZFRvU2V0OiB7IHRhc2tzIH0gfSk7XG4gIH0sXG4gIC8vR2V0cyBhIHBhY2thZ2UgYW5kIGl0J3MgZmlyc3QgdHJhaW5pbmdcbiAgXCJzdHVkZW50cy5nZXRQYWNrYWdlXCI6IGZ1bmN0aW9uKHBhY2thZ2VOYW1lLCBfaWQpIHtcbiAgICB2YXIgcGFja2FnZU9iaiA9IFBhY2thZ2UuZmluZE9uZSh7IG5hbWU6IHBhY2thZ2VOYW1lIH0pO1xuICAgIHRyeSB7XG4gICAgICBTdHVkZW50cy51cGRhdGUoX2lkLCB7ICRhZGRUb1NldDogeyBjdXJyZW50UGFja2FnZTogcGFja2FnZU9iaiB9IH0pO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgfVxuICB9LFxuICBcInN0dWRlbnRzLmluaXRUcmFpbmluZ1wiOiBmdW5jdGlvbih0cmFpbmluZywgX2lkKSB7XG4gICAgdHJ5IHtcbiAgICAgIFN0dWRlbnRzLnVwZGF0ZShfaWQsIHsgJHNldDogeyBjdXJyZW50VHJhaW5pbmc6IHRyYWluaW5nIH0gfSk7XG4gICAgICByZXR1cm4gU3R1ZGVudHMuZmluZCh7IF9pZDogX2lkIH0pLmZldGNoKClbMF07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgfVxuICB9LFxuICBcInN0dWRlbnRzLnNldExhc3RBY3RpdmVUYXNrSWRcIjogZnVuY3Rpb24odGFza0lkLCBfaWQpIHtcbiAgICBTdHVkZW50cy51cGRhdGUoX2lkLCB7ICRhZGRUb1NldDogeyBsYXN0QWN0aXZlVGFza0lkOiB0YXNrSWQgfSB9KTtcbiAgfSxcbiAgXCJzdHVkZW50cy5zb2x2ZVRyYWluaW5nXCI6IGZ1bmN0aW9uKHN0dWRlbnQsIHRyYWluaW5nKSB7XG4gICAgdmFyIHN0dWRlbnRVcGRhdGVzID0ge1xuICAgICAgJGFkZFRvU2V0OiB7IHNvbHZlZFRyYWluaW5nOiB0cmFpbmluZyB9LFxuICAgICAgJHB1bGw6IHtcbiAgICAgICAgY3VycmVudFRyYWluaW5nOiB7XG4gICAgICAgICAgbmFtZTogdHJhaW5pbmcubmFtZSxcbiAgICAgICAgICBzZXF1ZW5jZUlkOiB0cmFpbmluZy5zZXF1ZW5jZUlkXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIFN0dWRlbnRzLnVwZGF0ZSh7IF9pZDogc3R1ZGVudC5faWQgfSwgc3R1ZGVudFVwZGF0ZXMpO1xuICAgIFN0dWRlbnRzLnVwZGF0ZSh7IF9pZDogc3R1ZGVudC5faWQgfSwgeyAkaW5jOiB7IGN1cnJlbnRTZXF1ZW5jZUlkOiAxIH0gfSk7XG4gIH0sXG4gIFwic3R1ZGVudHMuc2hvd05leHRUYXNrXCI6IGZ1bmN0aW9uKHN0dWRlbnQpIHtcbiAgICBsZXQgdGFzayA9IFRhc2tzLmZpbmQoe1xuICAgICAgcGFja2FnZTogc3R1ZGVudC5jdXJyZW50UGFja2FnZVswXS5uYW1lLFxuICAgICAgc2VxdWVuY2VJZDogc3R1ZGVudC5jdXJyZW50U2VxdWVuY2VJZCArIDFcbiAgICB9KS5mZXRjaCgpWzBdO1xuICAgIGlmICh0YXNrICYmIHRhc2sucmVxdWlyZXMpIHtcbiAgICAgIGlmICghY2hlY2tUYXNrUmVxdWlyZW1lbnRzKHRhc2sucmVxdWlyZXMsIHN0dWRlbnQuc29sdmVkVGFza3MpKSB7XG4gICAgICAgIFN0dWRlbnRzLnVwZGF0ZShcbiAgICAgICAgICB7IF9pZDogc3R1ZGVudC5faWQgfSxcbiAgICAgICAgICB7ICRpbmM6IHsgY3VycmVudFNlcXVlbmNlSWQ6IDIgfSB9XG4gICAgICAgICk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gICAgU3R1ZGVudHMudXBkYXRlKHsgX2lkOiBzdHVkZW50Ll9pZCB9LCB7ICRpbmM6IHsgY3VycmVudFNlcXVlbmNlSWQ6IDEgfSB9KTtcbiAgfSxcbiAgXCJzdHVkZW50cy5zaG93UHJldmlvdXNUYXNrXCI6IGZ1bmN0aW9uKHN0dWRlbnQpIHtcbiAgICBsZXQgdGFzayA9IFRhc2tzLmZpbmQoe1xuICAgICAgcGFja2FnZTogc3R1ZGVudC5jdXJyZW50UGFja2FnZVswXS5uYW1lLFxuICAgICAgc2VxdWVuY2VJZDogc3R1ZGVudC5jdXJyZW50U2VxdWVuY2VJZCAtIDFcbiAgICB9KS5mZXRjaCgpWzBdO1xuICAgIGlmICh0YXNrLnJlcXVpcmVzKSB7XG4gICAgICBpZiAoIWNoZWNrVGFza1JlcXVpcmVtZW50cyh0YXNrLnJlcXVpcmVzLCBzdHVkZW50LnNvbHZlZFRhc2tzKSkge1xuICAgICAgICBTdHVkZW50cy51cGRhdGUoXG4gICAgICAgICAgeyBfaWQ6IHN0dWRlbnQuX2lkIH0sXG4gICAgICAgICAgeyAkaW5jOiB7IGN1cnJlbnRTZXF1ZW5jZUlkOiAtMiB9IH1cbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cblxuICAgIFN0dWRlbnRzLnVwZGF0ZSh7IF9pZDogc3R1ZGVudC5faWQgfSwgeyAkaW5jOiB7IGN1cnJlbnRTZXF1ZW5jZUlkOiAtMSB9IH0pO1xuICB9XG59KTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAvLyBwdXBpbFxuICBNZXRlb3IucHVibGlzaChcInN0dWRlbnRcIiwgKCkgPT4ge1xuICAgIGlmIChNZXRlb3IudXNlcklkKCkgJiYgUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VyKCksIFtcInN0dWRlbnRcIl0pKSB7XG4gICAgICByZXR1cm4gU3R1ZGVudHMuZmluZCh7IHVzZXJJZDogTWV0ZW9yLnVzZXJJZCgpIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICAvLyB0ZWFjaGVyXG4gIE1ldGVvci5wdWJsaXNoKFwicHVwaWxzQnlDbGFzc0lkXCIsIGNsYXNzSWQgPT4ge1xuICAgIGNvbnN0IHRlYWNoZXIgPSBUZWFjaGVycy5maW5kT25lKHsgdXNlcklkOiBNZXRlb3IudXNlcklkKCkgfSk7XG4gICAgaWYgKHRlYWNoZXIgJiYgdGVhY2hlci5jbGFzc3Jvb21zLmluY2x1ZGVzKGNsYXNzSWQpKSB7XG4gICAgICByZXR1cm4gUHVwaWxzLmZpbmQoeyBjbGFzc0lkIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gIH0pO1xuICAvLyBwdXBpbFxuICBNZXRlb3IucHVibGlzaChcImNvbXBhbnlNYXRlc1wiLCAoKSA9PiB7XG4gICAgY29uc3QgcHVwaWwgPSBQdXBpbHMuZmluZE9uZSh7IHVzZXJJZDogTWV0ZW9yLnVzZXJJZCgpIH0pO1xuICAgIGlmIChwdXBpbCkge1xuICAgICAgcmV0dXJuIFB1cGlscy5maW5kKHsgY29tcGFueUlkOiBwdXBpbC5jb21wYW55SWQgfSk7XG4gICAgfVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJBY2Nlc3MgZGVuaWVkIVwiKTtcbiAgfSk7XG4gIC8vIGFkbWluXG4gIE1ldGVvci5wdWJsaXNoKFwicHVwaWxzT2ZUZWFjaGVyXCIsICgpID0+IHtcbiAgICBjb25zdCB0ZWFjaGVyID0gVGVhY2hlcnMuZmluZE9uZSh7IHVzZXJJZDogTWV0ZW9yLnVzZXJJZCgpIH0pO1xuICAgIGlmICh0ZWFjaGVyKSB7XG4gICAgICByZXR1cm4gUHVwaWxzLmZpbmQoeyBjbGFzc0lkOiB7ICRpbjogdGVhY2hlci5jbGFzc3Jvb21zIH0gfSk7XG4gICAgfVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJBY2Nlc3MgZGVuaWVkIVwiKTtcbiAgfSk7XG59XG4iLCIvKlxuIFRpdGVsOiBDb2xsZWN0aW9uIHVuZCBTY2hlbWEgdW0gZWluZW4gTWV0ZW9yLlVzZXIgZWluZXIgU2Now7xsZXItQ29sbGVjdGlvblxuICAgICAgICB6dXp1d2Vpc2VuXG4gQXV0b3I6IEp1bGlhblxuKi9cblxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tIFwic2ltcGwtc2NoZW1hXCI7XG5pbXBvcnQgc2hvcnRpZCBmcm9tIFwic2hvcnRpZFwiO1xuXG5leHBvcnQgY29uc3QgVGFza3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInRhc2tzXCIpO1xuXG5jb25zdCB0YXNrU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIHRhc2tJZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBzaG9ydERlc2NyaXB0aW9uOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIHR5cGU6IHtcbiAgICB0eXBlOiBTdHJpbmdcbiAgfSxcbiAgdHJhaW5pbmdJZDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBwYWNrYWdlOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIGZpbGVQcmVmaXg6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgc29sdXRpb24xOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgc29sdXRpb24yOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgc29sdXRpb24zOiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgc29sdXRpb240OiB7XG4gICAgdHlwZTogQXJyYXksXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgcmVuZGVyZmlsZXM6IHtcbiAgICB0eXBlOiBBcnJheSxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuXG4gIFwicmVuZGVyZmlsZXMuJFwiOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIFwic29sdXRpb24xLiRcIjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBcInNvbHV0aW9uMi4kXCI6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgXCJzb2x1dGlvbjMuJFwiOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIFwic29sdXRpb240LiRcIjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuXG4gIGRlc2NyaXB0aW9uOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIGluc3RydWN0aW9uOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG4gIGNyZWRpdHM6IHtcbiAgICB0eXBlOiBOdW1iZXJcbiAgfSxcblxuICBtaW5MZXZlbDoge1xuICAgIHR5cGU6IE51bWJlclxuICB9LFxuICAvL2VtcGZvaGxlbmVzIExldmVsXG4gIGxldmVsOiB7XG4gICAgdHlwZTogTnVtYmVyXG4gIH0sXG4gIHRhc2t1cmw6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSxcbiAgcHJlS25vd2xlZGdlOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0sXG4gIC8vdHJ1ZSB3ZW5uIGdyYWRpbmcgYXV0b21hdGlzY2ggaXN0LCBmYWxzZSBzb25zdFxuICBhdXRvR3JhZGluZzoge1xuICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfVxufSkubmV3Q29udGV4dCgpO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIFwidGFza3MuaW5zZXJ0XCIodGFzaykge1xuICAgIFRhc2tzLmluc2VydCh0YXNrKTtcbiAgfVxufSk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgTWV0ZW9yLnB1Ymxpc2goXCJ0YXNrc1wiLCAoKSA9PiB7XG4gICAgcmV0dXJuIFRhc2tzLmZpbmQoe30pO1xuICB9KTtcbiAgTWV0ZW9yLnB1Ymxpc2goXCJ0YXNrc0J5SWRzXCIsIHRhc2tJZHMgPT4ge1xuICAgIHJldHVybiBUYXNrcy5maW5kKHsgdGFza0lkOiB7ICRpbjogdGFza0lkcyB9IH0pO1xuICB9KTtcbiAgTWV0ZW9yLnB1Ymxpc2goXCJ0YXNrQnlJZFwiLCBmdW5jdGlvbih0YXNrSWQpIHtcbiAgICByZXR1cm4gVGFza3MuZmluZCh7IHRhc2tJZDogdGFza0lkIH0pO1xuICB9KTtcblxuICBNZXRlb3IucHVibGlzaChcInRhc2tzQnlQYWNrYWdlXCIsIG5hbWUgPT4ge1xuICAgIHJldHVybiBUYXNrcy5maW5kKHsgdGFza1BhY2thZ2U6IG5hbWUgfSk7XG4gIH0pO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tIFwic2ltcGwtc2NoZW1hXCI7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gXCJtZXRlb3IvYWNjb3VudHMtYmFzZVwiO1xuaW1wb3J0IHsgU3R1ZGVudHMgfSBmcm9tIFwiLi9zdHVkZW50c1wiO1xuaW1wb3J0IHsgQ2xhc3Nyb29tcyB9IGZyb20gXCIuL2NvdXJzZXNcIjtcblxuZXhwb3J0IGNvbnN0IFRlYWNoZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJ0ZWFjaGVyc1wiKTtcblxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAvLyB0ZWFjaGVyXG4gIE1ldGVvci5wdWJsaXNoKFwidGVhY2hlclwiLCBmdW5jdGlvbih0ZWFjaGVySWQpIHtcbiAgICByZXR1cm4gVGVhY2hlcnMuZmluZCh7IHN0dWRpcFVzZXJJZDogdGVhY2hlcklkIH0pO1xuICB9KTtcbiAgTWV0ZW9yLnB1Ymxpc2goXCJ0ZWFjaGVyQnlVc2VySWRcIiwgZnVuY3Rpb24odXNlcklkKSB7XG4gICAgaWYgKE1ldGVvci51c2VySWQoKSAmJiBSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXIoKSwgW1widGVhY2hlclwiXSkpIHtcbiAgICAgIHJldHVybiBUZWFjaGVycy5maW5kKHsgdXNlcklkOiBNZXRlb3IudXNlcklkKCkgfSk7XG4gICAgfVxuICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJBY2NlcyBkZW5pZWQhXCIpO1xuICB9KTtcbiAgLy8gYWRtaW5cbiAgTWV0ZW9yLnB1Ymxpc2goXCJhbGxUZWFjaGVyXCIsIGZ1bmN0aW9uKCkge1xuICAgIGlmIChNZXRlb3IudXNlcklkKCkgJiYgUm9sZXMudXNlcklzSW5Sb2xlKE1ldGVvci51c2VyKCksIFtcInlhZG1pblwiXSkpIHtcbiAgICAgIHJldHVybiBUZWFjaGVycy5maW5kKHt9KTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcIkFjY2VzcyBkZW5pZWQhXCIpO1xuICB9KTtcbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICBcInRlYWNoZXJzLmluc2VydFwiOiBmdW5jdGlvbih1c2VySWQsIHN0dWRpcFVzZXJJZCkge1xuICAgIFRlYWNoZXJzLmluc2VydCh7XG4gICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgIHN0dWRpcFVzZXJJZDogc3R1ZGlwVXNlcklkLFxuICAgICAgY291cnNlczogW11cbiAgICB9KTtcbiAgfSxcblxuICBcInRlYWNoZXJzLmRlbGV0ZVwiOiBmdW5jdGlvbih1c2VySWQpIHtcbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBsZXQgdGVhY2hlciA9IG51bGw7XG4gICAgICBpZiAoTWV0ZW9yLnVzZXJJZCgpICYmIFJvbGVzLnVzZXJJc0luUm9sZShNZXRlb3IudXNlcigpLCBbXCJwcGFkbWluXCJdKSkge1xuICAgICAgICB0ZWFjaGVyID0gVGVhY2hlcnMuZmluZE9uZSh7IHVzZXJJZCB9KTtcbiAgICAgICAgaWYgKCF0ZWFjaGVyKSB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiVGVhY2hlciBkb2Vzbid0IGV4aXN0IVwiKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIE1ldGVvci51c2VySWQoKSAmJlxuICAgICAgICBSb2xlcy51c2VySXNJblJvbGUoTWV0ZW9yLnVzZXIoKSwgW1widGVhY2hlclwiXSlcbiAgICAgICkge1xuICAgICAgICB0ZWFjaGVyID0gVGVhY2hlcnMuZmluZE9uZSh7IHVzZXJJZDogTWV0ZW9yLnVzZXJJZCgpIH0pO1xuICAgICAgfVxuICAgICAgaWYgKHRlYWNoZXIpIHtcbiAgICAgICAgY29uc3QgY2xhc3Nyb29tcyA9IENsYXNzcm9vbXMuZmluZCh7XG4gICAgICAgICAgX2lkOiB7ICRpbjogdGVhY2hlci5jbGFzc3Jvb21zIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNsYXNzcm9vbXMuZm9yRWFjaChjbGFzc3Jvb20gPT4ge1xuICAgICAgICAgIENvbXBhbmllcy5yZW1vdmUoeyBfaWQ6IHsgJGluOiBjbGFzc3Jvb20uY29tcGFuaWVzIH0gfSk7XG4gICAgICAgICAgU3R1ZGVudHMucmVtb3ZlKHsgdXNlcklkOiB7ICRpbjogY2xhc3Nyb29tLnN0dWRlbnRzIH0gfSk7XG4gICAgICAgICAgTWV0ZW9yLnVzZXJzLnJlbW92ZSh7IF9pZDogeyAkaW46IGNsYXNzcm9vbS5zdHVkZW50cyB9IH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgQ2xhc3Nyb29tcy5yZW1vdmUoeyBfaWQ6IHsgJGluOiB0ZWFjaGVyLmNsYXNzcm9vbXMgfSB9KTtcbiAgICAgICAgVGVhY2hlcnMucmVtb3ZlKHsgdXNlcklkOiB0ZWFjaGVyLnVzZXJJZCB9KTtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnJlbW92ZSh7IF9pZDogdGVhY2hlci51c2VySWQgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiQWNjZXNzIGRlbmllZCFcIik7XG4gICAgICB9XG4gICAgfVxuICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSBcInNpbXBsLXNjaGVtYVwiO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tIFwibWV0ZW9yL2FjY291bnRzLWJhc2VcIjtcblxuZXhwb3J0IGNvbnN0IFRva2VucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwidG9rZW5zXCIpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIE1ldGVvci5wdWJsaXNoKFwidG9rZW5CeVVzZXJcIiwgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIFRva2Vucy5maW5kKHsgdXNlcklkOiBNZXRlb3IudXNlcklkKCkgfSk7XG4gIH0pO1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgXCJ0b2tlbnMuaW5zZXJ0XCI6IGZ1bmN0aW9uKHVzZXJJZCwgdG9rZW4pIHtcbiAgICAgIFRva2Vucy5pbnNlcnQoe1xuICAgICAgICB1c2VySWQ6IHVzZXJJZCxcbiAgICAgICAgdG9rZW46IHRva2VuXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tIFwic2ltcGwtc2NoZW1hXCI7XG5cbmV4cG9ydCBjb25zdCBUcmFpbmluZyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwidHJhaW5pbmdcIik7XG5cbmNvbnN0IHRyYWluaW5nU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gIG5hbWU6IHtcbiAgICB0eXBlOiBTdHJpbmdcbiAgfSxcblxuICBwYWNrYWdlOiB7XG4gICAgdHlwZTogU3RyaW5nXG4gIH0sXG5cbiAgaW1hZ2VWaWRlbzoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9LFxuICBkaXNjb3VudDoge1xuICAgIHR5cGU6IEJvb2xlYW5cbiAgfSxcblxuICBmb3JtYXQ6IHtcbiAgICB0eXBlOiBTdHJpbmdcbiAgfVxufSkubmV3Q29udGV4dCgpO1xuXG5pZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gIE1ldGVvci5wdWJsaXNoKFwidHJhaW5pbmdcIiwgKCkgPT4ge1xuICAgIHJldHVybiBUcmFpbmluZy5maW5kKHt9KTtcbiAgfSk7XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgXCJ0cmFpbmluZy5pbnNlcnRcIih0cmFpbmluZykge1xuICAgIFRyYWluaW5nLmluc2VydCh0cmFpbmluZyk7XG4gIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSBcInNpbXBsLXNjaGVtYVwiO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tIFwibWV0ZW9yL2FjY291bnRzLWJhc2VcIjtcblxuaW1wb3J0IHsgUHVwaWxzIH0gZnJvbSBcIi4vc3R1ZGVudHNcIjtcbmltcG9ydCB7IFRlYWNoZXJzIH0gZnJvbSBcIi4vdGVhY2hlcnNcIjtcbmltcG9ydCB7IENvdXJzZXMgfSBmcm9tIFwiLi9jb3Vyc2VzXCI7XG5BY2NvdW50cy52YWxpZGF0ZU5ld1VzZXIodXNlciA9PiB7XG4gIHJldHVybiB0cnVlO1xufSk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgLy8gVE9ETzpcbiAgTWV0ZW9yLnB1Ymxpc2goXCJ1c2Vyc0J5Q2xhc3Nyb29tXCIsIGZ1bmN0aW9uKGNsYXNzSWQpIHt9KTtcblxuICBNZXRlb3IucHVibGlzaChcInVzZXJCeU5hbWVcIiwgZnVuY3Rpb24odXNlck5hbWUpIHtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyB1c2VybmFtZTogdXNlck5hbWUgfSk7XG4gIH0pO1xufVxuTWV0ZW9yLm1ldGhvZHMoe1xuICAvLyBwZXJmb3JtIGEgYmFzaWMgYXV0aCB1c2VyLXJlcXVlc3QgdG8gdmVyaWZ5IGEgc3R1ZGlwLXVzZXJcbiAgXCJ1c2Vycy5hdXRoXCI6IGZ1bmN0aW9uKHRva2VuLCBlbWFpbCwgcGFzc3dvcmQpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0ID0gSFRUUC5jYWxsKFxuICAgICAgICBcIkdFVFwiLFxuICAgICAgICBcImh0dHA6Ly9sb2NhbGhvc3Qvc3R1ZGlwL3BsdWdpbnMucGhwL2FyZ29uYXV0c3BsdWdpbi91c2Vycy9tZVwiLFxuICAgICAgICB7XG4gICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiB0b2tlbiB9XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgICB2YXIgdXNlckRhdGEgPSBKU09OLnBhcnNlKHJlc3VsdC5jb250ZW50KTtcbiAgICAgIHZhciBzdHVkaXBVc2VySWQgPSB1c2VyRGF0YS5kYXRhLmlkO1xuICAgICAgaWYgKE1ldGVvci51c2Vycy5maW5kT25lKHsgdXNlcm5hbWU6IGVtYWlsIH0pKSB7XG4gICAgICAgIHZhciB1c2VyID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoeyB1c2VybmFtZTogZW1haWwgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB1c2VySWQgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgICB1c2VybmFtZTogZW1haWwsXG4gICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgdmFyIHJlc3VsdHMgPSBbcmVzdWx0LCBzdHVkaXBVc2VySWRdO1xuICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAvLyBHb3QgYSBuZXR3b3JrIGVycm9yLCB0aW1lb3V0LCBvciBIVFRQIGVycm9yIGluIHRoZSA0MDAgb3IgNTAwIHJhbmdlLlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfSxcbiAgXCJ1c2Vycy50ZWFjaGVyc0luc2VydFwiOiBmdW5jdGlvbih1c2VybmFtZSwgc3R1ZGlwVXNlcklkKSB7XG4gICAgdmFyIHRlYWNoZXJJZCA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgdXNlcm5hbWU6IHVzZXJuYW1lIH0pLl9pZDtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModGVhY2hlcklkLCBcInRlYWNoZXJcIik7XG4gICAgTWV0ZW9yLmNhbGwoXCJ0ZWFjaGVycy5pbnNlcnRcIiwgdGVhY2hlcklkLCBzdHVkaXBVc2VySWQpO1xuICAgIHJldHVybiB0ZWFjaGVySWQ7XG4gIH0sXG4gIFwidXNlcnMuc3R1ZGVudEluc2VydFwiOiBmdW5jdGlvbih1c2VybmFtZSwgc3R1ZGlwVXNlcklkKSB7XG4gICAgdmFyIHN0dWRlbnRJZCA9IE1ldGVvci51c2Vycy5maW5kT25lKHsgdXNlcm5hbWU6IHVzZXJuYW1lIH0pLl9pZDtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXMoc3R1ZGVudElkLCBcInN0dWRlbnRcIik7XG4gICAgTWV0ZW9yLmNhbGwoXCJzdHVkZW50cy5pbnNlcnRcIiwgc3R1ZGVudElkLCBzdHVkaXBVc2VySWQpO1xuICAgIHJldHVybiBzdHVkZW50SWQ7XG4gIH1cbn0pO1xuIiwiZXhwb3J0IGZ1bmN0aW9uIHNhdmVDYXJkKHN0dWRlbnRJZCwgdGFza0lkKSB7XG4gIGNvbnN0IHRhc2sgPSB0YXNrSWQ7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gY2hlY2tNdWx0aShxdWVzdGlvbiwgc3R1ZGVudFNvbHV0aW9uLCBjb3JyZWN0U29sdXRpb24pIHtcbiAgY29uc3QgYW5zd2VycyA9IHF1ZXN0aW9uLkFuc3dlclNldDtcbiAgbGV0IGZhbHNlQ291bnQgPSAwO1xuXG4gIC8vIEdldCBjb3JyZWN0IHF1ZXN0aW9uIGZyb20gYXJyYXlcbiAgaWYgKHN0dWRlbnRTb2x1dGlvbi5sZW5ndGggPiAxKSB7XG4gICAgc3R1ZGVudFNvbHV0aW9uID0gc3R1ZGVudFNvbHV0aW9uLmZpbHRlcihlbGVtID0+IHtcbiAgICAgIHJldHVybiBlbGVtLmlkLnRvU3RyaW5nKCkgPT09IHF1ZXN0aW9uLlF1ZXN0aW9uSWQudG9TdHJpbmcoKTtcbiAgICB9KTtcbiAgfVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYW5zd2Vycy5sZW5ndGg7IGkrKykge1xuICAgIGxldCBhbnN3ZXJJc1NlbGVjdGVkID1cbiAgICAgIHN0dWRlbnRTb2x1dGlvbi5sZW5ndGggPiAwXG4gICAgICAgID8gc3R1ZGVudFNvbHV0aW9uWzBdLnZhbHVlcy5pbmNsdWRlcyhhbnN3ZXJzW2ldKVxuICAgICAgICA6IGZhbHNlO1xuICAgIGxldCBhbnN3ZXJJc0NvcnJlY3QgPSBjb3JyZWN0U29sdXRpb24uY29ycmVjdC5pbmNsdWRlcyhhbnN3ZXJzW2ldKTtcblxuICAgIGlmIChhbnN3ZXJJc1NlbGVjdGVkICE9IGFuc3dlcklzQ29ycmVjdCkge1xuICAgICAgbGV0IGFuc3dlck5ldXRyYWwgPVxuICAgICAgICBjb3JyZWN0U29sdXRpb24ubmV1dHJhbCAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgIGNvcnJlY3RTb2x1dGlvbi5uZXV0cmFsLmluY2x1ZGVzKGFuc3dlcnNbaV0pO1xuICAgICAgaWYgKCFhbnN3ZXJOZXV0cmFsKSB7XG4gICAgICAgIGZhbHNlQ291bnQrKztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgbGV0IGZhbHNlUXVlc3Rpb25zID0gW107XG4gIGlmIChmYWxzZUNvdW50ID4gMCkge1xuICAgIGZhbHNlUXVlc3Rpb25zLnB1c2goY29ycmVjdFNvbHV0aW9uKTtcbiAgfVxuXG4gIGxldCByZXR2YWwgPSB7XG4gICAgZmFsc2VDb3VudCxcbiAgICB0b3RhbEFuc3dlckNvdW50OiBhbnN3ZXJzLmxlbmd0aCxcbiAgICBuZXV0cmFsQW5zd2VyczogY29ycmVjdFNvbHV0aW9uLm5ldXRyYWwsXG4gICAgZmFsc2VRdWVzdGlvbnNcbiAgfTtcblxuICByZXR1cm4gcmV0dmFsO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCBlcXVhbHMgZnJvbSBcImZhc3QtZGVlcC1lcXVhbFwiO1xuaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XG5cbmltcG9ydCB7IFN0dWRlbnRzIH0gZnJvbSBcIi4uLy4uL2ltcG9ydHMvYXBpL3N0dWRlbnRzXCI7XG5pbXBvcnQgeyBUYXNrcyB9IGZyb20gXCIuLi8uLi9pbXBvcnRzL2FwaS90YXNrc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gc29sdmVUYXNrKHN0dWRlbnRJZCwgdGFza0lkLCBzb2x2ZWRQZXJjZW50YWdlKSB7XG4gIGNvbnN0IHN0dWRlbnQgPSBTdHVkZW50cy5maW5kT25lKHsgX2lkOiBzdHVkZW50SWQgfSk7XG4gIGxldCB0YXNrID0gZ2V0VGFzayhzdHVkZW50SWQsIHRhc2tJZCk7XG4gIGlmICghdGFzaykgcmV0dXJuO1xuICB1cGRhdGVTdHVkZW50RXhwZXJpZW5jZShzdHVkZW50LCB0YXNrLCBzb2x2ZWRQZXJjZW50YWdlKTtcbiAgdXBkYXRlU3R1ZGVudENyZWRpdHMoc3R1ZGVudCwgdGFzaywgc29sdmVkUGVyY2VudGFnZSk7XG4gIHNldFRhc2tTb2x2ZWQoc3R1ZGVudCwgdGFzayk7XG59XG5cbi8qKlxuICogR2V0IFRhc2sgZnJvbSBTdHVkZW50IGJ5IHN0dWRlbnRJZCBhbmQgdGFza0lkXG4gKiBAcGFyYW0ge051bWJlcn0gc3R1ZGVudElkXG4gKiBAcGFyYW0ge051bWJlcn0gdGFza0lkXG4gKi9cbmZ1bmN0aW9uIGdldFRhc2soc3R1ZGVudElkLCB0YXNrSWQpIHtcbiAgdHJ5IHtcbiAgICB2YXIgY3VycmVudFRhc2sgPSBTdHVkZW50cy5maW5kKFxuICAgICAgeyBfaWQ6IHN0dWRlbnRJZCwgXCJ0YXNrcy50YXNrSWRcIjogdGFza0lkIH0sXG4gICAgICB7IGZpZWxkczogeyBcInRhc2tzLiRcIjogMSwgX2lkOiAwIH0gfVxuICAgICkuZmV0Y2goKVswXTtcbiAgICBpZiAoIWN1cnJlbnRUYXNrKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gY3VycmVudFRhc2sudGFza3NbMF07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5sb2coZXJyb3IpO1xuICB9XG59XG5cbi8qKlxuICogU2V0IGVuZFRpbWUgYW5kIHNvbHZlZCBmbGFnIG9mIHRhc2tcbiAqIEBwYXJhbSB7Kn0gc3R1ZGVudFxuICogQHBhcmFtIHsqfSB0YXNrXG4gKi9cbmZ1bmN0aW9uIHNldFRhc2tTb2x2ZWQoc3R1ZGVudCwgdGFzaykge1xuICB2YXIgZW5kVGltZSA9IG1vbWVudCgpLmZvcm1hdChcImRkZGQsIE1NTU0sIERvIFlZWVksIGg6bW06c3MgYVwiKTtcbiAgdGFza1tcImVuZFRpbWVcIl0gPSBlbmRUaW1lO1xuICB0YXNrW1widGFza1N0YXRlXCJdID0gXCJzb2x2ZWRcIjtcblxuICB1cGRhdGVTdHVkZW50RGF0YShzdHVkZW50Ll9pZCwge1xuICAgICRwdXNoOiB7IHNvbHZlZFRhc2tzOiB0YXNrIH0sXG4gICAgJHNldDogeyBsYXN0QWN0aXZlVGFza0lkOiB0YXNrLnRhc2tJZCB9LFxuICAgICRwdWxsOiB7IHRhc2tzOiB7IHRhc2tJZDogdGFzay50YXNrSWQgfSB9LFxuICAgICRpbmM6IHsgY3VycmVudFNlcXVlbmNlSWQ6IDEgfVxuICB9KTtcbn1cblxuLyoqXG4gKiBVcGRhdGUgdGhlIHN0dWRlbnRzIGV4cGVyaWVuY2UgYW5kIGNoZWNrIGZvciBsZXZlbC11cFxuICogQHBhcmFtIHsqfSBzdHVkZW50XG4gKiBAcGFyYW0geyp9IHRhc2tcbiAqIEBwYXJhbSB7TnVtYmVyfSBzb2x2ZWRQZXJjZW50YWdlXG4gKi9cbmZ1bmN0aW9uIHVwZGF0ZVN0dWRlbnRFeHBlcmllbmNlKHN0dWRlbnQsIHRhc2ssIHNvbHZlZFBlcmNlbnRhZ2UpIHtcbiAgbGV0IHRhc2tFeHAgPSB0YXNrLmNyZWRpdHM7XG4gIGxldCBsZXZlbCA9IHN0dWRlbnQubGV2ZWw7XG5cbiAgLy8gRXhwZXJpZW5jZSBuZWVkZWQgdG8gbGV2ZWwgdXBcbiAgY29uc3QgbmVlZGVkRXhwID0gbGV2ZWwgKiBsZXZlbCAqIDEwO1xuXG4gIC8vIENoZWNrIGlmIHNvbHZlZFBlcmNlbnRhZ2UgaXMgYSBub3QgbnVsbCBvciBpcyAwXG4gIGlmIChzb2x2ZWRQZXJjZW50YWdlIHx8IHNvbHZlZFBlcmNlbnRhZ2UgPT0gMCkge1xuICAgIHRhc2tFeHAgPSBNYXRoLnJvdW5kKHRhc2tFeHAgKiBzb2x2ZWRQZXJjZW50YWdlKTtcbiAgfVxuXG4gIGxldCBuZXdFeHAgPSBzdHVkZW50LmV4cCArIHRhc2tFeHA7XG5cbiAgaWYgKG5ld0V4cCA+IG5lZWRlZEV4cCkge1xuICAgIGxldmVsKys7XG4gICAgbmV3RXhwIC09IG5lZWRlZEV4cDtcbiAgfVxuXG4gIHVwZGF0ZVN0dWRlbnREYXRhKHN0dWRlbnQuX2lkLCB7ICRzZXQ6IHsgbGV2ZWw6IGxldmVsLCBleHA6IG5ld0V4cCB9IH0pO1xufVxuXG4vKipcbiAqIEluY3JlbWVudCB0aGUgc3R1ZGVudHMgY3JlZGl0c1xuICogQHBhcmFtIHsqfSBzdHVkZW50XG4gKiBAcGFyYW0geyp9IHRhc2tcbiAqIEBwYXJhbSB7TnVtYmVyfSBzb2x2ZWRQZXJjZW50YWdlXG4gKi9cbmZ1bmN0aW9uIHVwZGF0ZVN0dWRlbnRDcmVkaXRzKHN0dWRlbnQsIHRhc2ssIHNvbHZlZFBlcmNlbnRhZ2UpIHtcbiAgbGV0IG5ld0NyZWRpdHMgPSB0YXNrLmNyZWRpdHM7XG4gIGlmIChzb2x2ZWRQZXJjZW50YWdlIHx8IHNvbHZlZFBlcmNlbnRhZ2UgPT0gMCkge1xuICAgIG5ld0NyZWRpdHMgPSBNYXRoLnJvdW5kKG5ld0NyZWRpdHMgKiBzb2x2ZWRQZXJjZW50YWdlKTtcbiAgfVxuXG4gIHVwZGF0ZVN0dWRlbnREYXRhKHN0dWRlbnQuX2lkLCB7ICRpbmM6IHsgY3JlZGl0czogbmV3Q3JlZGl0cyB9IH0pO1xufVxuXG4vKipcbiAqIFVwZGF0ZSBzdHVkZW50IGluIG1vbmdvXG4gKiBAcGFyYW0ge051bWJlcn0gc3R1ZGVudElkXG4gKiBAcGFyYW0geyp9IGRhdGFcbiAqL1xuZnVuY3Rpb24gdXBkYXRlU3R1ZGVudERhdGEoc3R1ZGVudElkLCBkYXRhKSB7XG4gIFN0dWRlbnRzLnVwZGF0ZSh7IF9pZDogc3R1ZGVudElkIH0sIGRhdGEpO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcbmltcG9ydCBlcXVhbHMgZnJvbSBcImZhc3QtZGVlcC1lcXVhbFwiO1xuXG5pbXBvcnQgeyBzYXZlQ2FyZCB9IGZyb20gXCIuL3NvbHV0aW9uSGFuZGxpbmcvY2FyZFNhdmVyXCI7XG5pbXBvcnQgeyBzb2x2ZVRhc2sgfSBmcm9tIFwiLi9zb2x1dGlvbkhhbmRsaW5nL3Rhc2tTb2x2ZXJcIjtcbmltcG9ydCB7IGNoZWNrTXVsdGkgfSBmcm9tIFwiLi9zb2x1dGlvbkhhbmRsaW5nL211bHRpU29sdmVyXCI7XG5cbmltcG9ydCB7IFN0dWRlbnRzIH0gZnJvbSBcIi4uL2ltcG9ydHMvYXBpL3N0dWRlbnRzXCI7XG5cbnZhciBTb2x1dGlvbnMgPSBKU09OLnBhcnNlKEFzc2V0cy5nZXRUZXh0KFwic29sdXRpb25zLmpzb25cIikpO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gIFwic29sdXRpb25IYW5kbGVyLnN1Ym1pdENhcmRcIihzdHVkZW50SWQsIHRhc2spIHtcbiAgICBzYXZlQ2FyZChzdHVkZW50SWQsIHRhc2sudGFza0lkKTtcbiAgICBzb2x2ZVRhc2soc3R1ZGVudElkLCB0YXNrLnRhc2tJZCwgMTAwKTtcbiAgfSxcbiAgXCJzb2x1dGlvbkhhbmRsZXIuc3VibWl0RHJhZ1wiKFxuICAgIHN0dWRlbnRTb2x1dGlvbixcbiAgICBzdHVkZW50SWQsXG4gICAgdGFzayxcbiAgICBzb2x2ZWRQZXJjZW50YWdlXG4gICkge1xuICAgIGNvbnNvbGUubG9nKFwiZW50ZXJlZGRcIik7XG4gICAgY29uc29sZS5sb2coc3R1ZGVudFNvbHV0aW9uKTtcbiAgICBpZiAoc29sdmVkUGVyY2VudGFnZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBzb2x2ZVRhc2soc3R1ZGVudElkLCB0YXNrLnRhc2tJZCwgc29sdmVkUGVyY2VudGFnZSk7XG4gICAgfVxuXG4gICAgLy8gdmFyIGNvcnJlY3QgPSBlcXVhbHMoc3R1ZGVudFNvbHV0aW9uLCBTb2x1dGlvbnNbdGFzay50YXNrSWRdKTtcbiAgICB2YXIgY29ycmVjdCA9IHRydWU7XG4gICAgc3R1ZGVudFNvbHV0aW9uLm1hcChzb2x1dGlvbiA9PiB7XG4gICAgICBzb2x1dGlvbi5jaGlsZHJlbi5tYXAoKGNoaWxkLCBpbmRleCkgPT4ge1xuICAgICAgICBpZiAodGFzay5tdWx0aXBsZUNvbHVtbnMpIHtcbiAgICAgICAgICBpZiAoc29sdXRpb24uY2F0ZWdvcmllICE9IGNoaWxkLnNvbHV0aW9uKSB7XG4gICAgICAgICAgICBjb3JyZWN0ID0gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChjaGlsZC5zb2x1dGlvbiAhPSB0YXNrLnNvbEFycmF5W2luZGV4XSkge1xuICAgICAgICAgICAgY29ycmVjdCA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBpZiAoY29ycmVjdCkge1xuICAgICAgc29sdmVUYXNrKHN0dWRlbnRJZCwgdGFzay50YXNrSWQpO1xuICAgIH1cbiAgICByZXR1cm4gY29ycmVjdDtcbiAgfSxcbiAgXCJzb2x1dGlvbkhhbmRsZXIuc3VibWl0Q2xvemVcIihcbiAgICBzdHVkZW50U29sdXRpb24sXG4gICAgc3R1ZGVudElkLFxuICAgIHRhc2ssXG4gICAgc29sdmVkUGVyY2VudGFnZVxuICApIHtcbiAgICBpZiAoc29sdmVkUGVyY2VudGFnZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBzb2x2ZVRhc2soc3R1ZGVudElkLCB0YXNrLnRhc2tJZCwgc29sdmVkUGVyY2VudGFnZSk7XG4gICAgfVxuICAgIGxldCBjb3JyZWN0QW5zd2VycyA9IFtdO1xuICAgIGxldCBhbGxDb3JyZWN0ID0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0dWRlbnRTb2x1dGlvbi5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKFxuICAgICAgICBzdHVkZW50U29sdXRpb25baV0udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpID09PVxuICAgICAgICBTb2x1dGlvbnNbdGFzay50YXNrSWRdW2ldLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKVxuICAgICAgKSB7XG4gICAgICAgIGNvcnJlY3RBbnN3ZXJzLnB1c2godHJ1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb3JyZWN0QW5zd2Vycy5wdXNoKGZhbHNlKTtcbiAgICAgICAgYWxsQ29ycmVjdCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYWxsQ29ycmVjdCkge1xuICAgICAgc29sdmVUYXNrKHN0dWRlbnRJZCwgdGFzay50YXNrSWQpO1xuICAgIH1cbiAgICByZXR1cm4gY29ycmVjdEFuc3dlcnM7XG4gIH0sXG4gIFwic29sdXRpb25IYW5kbGVyLnN1Ym1pdFRhZ1wiKHN0dWRlbnRTb2x1dGlvbiwgc3R1ZGVudElkLCB0YXNrKSB7XG4gICAgdmFyIGNvcnJlY3QgPVxuICAgICAgIVNvbHV0aW9uc1t0YXNrLnRhc2tJZF0gfHxcbiAgICAgIHN0dWRlbnRTb2x1dGlvbi5sZW5ndGggPT0gU29sdXRpb25zW3Rhc2sudGFza0lkXS5sZW5ndGg7XG4gICAgaWYgKGNvcnJlY3QpIHtcbiAgICAgIHNvbHZlVGFzayhzdHVkZW50SWQsIHRhc2sudGFza0lkKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvcnJlY3Q7XG4gIH0sXG4gIFwic29sdXRpb25IYW5kbGVyLnN1Ym1pdE1lbW9yeVwiKHN0dWRlbnRTb2x1dGlvbiwgc3R1ZGVudElkLCB0YXNrKSB7XG4gICAgdmFyIGNvcnJlY3QgPSBzdHVkZW50U29sdXRpb24ubGVuZ3RoID09IHRhc2suY29udGVudFswXS5rZXl3b3Jkcy5sZW5ndGggKiAyO1xuICAgIGlmIChjb3JyZWN0KSB7XG4gICAgICBzb2x2ZVRhc2soc3R1ZGVudElkLCB0YXNrLnRhc2tJZCk7XG4gICAgfVxuICAgIHJldHVybiBjb3JyZWN0O1xuICB9LFxuICBcInNvbHV0aW9uSGFuZGxlci5zdWJtaXRNdWx0aVwiKFxuICAgIHN0dWRlbnRTb2x1dGlvbixcbiAgICBzdHVkZW50SWQsXG4gICAgdGFzayxcbiAgICBxdWVzdGlvbkluZGV4LFxuICAgIHNvbHZlZFBlcmNlbnRhZ2VcbiAgKSB7XG4gICAgaWYgKHNvbHZlZFBlcmNlbnRhZ2UgIT09IHVuZGVmaW5lZCkge1xuICAgICAgc29sdmVUYXNrKHN0dWRlbnRJZCwgdGFzay50YXNrSWQsIHNvbHZlZFBlcmNlbnRhZ2UpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGxldCBzb2x1dGlvbiA9IFNvbHV0aW9uc1t0YXNrLnRhc2tJZF07XG4gICAgaWYgKCFzb2x1dGlvbikgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBjdXJyZW50U29sdXRpb24gPSBzb2x1dGlvbi5maW5kKGVsZW1lbnQgPT4ge1xuICAgICAgaWYgKHRhc2suY29udGVudCkge1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIGVsZW1lbnQuaWQudG9TdHJpbmcoKSA9PT1cbiAgICAgICAgICB0YXNrLmNvbnRlbnRbcXVlc3Rpb25JbmRleF0uUXVlc3Rpb25JZC50b1N0cmluZygpXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gZWxlbWVudC5pZC50b1N0cmluZygpID09PSB0YXNrLlF1ZXN0aW9uSWQudG9TdHJpbmcoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIHF1ZXN0aW9uIGhhcyBubyBcImNvcnJlY3RcIiBhbnN3ZXJcbiAgICBpZiAoY3VycmVudFNvbHV0aW9uLmNvcnJlY3RbMF0gPT09IFwiZnJlZVwiKSB7XG4gICAgICByZXR1cm4gY3VycmVudFNvbHV0aW9uLmNvcnJlY3QuY29uY2F0KHN0dWRlbnRTb2x1dGlvbik7XG4gICAgfVxuXG4gICAgbGV0IHJldHZhbCA9IGNoZWNrTXVsdGkoXG4gICAgICB0YXNrLmNvbnRlbnQgPyB0YXNrLmNvbnRlbnRbcXVlc3Rpb25JbmRleF0gOiB0YXNrLFxuICAgICAgc3R1ZGVudFNvbHV0aW9uLFxuICAgICAgY3VycmVudFNvbHV0aW9uXG4gICAgKTtcblxuICAgIGlmICh0YXNrLmhhc05leHQpIHtcbiAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHJldHZhbCwgeyBuZXh0OiB0cnVlIH0pO1xuICAgIH1cblxuICAgIGlmIChyZXR2YWwuZmFsc2VDb3VudCA9PT0gMCkge1xuICAgICAgc29sdmVUYXNrKHN0dWRlbnRJZCwgdGFzay50YXNrSWQpO1xuICAgIH1cblxuICAgIHJldHVybiByZXR2YWw7XG4gIH0sXG4gIFwic29sdXRpb25IYW5kbGVyLnN1Ym1pdFN1cnZleVwiKHN1cnZleURhdGEsIHN0dWRlbnRJZCwgdGFzaykge1xuICAgIC8vIE1hcmsgc3VydmV5VGFzayBhcyBTb2x2ZWQgYW5kIG1vdmUgaXQgaW50byBzb2x2ZWRUYXNrQXJyYXlcbiAgICBzb2x2ZVRhc2soc3R1ZGVudElkLCB0YXNrLnRhc2tJZCk7XG4gICAgLy9HZXQgdXBkYXRlZCBTb2x2ZWRUYXNrcyBmcm9tIFN0dWRlbnRcbiAgICBsZXQgY3VycmVudFN0dWRlbnREYXRhID0gU3R1ZGVudHMuZmluZE9uZSh7IF9pZDogc3R1ZGVudElkIH0pO1xuICAgIGxldCBjdXJyZW50U3VydmV5VGFzayA9IGN1cnJlbnRTdHVkZW50RGF0YS5zb2x2ZWRUYXNrcy5maW5kKFxuICAgICAgZWxlbSA9PiBlbGVtLnRhc2tJZCA9PT0gdGFzay50YXNrSWRcbiAgICApO1xuICAgIC8vIFNldCBzdXJ2ZXlEYXRhIGluIFNvbHZlZFRhc2sgKFN1cnZleSlcbiAgICBjdXJyZW50U3VydmV5VGFzay5zdXJ2ZXlEYXRhID0gc3VydmV5RGF0YTtcbiAgICBjdXJyZW50U3VydmV5VGFzay5jb250ZW50ID0gc3VydmV5RGF0YS5jb250ZW50O1xuICAgIC8vIEFkZCBuZXcgc3VydmV5RGF0YSB0byBNZXRlb3JcbiAgICBjb25zdCBzdXJ2ZXlPYmogPSB7XG4gICAgICBzdXJ2ZXlJZDogdGFzay50YXNrSWQsXG4gICAgICB0aXRsZTogdGFzay50aXRsZSxcbiAgICAgIHBhY2thZ2U6IHRhc2sucGFja2FnZSxcbiAgICAgIHF1ZXN0aW9uOiB0YXNrLnF1ZXN0aW9uLFxuICAgICAgYW5zd2VyczogdGFzay5rZXl3b3JkcyxcbiAgICAgIHNvbHV0aW9uOiBzdXJ2ZXlEYXRhLmNoZWNrZWRBbnN3ZXJzLFxuICAgICAgY29tbWVudDogc3VydmV5RGF0YS5jb250ZW50XG4gICAgfTtcbiAgICBTdHVkZW50cy51cGRhdGUoeyBfaWQ6IHN0dWRlbnRJZCB9LCB7ICRzZXQ6IHsgc29sdmVkU3VydmV5czogc3VydmV5T2JqIH0gfSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIFwic29sdXRpb25IYW5kbGVyLmNoZWNrTXVsdGlcIihzdHVkZW50U29sdXRpb24sIHRhc2ssIHF1ZXN0aW9uSW5kZXgpIHtcbiAgICBsZXQgc29sdXRpb24gPSBTb2x1dGlvbnNbdGFzay50YXNrSWRdO1xuICAgIGlmICghc29sdXRpb24pIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgY3VycmVudFNvbHV0aW9uID0gc29sdXRpb24uZmluZChlbGVtZW50ID0+IHtcbiAgICAgIGlmICh0YXNrLmNvbnRlbnQpIHtcbiAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICBlbGVtZW50LmlkLnRvU3RyaW5nKCkgPT09XG4gICAgICAgICAgdGFzay5jb250ZW50W3F1ZXN0aW9uSW5kZXhdLlF1ZXN0aW9uSWQudG9TdHJpbmcoKVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGVsZW1lbnQuaWQudG9TdHJpbmcoKSA9PT0gdGFzay5RdWVzdGlvbklkLnRvU3RyaW5nKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBxdWVzdGlvbiBoYXMgbm8gXCJjb3JyZWN0XCIgYW5zd2VyXG4gICAgaWYgKGN1cnJlbnRTb2x1dGlvbi5jb3JyZWN0WzBdID09PSBcImZyZWVcIikge1xuICAgICAgcmV0dXJuIGN1cnJlbnRTb2x1dGlvbi5jb3JyZWN0LmNvbmNhdChzdHVkZW50U29sdXRpb24pO1xuICAgIH1cblxuICAgIGxldCByZXR2YWwgPSBjaGVja011bHRpKFxuICAgICAgdGFzay5jb250ZW50ID8gdGFzay5jb250ZW50W3F1ZXN0aW9uSW5kZXhdIDogdGFzayxcbiAgICAgIHN0dWRlbnRTb2x1dGlvbixcbiAgICAgIGN1cnJlbnRTb2x1dGlvblxuICAgICk7XG5cbiAgICBpZiAodGFzay5oYXNOZXh0KSB7XG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihyZXR2YWwsIHsgbmV4dDogdHJ1ZSB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmV0dmFsO1xuICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG4vKiBSZWZlcmVueiBhdWYgQ29sbGVjdGlvbi1BcGksIHdlaWwgd2lyIG5pY2h0IGRpcmVrdCBpbiBTZXJ2ZXIgc2NocmVpYmVuIGTDvHJmZW4gKi9cbmltcG9ydCB7IEFjY291bnRzIH0gZnJvbSBcIm1ldGVvci9hY2NvdW50cy1iYXNlXCI7XG5pbXBvcnQgeyByZXNldERhdGFiYXNlIH0gZnJvbSBcIi4uL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvZGF0YWJhc2VIYW5kbGluZ1wiO1xuaW1wb3J0IFwiLi9zb2x1dGlvbkhhbmRsaW5nXCI7XG5cbmltcG9ydCBcIi4uL2ltcG9ydHMvYXBpL3VzZXJzXCI7XG5pbXBvcnQgXCIuLi9pbXBvcnRzL2FwaS90ZWFjaGVyc1wiO1xuaW1wb3J0IFwiLi4vaW1wb3J0cy9hcGkvY291cnNlc1wiO1xuaW1wb3J0IFwiLi4vaW1wb3J0cy9hcGkvdG9rZW5zXCI7XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgLy8gY29kZSB0byBydW4gb24gc2VydmVyIGF0IHN0YXJ0dXBcbiAgcmVzZXREYXRhYmFzZSgpO1xufSk7XG4iXX0=
