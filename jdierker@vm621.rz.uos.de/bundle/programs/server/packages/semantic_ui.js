(function () {



/* Exports */
Package._define("semantic:ui");

})();
