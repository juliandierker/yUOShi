(function () {

/* Package-scope variables */
var Draggable, goog;



/* Exports */
Package._define("draggable", {
  Draggable: Draggable,
  goog: goog
});

})();
